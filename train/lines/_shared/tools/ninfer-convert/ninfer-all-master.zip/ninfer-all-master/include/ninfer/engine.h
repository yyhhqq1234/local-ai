#pragma once

#include "ninfer/types.h"

#include <chrono>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace ninfer {

class PreparedPrompt {
public:
    PreparedPrompt() noexcept;
    ~PreparedPrompt();

    PreparedPrompt(PreparedPrompt&&) noexcept;
    PreparedPrompt& operator=(PreparedPrompt&&) noexcept;

    PreparedPrompt(const PreparedPrompt&)            = delete;
    PreparedPrompt& operator=(const PreparedPrompt&) = delete;

    [[nodiscard]] const PromptSummary& summary() const noexcept;
    [[nodiscard]] const PromptPreparationStats& preparation_stats() const noexcept;
    // The prompt's token ids as the model reads them, media placeholders included.
    [[nodiscard]] std::span<const TokenId> token_ids() const noexcept;
    [[nodiscard]] explicit operator bool() const noexcept;

private:
    class Impl;
    explicit PreparedPrompt(std::unique_ptr<Impl> impl) noexcept;
    std::unique_ptr<Impl> impl_;

    friend class Engine;
};

class GenerationHandle {
public:
    GenerationHandle() noexcept;
    ~GenerationHandle();

    GenerationHandle(GenerationHandle&&) noexcept;
    GenerationHandle& operator=(GenerationHandle&&) noexcept;

    GenerationHandle(const GenerationHandle&)            = delete;
    GenerationHandle& operator=(const GenerationHandle&) = delete;

    [[nodiscard]] explicit operator bool() const noexcept;
    [[nodiscard]] const ResolvedSamplingParameters& resolved_sampling() const noexcept;
    [[nodiscard]] std::optional<std::uint32_t> effective_thinking_budget() const noexcept;

    GenerationResult wait(OutputSink* sink = nullptr, const CancellationView& cancellation = {});

private:
    class Impl;
    explicit GenerationHandle(std::unique_ptr<Impl> impl) noexcept;
    std::unique_ptr<Impl> impl_;

    friend class Engine;
};

class Engine {
public:
    explicit Engine(EngineOptions options);
    ~Engine();

    Engine(Engine&&) noexcept;
    Engine& operator=(Engine&&) noexcept;

    Engine(const Engine&)            = delete;
    Engine& operator=(const Engine&) = delete;

    [[nodiscard]] PreparedPrompt prepare(PromptInput input,
                                         const PreparationControl& control = {}) const;

    // Raw token input is retained for repeatable correctness and performance measurement.
    // `anchor_prompt_end` also retains a private checkpoint one token short of the prompt's end, so
    // the same prompt sent again (a regenerated raw completion) resumes from it; a raw prompt has
    // no message structure to anchor otherwise. It costs a prefill split and a StateImage.
    [[nodiscard]] PreparedPrompt prepare_tokens(std::vector<TokenId> token_ids,
                                                bool allow_prefix_identity = true,
                                                bool anchor_prompt_end     = false) const;

    // Artifact-tokenizer raw-text encoding. No chat template or implicit special token is added;
    // special-token text in `text` encodes as that token unless `parse_special` is false.
    [[nodiscard]] std::vector<TokenId> tokenize_text(std::string_view text,
                                                     bool parse_special = true) const;

    // The bytes one token decodes to, special tokens included; they need not be whole UTF-8.
    [[nodiscard]] std::string token_bytes(TokenId token) const;

    // Returns log p(tokens[i] | tokens[0..i)) for i in [first_target,tokens.size()).
    [[nodiscard]] std::vector<float> score_tokens(std::vector<TokenId> tokens,
                                                  std::uint32_t first_target);

    [[nodiscard]] std::uint32_t count_tokens(PromptInput input,
                                             const PreparationControl& control = {}) const;
    [[nodiscard]] ModelSamplingDefaults sampling_defaults() const;

    // Establishes queue membership synchronously with a fixed output consumer mode. Destroying an
    // unconsumed handle cancels its request; wait() owns result consumption and may run
    // independently from GPU execution. Streaming mode requires a non-null sink in wait() and
    // publishes one exact GenerationStart before output deltas; Aggregate mode requires a null
    // sink. Observation options request protocol-neutral publication facts without changing the
    // execution request.
    [[nodiscard]] GenerationHandle
    submit(PreparedPrompt prompt, RequestOptions options,
           OutputConsumerMode consumer_mode                       = OutputConsumerMode::Aggregate,
           GenerationObservationOptions observation               = {},
           std::chrono::steady_clock::time_point pending_deadline = {});

    // The largest requested_output_tokens for this prompt whose admission entitlement -- Main KV
    // plus any MTP/DFlash backend KV, draft window included -- fits one lane's share of each pool,
    // so every lane of max_concurrency can hold such a request at the same time. Clamped to the
    // remaining context; with one lane that is the remaining context itself. A prompt that alone
    // exceeds a lane's share receives the remaining context. Generation Engines only.
    [[nodiscard]] std::uint32_t concurrent_output_budget(const PreparedPrompt& prompt) const;

    GenerationResult generate(PreparedPrompt prompt, RequestOptions options,
                              OutputSink* sink                     = nullptr,
                              const CancellationView& cancellation = {});

    [[nodiscard]] const EngineOptions& options() const;
    [[nodiscard]] LoadSummary load_summary() const;
    [[nodiscard]] ModelMetadata model_metadata() const;
    [[nodiscard]] MemorySummary memory_summary() const;
    [[nodiscard]] RuntimeStats runtime_stats() const;
    [[nodiscard]] MediaCacheSummary media_cache_summary() const;
    [[nodiscard]] bool is_available() const;
    // True after an Engine-wide failure, from which the Engine never recovers: every request fails
    // until a new Engine is constructed. Unavailability for any other reason (a stop, a model held
    // suspended) is not a failure.
    [[nodiscard]] bool has_failed() const;

    void reset_memory_peaks() noexcept;

    // Model residency (EngineOptions::suspend, Generation Engines). suspend() gives the model's
    // device memory back while the Engine is idle and returns once it is released; it refuses with
    // RequestError(Overloaded) while anything is queued, admitted or running, and never cancels
    // work. `auto_resume` (default: the Engine option) decides whether a generation request
    // arriving meanwhile resumes the model first or fails as Unavailable. resume() maps the memory
    // again, uploads the weights and restores the retained state; a failure leaves the model
    // suspended with its state intact, so it may be retried. Both are idempotent and callable from
    // any thread; with suspend disabled they throw std::invalid_argument.
    ResidencyStatus suspend(std::optional<bool> auto_resume = std::nullopt);
    ResidencyStatus resume();
    [[nodiscard]] ResidencyStatus residency() const;

    // Begins the orderly stop without waiting for it: new work is refused, and queued and active
    // generation requests end with an Unavailable error within one unit of work. A Generation
    // Engine then saves its prefix cache file, when configured. Destruction waits for the stop.
    // Idempotent and callable from any thread.
    void stop() noexcept;

    // Session persistence for one private context-cache catalog cell (slot_states().size()
    // cells). save_slot writes the cell's retained session to `path`; restore_slot rebuilds the
    // cell from a saved file, evicting what it held; erase_slot evicts the cell's session and
    // returns its depth. A cell in use by a request, or any open resource transaction, raises
    // RequestError(Overloaded); a missing or incompatible file raises std::invalid_argument; a
    // non-empty expected_digest that does not match the resident session raises
    // SlotSessionMismatch, checked atomically with the operation. Device copies run between
    // Engine units; file I/O runs outside them.
    [[nodiscard]] SlotSaveResult save_slot(std::uint32_t slot, const std::string& path,
                                           const std::string& expected_digest = {});
    [[nodiscard]] SlotRestoreResult restore_slot(std::uint32_t slot, const std::string& path);
    std::uint32_t erase_slot(std::uint32_t slot, const std::string& expected_digest = {});
    // Per-cell occupancy as of the last Engine unit boundary.
    [[nodiscard]] std::vector<SlotState> slot_states() const;

private:
    class Impl;
    std::shared_ptr<Impl> impl_;
};

} // namespace ninfer
