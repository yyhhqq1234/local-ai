#pragma once

#include "core/arena.h"
#include "core/device.h"

#include <cuda_runtime.h>

#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>
#include <vector>

namespace ninfer {

// VMM-backed persistent arena whose KV payload prefix can lend individual granules for a bounded
// window. Every store binds at the offsets it uses today, so plane pointers, block tables and the
// captured decode graphs stay valid: the home mapping never moves and only granules that lie
// entirely inside free KV pages are ever unmapped.
//
// Unlike the weight pool there is no host mirror. A lent granule holds free pages only, and no
// page is read before the append kernel writes it, so closing a lease remaps home and copies
// nothing.
//
// Neither lease() nor close() quiesces a stream: the caller guarantees that every lent granule
// lies entirely inside free KV pages, so no in-flight work addresses it and decode continues on
// the main stream while a window is open.
class EvictableKVPool {
public:
    struct Config {
        std::size_t arena_bytes           = 0; // persistent arena capacity
        std::size_t lendable_prefix_bytes = 0; // KV payload prefix eligible for lending
        // Largest extent one lease may hand out; zero: no leases, granule releases only.
        std::size_t window_capacity_bytes = 0;
    };

    struct LeaseStats {
        double lease_seconds     = 0.0;
        double return_seconds    = 0.0;
        std::size_t mapped_bytes = 0;
    };

    class Transaction {
    public:
        Transaction() noexcept = default;
        ~Transaction();

        Transaction(const Transaction&)            = delete;
        Transaction& operator=(const Transaction&) = delete;
        Transaction(Transaction&& other) noexcept;
        Transaction& operator=(Transaction&& other) noexcept;

        [[nodiscard]] bool open() const noexcept { return pool_ != nullptr; }
        [[nodiscard]] DeviceSpan leased() const noexcept { return leased_; }
        [[nodiscard]] const LeaseStats& stats() const noexcept { return stats_; }

        // Remaps the lent granules home. Never throws: a failure poisons the pool, which the
        // owner must treat as fatal for the KV cache.
        void close() noexcept;

    private:
        friend class EvictableKVPool;

        Transaction(EvictableKVPool& pool, DeviceSpan leased, cudaStream_t stream,
                    double lease_seconds) noexcept;

        EvictableKVPool* pool_ = nullptr;
        DeviceSpan leased_{};
        cudaStream_t stream_ = nullptr;
        LeaseStats stats_{};
    };

    [[nodiscard]] static bool supported(const DeviceContext& device);
    // VMM allocation granularity of the device, or zero when virtual memory management is
    // unavailable. Lets a caller decide whether a window fits the lendable prefix before it
    // commits to building a pool.
    [[nodiscard]] static std::size_t device_granularity(const DeviceContext& device);

    EvictableKVPool(DeviceContext& device, const Config& config);
    ~EvictableKVPool();

    EvictableKVPool(const EvictableKVPool&)            = delete;
    EvictableKVPool& operator=(const EvictableKVPool&) = delete;

    // Stable home mapping backing the persistent arena for the process lifetime.
    [[nodiscard]] DeviceSpan arena() const noexcept;
    [[nodiscard]] std::size_t granularity() const noexcept;
    // Granules covering the lendable prefix; indices beyond this are permanently resident.
    [[nodiscard]] std::size_t lendable_granules() const noexcept;
    [[nodiscard]] std::size_t window_capacity_bytes() const noexcept;
    [[nodiscard]] bool lease_open() const noexcept;
    [[nodiscard]] bool poisoned() const noexcept;

    // Model suspend: every physical piece goes back to the device while the home addresses stay
    // reserved, so the pointers and graphs that captured them stay valid. Nothing may be borrowed
    // and the caller has drained every stream that addresses the arena. restore_backing maps fresh
    // pieces home; their contents are undefined until the owner rewrites them. A restore that fails
    // part-way releases what it created and leaves the pool unbacked, so it may be retried.
    void release_backing();
    void restore_backing();
    [[nodiscard]] bool backed() const noexcept;

    // Granule containing an arena offset, and the arena range one granule covers.
    [[nodiscard]] std::size_t granule_of(std::size_t offset) const;
    [[nodiscard]] DeviceSpan granule_bytes(std::size_t index) const;

    // Lends the given granules, mapped consecutively at the overlay range in the order supplied.
    // Indices must be strictly increasing and inside the lendable prefix. A failure part-way
    // through returns every piece to its home mapping before it throws, so a refused lease leaves
    // the arena exactly as it found it and the caller may try again.
    [[nodiscard]] Transaction lease(std::span<const std::size_t> granules, cudaStream_t stream);

    // Stage of one granule's move to the overlay range, named so a test can fail a lease there.
    enum class LeaseFault : std::uint8_t {
        None,
        Unmap,   // before the piece leaves its home mapping
        Overlay, // after the home unmap, before the overlay mapping exists
        Access,  // after the overlay mapping exists, before the piece counts as lent
    };

    // Test seam: makes the next lease() throw at `rank`, at the stage named, and fires once. The
    // rollback in lease() must still hand back a fully resident, unpoisoned pool.
    void inject_lease_fault(std::size_t rank, LeaseFault stage) noexcept;

    // Gives the physical pieces of resident granules back to the device, for another owner (an
    // expert cache) to allocate; their home addresses stay reserved and unmapped. restore_granules
    // backs released granules at home again with fresh pieces whose contents are undefined, or,
    // when the device cannot supply them all, releases what it created and throws. Like lease(),
    // neither quiesces a stream: the caller guarantees that the granules lie entirely inside KV
    // pages that no work addresses. A suspend needs every granule restored first.
    void release_granules(std::span<const std::size_t> granules);
    void restore_granules(std::span<const std::size_t> granules);
    [[nodiscard]] std::size_t released_granules() const noexcept;
    [[nodiscard]] bool granule_released(std::size_t granule) const noexcept;

private:
    struct Impl;

    void give_back(Transaction& transaction) noexcept;

    std::unique_ptr<Impl> impl_;
};

} // namespace ninfer
