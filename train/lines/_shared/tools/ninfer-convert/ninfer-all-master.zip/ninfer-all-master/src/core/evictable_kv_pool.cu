#include "core/evictable_kv_pool.h"

#include "core/vmm.h"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <stdexcept>
#include <string>
#include <vector>

namespace ninfer {
namespace {

using Clock = std::chrono::steady_clock;

std::size_t align_up(std::size_t value, std::size_t alignment) {
    return (value + alignment - 1) / alignment * alignment;
}

double seconds_since(Clock::time_point start) {
    return std::chrono::duration<double>(Clock::now() - start).count();
}

constexpr std::size_t kResidentPiece = 1024ULL * 1024ULL * 1024ULL;

} // namespace

struct EvictableKVPool::Impl {
    DeviceContext& device;
    Config config{};
    std::size_t granularity       = 0;
    std::size_t arena_reserved    = 0; // granularity-aligned home reservation
    std::size_t window_reserved   = 0; // granularity-aligned overlay reservation
    std::size_t lendable_granules = 0; // granules covering the KV payload prefix
    CUdeviceptr home              = 0;
    CUdeviceptr overlay           = 0;
    // One handle per piece: the lendable prefix in granules, the remainder in large pieces.
    // Offsets are arena offsets; the vectors are parallel and piece i of the prefix is granule i.
    std::vector<CUmemGenericAllocationHandle> handles;
    std::vector<std::size_t> offsets;
    std::vector<std::size_t> sizes;
    std::vector<std::size_t> lent; // granule indices currently mapped at the overlay range
    std::vector<unsigned char> released; // by piece: no physical piece (release_granules)
    std::size_t released_count = 0;
    bool poisoned = false;
    bool backed   = false; // physical pieces exist and are mapped home or at the overlay
    // Test seam; see inject_lease_fault.
    LeaseFault fault       = LeaseFault::None;
    std::size_t fault_rank = 0;

    explicit Impl(DeviceContext& context) : device(context) {}

    void set_access(CUdeviceptr va, std::size_t bytes) {
        vmm::set_access(va, bytes, std::span(&device.device, 1));
    }

    void map_home(std::size_t piece) {
        vmm::map(home + offsets[piece], sizes[piece], handles[piece], std::span(&device.device, 1));
    }

    void map_overlay(std::size_t piece, std::size_t rank) {
        check_fault(rank, LeaseFault::Overlay);
        NINFER_CU_CHECK(cuMemMap(overlay + rank * granularity, sizes[piece], 0, handles[piece], 0));
        check_fault(rank, LeaseFault::Access);
        set_access(overlay + rank * granularity, sizes[piece]);
    }

    void check_fault(std::size_t rank, LeaseFault stage) {
        if (fault != stage || fault_rank != rank) { return; }
        fault = LeaseFault::None;
        throw std::runtime_error("injected evictable KV lease fault");
    }

    // Undoes a lease that threw while moving `rank` to the overlay range. Ranks below it are
    // mapped there and counted in `lent`; `homeless` says `rank` itself has already lost its home
    // mapping. Every touched piece must end up home again: the caller only learns that the lease
    // failed, and a granule left unmapped faults the next kernel that writes a page inside it.
    void unwind_lease(std::span<const std::size_t> granules, std::size_t rank,
                      bool homeless) noexcept {
        try {
            for (std::size_t done = 0; done < rank; ++done) {
                NINFER_CU_CHECK(cuMemUnmap(overlay + done * granularity, granularity));
                map_home(granules[done]);
            }
            if (homeless) {
                // The overlay mapping of this piece may or may not exist, and unmapping a range
                // that carries nothing is a harmless error here; losing its home mapping is not.
                (void)cuMemUnmap(overlay + rank * granularity, granularity);
                map_home(granules[rank]);
            }
        } catch (const std::exception& error) {
            poisoned = true;
            std::fprintf(stderr,
                         "ninfer: evictable KV lease rollback failed (%s); the KV cache is no "
                         "longer trustworthy\n",
                         error.what());
        } catch (...) {
            poisoned = true;
            std::fprintf(stderr, "ninfer: evictable KV lease rollback failed; the KV cache is no "
                                 "longer trustworthy\n");
        }
        lent.clear();
    }
};

bool EvictableKVPool::supported(const DeviceContext& device) {
    return vmm::supported(device.device);
}

std::size_t EvictableKVPool::device_granularity(const DeviceContext& device) {
    return vmm::granularity(device.device);
}

EvictableKVPool::EvictableKVPool(DeviceContext& device, const Config& config)
    : impl_(std::make_unique<Impl>(device)) {
    if (config.arena_bytes == 0) {
        throw std::invalid_argument("evictable KV arena must not be empty");
    }
    if (config.lendable_prefix_bytes > config.arena_bytes) {
        throw std::invalid_argument("evictable KV lendable prefix exceeds the arena");
    }
    vmm::ensure_driver_initialized();
    Impl& impl       = *impl_;
    impl.config      = config;
    impl.granularity = vmm::granularity(device.device);
    if (impl.granularity == 0) {
        throw std::invalid_argument("evictable KV pool needs CUDA virtual memory management");
    }
    if (kResidentPiece % impl.granularity != 0) {
        throw std::runtime_error("evictable KV resident piece is not a granularity multiple");
    }

    impl.arena_reserved = align_up(config.arena_bytes, impl.granularity);
    // Whole granules only: a granule that straddles the payload boundary stays resident.
    impl.lendable_granules = config.lendable_prefix_bytes / impl.granularity;
    impl.window_reserved   = align_up(config.window_capacity_bytes, impl.granularity);
    if (impl.window_reserved > impl.lendable_granules * impl.granularity) {
        throw std::invalid_argument("evictable KV window exceeds the lendable prefix");
    }

    NINFER_CU_CHECK(cuMemAddressReserve(&impl.home, impl.arena_reserved, impl.granularity, 0, 0));
    if (impl.window_reserved != 0) {
        NINFER_CU_CHECK(
            cuMemAddressReserve(&impl.overlay, impl.window_reserved, impl.granularity, 0, 0));
    }

    std::size_t offset = 0;
    for (std::size_t granule = 0; granule < impl.lendable_granules; ++granule) {
        impl.offsets.push_back(offset);
        impl.sizes.push_back(impl.granularity);
        offset += impl.granularity;
    }
    while (offset < impl.arena_reserved) {
        const std::size_t piece = std::min(kResidentPiece, impl.arena_reserved - offset);
        impl.offsets.push_back(offset);
        impl.sizes.push_back(piece);
        offset += piece;
    }

    impl.handles.resize(impl.offsets.size());
    impl.released.assign(impl.offsets.size(), 0);
    restore_backing();
}

EvictableKVPool::~EvictableKVPool() {
    if (impl_ == nullptr || impl_->home == 0) { return; }
    Impl& impl = *impl_;
    for (std::size_t rank = 0; rank < impl.lent.size(); ++rank) {
        (void)cuMemUnmap(impl.overlay + rank * impl.granularity, impl.granularity);
    }
    if (impl.backed) {
        for (std::size_t piece = 0; piece < impl.handles.size(); ++piece) {
            if (impl.released[piece]) { continue; }
            const bool away =
                std::find(impl.lent.begin(), impl.lent.end(), piece) != impl.lent.end();
            if (!away) { (void)cuMemUnmap(impl.home + impl.offsets[piece], impl.sizes[piece]); }
            (void)cuMemRelease(impl.handles[piece]);
        }
    }
    (void)cuMemAddressFree(impl.home, impl.arena_reserved);
    if (impl.overlay != 0) { (void)cuMemAddressFree(impl.overlay, impl.window_reserved); }
}

bool EvictableKVPool::backed() const noexcept { return impl_->backed; }

void EvictableKVPool::release_backing() {
    Impl& impl = *impl_;
    if (!impl.backed) { return; }
    if (!impl.lent.empty()) {
        throw std::logic_error("evictable KV pool cannot release its backing while a lease is open");
    }
    if (impl.released_count != 0) {
        throw std::logic_error("evictable KV pool cannot release its backing while granules are released");
    }
    for (std::size_t piece = 0; piece < impl.handles.size(); ++piece) {
        (void)cuMemUnmap(impl.home + impl.offsets[piece], impl.sizes[piece]);
        (void)cuMemRelease(impl.handles[piece]);
        impl.handles[piece] = {};
    }
    impl.backed = false;
}

void EvictableKVPool::restore_backing() {
    Impl& impl = *impl_;
    if (impl.backed) { return; }
    std::size_t created = 0;
    try {
        for (; created < impl.handles.size(); ++created) {
            impl.handles[created] = vmm::create(impl.sizes[created], impl.device.device);
            try {
                impl.map_home(created);
            } catch (...) {
                (void)cuMemRelease(impl.handles[created]);
                throw;
            }
        }
    } catch (...) {
        for (std::size_t piece = 0; piece < created; ++piece) {
            (void)cuMemUnmap(impl.home + impl.offsets[piece], impl.sizes[piece]);
            (void)cuMemRelease(impl.handles[piece]);
        }
        throw;
    }
    impl.backed = true;
}

DeviceSpan EvictableKVPool::arena() const noexcept {
    return DeviceSpan{reinterpret_cast<void*>(impl_->home), impl_->config.arena_bytes};
}

std::size_t EvictableKVPool::granularity() const noexcept { return impl_->granularity; }

std::size_t EvictableKVPool::lendable_granules() const noexcept { return impl_->lendable_granules; }

std::size_t EvictableKVPool::window_capacity_bytes() const noexcept {
    return impl_->window_reserved;
}

bool EvictableKVPool::lease_open() const noexcept { return !impl_->lent.empty(); }

bool EvictableKVPool::poisoned() const noexcept { return impl_->poisoned; }

std::size_t EvictableKVPool::granule_of(std::size_t offset) const {
    if (offset >= impl_->config.arena_bytes) {
        throw std::out_of_range("evictable KV offset is outside the arena");
    }
    return offset / impl_->granularity;
}

DeviceSpan EvictableKVPool::granule_bytes(std::size_t index) const {
    if (index >= impl_->lendable_granules) {
        throw std::out_of_range("evictable KV granule is outside the lendable prefix");
    }
    return DeviceSpan{reinterpret_cast<void*>(impl_->home + index * impl_->granularity),
                      impl_->granularity};
}

EvictableKVPool::Transaction EvictableKVPool::lease(std::span<const std::size_t> granules,
                                                    cudaStream_t stream) {
    Impl& impl = *impl_;
    if (impl.poisoned) {
        throw std::runtime_error("evictable KV pool is poisoned by a failed return");
    }
    if (!impl.lent.empty()) { throw std::logic_error("evictable KV lease is already open"); }
    if (granules.empty()) { throw std::invalid_argument("evictable KV lease needs a granule"); }
    if (granules.size() * impl.granularity > impl.window_reserved) {
        throw std::invalid_argument("evictable KV lease exceeds the window capacity: " +
                                    std::to_string(granules.size()) + " granules");
    }
    for (std::size_t rank = 0; rank < granules.size(); ++rank) {
        if (granules[rank] >= impl.lendable_granules) {
            throw std::invalid_argument("evictable KV lease names a resident granule");
        }
        if (impl.released[granules[rank]]) {
            throw std::invalid_argument("evictable KV lease names a released granule");
        }
        if (rank != 0 && granules[rank] <= granules[rank - 1]) {
            throw std::invalid_argument("evictable KV lease granules must strictly increase");
        }
    }
    // No stream is quiesced here, and that is the point of this pool: a lent granule lies
    // entirely inside free KV pages, so no in-flight kernel reads or writes it and other lanes
    // keep running while the window is open.
    const auto start = Clock::now();
    // Reserved up front so no push_back below can throw between a piece's two mappings.
    impl.lent.reserve(granules.size());
    // A piece is homeless between its home unmap and its overlay mapping, and the lease as a whole
    // is half-applied until the last piece lands. Neither state may survive a failure: the window
    // never opens, so nothing else would ever put those granules back.
    std::size_t rank = 0;
    bool homeless    = false;
    try {
        for (; rank < granules.size(); ++rank) {
            const std::size_t piece = granules[rank];
            impl.check_fault(rank, LeaseFault::Unmap);
            NINFER_CU_CHECK(cuMemUnmap(impl.home + impl.offsets[piece], impl.sizes[piece]));
            homeless = true;
            impl.map_overlay(piece, rank);
            impl.lent.push_back(piece);
            homeless = false;
        }
    } catch (...) {
        impl.unwind_lease(granules, rank, homeless);
        throw;
    }
    return Transaction(*this,
                       DeviceSpan{reinterpret_cast<void*>(impl.overlay),
                                  granules.size() * impl.granularity},
                       stream, seconds_since(start));
}

void EvictableKVPool::release_granules(std::span<const std::size_t> granules) {
    Impl& impl = *impl_;
    if (!impl.backed || !impl.lent.empty() || impl.poisoned) {
        throw std::logic_error("evictable KV granules can be released only from a resident pool");
    }
    for (const std::size_t granule : granules) {
        if (granule >= impl.lendable_granules || impl.released[granule]) {
            throw std::invalid_argument("evictable KV release names a resident or released granule");
        }
    }
    for (const std::size_t granule : granules) {
        NINFER_CU_CHECK(cuMemUnmap(impl.home + impl.offsets[granule], impl.sizes[granule]));
        NINFER_CU_CHECK(cuMemRelease(impl.handles[granule]));
        impl.handles[granule]  = {};
        impl.released[granule] = 1;
        ++impl.released_count;
    }
}

void EvictableKVPool::restore_granules(std::span<const std::size_t> granules) {
    Impl& impl = *impl_;
    for (const std::size_t granule : granules) {
        if (granule >= impl.lendable_granules || !impl.released[granule]) {
            throw std::invalid_argument("evictable KV restore names a granule that is not released");
        }
    }
    std::size_t created = 0;
    try {
        for (; created < granules.size(); ++created) {
            const std::size_t piece = granules[created];
            impl.handles[piece] = vmm::create(impl.sizes[piece], impl.device.device);
            try {
                impl.map_home(piece);
            } catch (...) {
                (void)cuMemRelease(impl.handles[piece]);
                impl.handles[piece] = {};
                throw;
            }
        }
    } catch (...) {
        for (std::size_t done = 0; done < created; ++done) {
            const std::size_t piece = granules[done];
            (void)cuMemUnmap(impl.home + impl.offsets[piece], impl.sizes[piece]);
            (void)cuMemRelease(impl.handles[piece]);
            impl.handles[piece] = {};
        }
        throw;
    }
    for (const std::size_t granule : granules) { impl.released[granule] = 0; }
    impl.released_count -= granules.size();
}

std::size_t EvictableKVPool::released_granules() const noexcept { return impl_->released_count; }

bool EvictableKVPool::granule_released(std::size_t granule) const noexcept {
    return granule < impl_->lendable_granules && impl_->released[granule] != 0;
}

void EvictableKVPool::inject_lease_fault(std::size_t rank, LeaseFault stage) noexcept {
    impl_->fault      = stage;
    impl_->fault_rank = rank;
}

void EvictableKVPool::give_back(Transaction& transaction) noexcept {
    Impl& impl = *impl_;
    if (impl.lent.empty()) { return; }
    const auto start = Clock::now();
    try {
        for (std::size_t rank = 0; rank < impl.lent.size(); ++rank) {
            NINFER_CU_CHECK(cuMemUnmap(impl.overlay + rank * impl.granularity, impl.granularity));
            impl.map_home(impl.lent[rank]);
        }
    } catch (const std::exception& error) {
        impl.poisoned = true;
        std::fprintf(stderr,
                     "ninfer: evictable KV pool return failed (%s); the KV cache is no longer "
                     "trustworthy\n",
                     error.what());
    } catch (...) {
        impl.poisoned = true;
        std::fprintf(stderr, "ninfer: evictable KV pool return failed; the KV cache is no longer "
                             "trustworthy\n");
    }
    impl.lent.clear();
    transaction.stats_.return_seconds = seconds_since(start);
}

EvictableKVPool::Transaction::Transaction(EvictableKVPool& pool, DeviceSpan leased,
                                          cudaStream_t stream, double lease_seconds) noexcept
    : pool_(&pool), leased_(leased), stream_(stream) {
    stats_.lease_seconds = lease_seconds;
    stats_.mapped_bytes  = leased.bytes;
}

EvictableKVPool::Transaction::~Transaction() { close(); }

EvictableKVPool::Transaction::Transaction(Transaction&& other) noexcept
    : pool_(other.pool_), leased_(other.leased_), stream_(other.stream_), stats_(other.stats_) {
    other.pool_ = nullptr;
}

EvictableKVPool::Transaction&
EvictableKVPool::Transaction::operator=(Transaction&& other) noexcept {
    if (this != &other) {
        close();
        pool_       = other.pool_;
        leased_     = other.leased_;
        stream_     = other.stream_;
        stats_      = other.stats_;
        other.pool_ = nullptr;
    }
    return *this;
}

void EvictableKVPool::Transaction::close() noexcept {
    if (pool_ == nullptr) { return; }
    pool_->give_back(*this);
    pool_ = nullptr;
}

} // namespace ninfer
