#!/usr/bin/env bash
# ------------------------------------------------------------------------------------------------
# Serve a model on one RTX 3090.
#
#   run.sh <model> [profile]
#
#   model             profiles
#   qwen38-27b        tuned (default), int8, c8   <- recommended
#   qwen36-35b-a3b    tuned (default)
#
# `tuned` is the recommended profile: rk4v4 KV, speculation plus the draft head, the memory flags,
# vision in overlay residency, and the tuned context cache with automatic prefix grid. `int8` and
# `c8` are the older reference profiles for the 27B -- one user at 64K of INT8 KV (the quality
# default), and eight lanes at 8K -- with every serving flag fixed.
#
# Every measurement behind these defaults, the memory model, and the reasoning for each flag are
# in docs/maintainer/launcher-profiles.md. What follows is what you need to run it.
#
# QWEN3.8-27B, `tuned`: two flag sets, each measured (docs/maintainer/launcher-profiles.md),
# chosen with NINFER_SPEC. The default is the fast one.
#
#   NINFER_SPEC=dflash2 (default): fastest at one stream, the full 262,144-token context headless
#
#     --spec dflash2 --draft-tokens 7 --lm-head-draft \
#     --prefill-cublas --prefill-chunk 4096 \
#     --kv-dtype rk4v4 --embedding-q4 --gdn-state-fp16 \
#     --vision --vision-residency overlay
#
#   NINFER_SPEC=mtp: the full context, two lanes sharing it, still fast
#
#     --spec mtp --draft-tokens 3 --lm-head-draft \
#     --prefill-cublas --prefill-chunk 2048 \
#     --kv-dtype rk4v4 --embedding-q4 --lm-head-q6 --gdn-state-fp16 \
#     --vision --vision-residency overlay
#
#   MTP accepts NINFER_DRAFT_TOKENS up to 15. Three suits chat and prose; for coding work that
#   returns edited files, 11-15 decodes up to 1.85x faster (docs/performance.md has the table).
#
# rk4v4 KV (Lloyd-Max 4-bit keys) is 31% smaller than rk8v4 at the same decode speed, for +0.10%
# perplexity over it. Measured beside a desktop on an RTX 3090 (2026-09-24), the DFlash2 set starts
# at up to 180,224 tokens and needs about 1.45 GB more for 262,144 -- roughly what a headless card
# gets back -- so the full context below is the headless extrapolation, and the step-down catches
# a card that falls short. The mtp set starts at 262,144 with two lanes even beside a desktop.
# `none` is the mtp set without speculation.
# The qwen3_8_27b.ninfer that download-model.sh fetches is the DFlash2 bundle and carries the MTP
# weights too, so one file serves both.
#
# IF THE CARD IS BUSY. A desktop (or another job) holding VRAM can leave too little for the default
# context. When the `tuned` profile is refused at startup for lack of GPU memory, this launcher steps
# down on its own -- an eighth of the context at a time, up to five times, from the second step with a 2048 prefill chunk
# and fewer host state slots -- and says what it did, so the first run starts instead of ending in an
# error. It
# only does that for the defaults: an explicit NINFER_CONTEXT, NINFER_PREFILL_CHUNK,
# NINFER_HOST_STATE_SLOTS or NINFER_KV_CAPACITY is honoured as given and fails loudly, and
# NINFER_FALLBACK=off turns the step-down off.
#
# OVERRIDES, from the environment. All profiles: NINFER_MODEL (artifact path), NINFER_MODEL_DIR,
# NINFER_SERVER, NINFER_HOST, NINFER_PORT, NINFER_CHAT_TEMPLATE (path to a local Jinja file, passed
# straight to --chat-template; overrides the artifact's built-in template), NINFER_GRAFT_DIR,
# NINFER_GRAFTS (off), NINFER_DEFAULT_GRAFT (see PROMPT GRAFTS below). `tuned` also:
# NINFER_CONTEXT, NINFER_CONCURRENCY,
# NINFER_KV_CAPACITY, NINFER_KV_DTYPE, NINFER_SPEC, NINFER_DRAFT_TOKENS, NINFER_PREFILL_CHUNK,
# NINFER_VISION (on|off), NINFER_VISION_RESIDENCY, NINFER_HOST_STATE_SLOTS. Each spec's defaults (context, lanes, chunk)
# are the ones that fit; the context figures below are extrapolated for a headless card, so treat
# the first start as the confirmation and drop a rung if it refuses:
# 229376 / 212992 / 196608 / 163840 / 131072 / 114688 / 98304 / 65536.
#
# PROMPT GRAFTS are optional and never shipped: nothing here needs one to start. Every NAME.bin with
# its NAME.json sidecar in grafts/<model>/ (beside models/, or NINFER_GRAFT_DIR) is loaded as
# --graft NAME=<file>, and a request selects it with "graft": "NAME" (docs/serving.md). No
# directory or an empty one serves without grafts. NINFER_GRAFTS=off skips them;
# NINFER_DEFAULT_GRAFT=NAME applies one to every request that names none.
# ------------------------------------------------------------------------------------------------
set -euo pipefail

usage() {
  printf 'usage: %s <model> [profile]\n' "${0##*/}"
  printf '  qwen38-27b       tuned (default), int8, c8   (recommended)\n'
  printf '  qwen36-35b-a3b   tuned (default)\n'
}

model_key="${1:-}"
profile="${2:-tuned}"
case "$model_key" in
  -h|--help) usage; exit 0 ;;
  qwen38-27b)     artifact='qwen3_8_27b.ninfer';     title='Qwen3.8-27B' ;;
  qwen36-35b-a3b) artifact='qwen3_6_35b_a3b.ninfer'; title='Qwen3.6-35B-A3B' ;;
  '') usage >&2; exit 2 ;;
  *) printf 'Unknown model: %s\n' "$model_key" >&2; usage >&2; exit 2 ;;
esac

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
root="$(cd -- "$script_dir/.." && pwd)"
# Two layouts reach this script: a checkout, where the artifacts sit in the repository's own
# models/ directory beside build-linux/, and an unpacked release archive, where the launcher
# sits next to ninfer-serve and models/. Probe for the checkout first, then the archive -- the
# same order the server lookup below uses.
#
# An explicit NINFER_MODEL_DIR is taken verbatim and never probed. Falling back past a
# directory the caller named turns their typo into a 'Missing model' error about a path they
# never mentioned, which is worse than failing on the one they did.
if [[ -n "${NINFER_MODEL_DIR:-}" ]]; then
  model_dir="$NINFER_MODEL_DIR"
else
  # Test for the artifact, not merely for a models/ directory. An archive unpacked below a
  # directory that happens to have its own models/ would otherwise stop at the parent and
  # never look beside the launcher, failing while its own artifact sits right there.
  model_dir="$root/models"
  [[ -f "$model_dir/$artifact" ]] || model_dir="$script_dir/models"
fi
MODEL="${NINFER_MODEL:-$model_dir/$artifact}"
HOST="${NINFER_HOST:-127.0.0.1}"
PORT="${NINFER_PORT:-8080}"

server="${NINFER_SERVER:-$root/build-linux/apps/ninfer-serve}"
# Same two layouts as the artifact lookup above: build tree in a checkout, then the archive
# root, where this launcher sits beside the binary.
[[ -x "$server" ]] || server="$script_dir/ninfer-serve"

# The profile fixes the whole serving shape. `label` is the banner; `profile_args` is everything
# after --host/--port.
label=''
profile_args=()
case "$model_key/$profile" in
  qwen38-27b/tuned)
    # The speculative backend fixes everything that has to move with it: the prefill chunk (the
    # cuBLAS route's workspace scales with it), the context and lanes that fit, and --lm-head-q6,
    # which DFlash and DFlash2 refuse.
    SPEC="${NINFER_SPEC:-dflash2}"
    case "$SPEC" in
      dflash2)
        spec_args=(--spec dflash2 --draft-tokens "${NINFER_DRAFT_TOKENS:-7}" --lm-head-draft)
        memory_args=()
        default_context=262144; default_concurrency=1; default_chunk=4096
        spec_label="DFlash2 K=${NINFER_DRAFT_TOKENS:-7} + draft head" ;;
      mtp)
        spec_args=(--spec mtp --draft-tokens "${NINFER_DRAFT_TOKENS:-3}" --lm-head-draft)
        memory_args=(--lm-head-q6)
        default_context=262144; default_concurrency=2; default_chunk=2048
        spec_label="MTP${NINFER_DRAFT_TOKENS:-3} + draft head, Q6 head, two lanes" ;;
      none)
        spec_args=()
        memory_args=()
        default_context=262144; default_concurrency=2; default_chunk=2048
        spec_label='no speculation' ;;
      *) printf 'NINFER_SPEC must be dflash2, mtp or none, got %s\n' "$SPEC" >&2; exit 2 ;;
    esac
    CONTEXT="${NINFER_CONTEXT:-$default_context}"
    CONCURRENCY="${NINFER_CONCURRENCY:-$default_concurrency}"
    KV_CAPACITY="${NINFER_KV_CAPACITY:-$CONTEXT}"
    KV_DTYPE="${NINFER_KV_DTYPE:-rk4v4}"
    PREFILL_CHUNK="${NINFER_PREFILL_CHUNK:-$default_chunk}"
    profile_args=(
      --max-concurrency "$CONCURRENCY" --max-context "$CONTEXT" --kv-capacity "$KV_CAPACITY"
      --kv-dtype "$KV_DTYPE"
      ${spec_args[@]+"${spec_args[@]}"}
      --embedding-q4 ${memory_args[@]+"${memory_args[@]}"} --gdn-state-fp16
      --prefill-cublas --prefill-chunk "$PREFILL_CHUNK"
    )
    label="C$CONCURRENCY  |  context $CONTEXT  |  KV pool $KV_CAPACITY  |  $KV_DTYPE  |  $spec_label"
    prefill_note="Prefill: cuBLAS route, chunk $PREFILL_CHUNK"
    if [[ "$SPEC" == 'dflash2' ]]; then
      hint="Need a second lane?  NINFER_SPEC=mtp ${0##*/} $model_key  (slower decode)"
    fi ;;

  qwen36-35b-a3b/tuned)
    SPEC="${NINFER_SPEC:-mtp}"
    case "$SPEC" in
      mtp)  spec_args=(--spec mtp --draft-tokens "${NINFER_DRAFT_TOKENS:-3}" --lm-head-draft --mtp-experts-q4)
            spec_label="MTP${NINFER_DRAFT_TOKENS:-3} + draft head" ;;
      none) spec_args=(); spec_label='no speculation' ;;
      *) printf 'NINFER_SPEC must be mtp or none, got %s\n' "$SPEC" >&2; exit 2 ;;
    esac
    # rk4v4 fits three lanes at the full context even beside a desktop (2026-09-24; four fall 48 MB
    # short there, so a headless card may take NINFER_CONCURRENCY=4). Lanes share the one
    # --kv-capacity pool: any request may use all of it, but not every lane at once.
    CONTEXT="${NINFER_CONTEXT:-262144}"
    CONCURRENCY="${NINFER_CONCURRENCY:-3}"
    KV_CAPACITY="${NINFER_KV_CAPACITY:-$CONTEXT}"
    KV_DTYPE="${NINFER_KV_DTYPE:-rk4v4}"
    PREFILL_CHUNK="${NINFER_PREFILL_CHUNK:-512}"
    profile_args=(
      --max-concurrency "$CONCURRENCY" --max-context "$CONTEXT" --kv-capacity "$KV_CAPACITY"
      --kv-dtype "$KV_DTYPE"
      ${spec_args[@]+"${spec_args[@]}"}
      --gdn-state-fp16 --prefill-chunk "$PREFILL_CHUNK"
    )
    label="C$CONCURRENCY  |  context $CONTEXT  |  KV pool $KV_CAPACITY  |  $KV_DTYPE  |  $spec_label" ;;

  qwen38-27b/int8)
    profile_args=(
      --max-context 65536 --kv-capacity 65536
      --max-concurrency 1 --max-pending-requests 16 --pending-timeout-ms 600000
      --prefill-chunk 1024 --kv-dtype int8
      --spec mtp --draft-tokens 3 --lm-head-draft
    )
    label='one request  |  64K context  |  INT8 KV  |  MTP3, ReplaySSM' ;;

  qwen38-27b/c8)
    # Context cache sized per lane, so several agents rotating through the lanes find their own
    # conversation still cached instead of re-prefilling it: two retained conversations per lane,
    # one checkpoint StateImage per lane on the card beyond the active ones, and two per lane in
    # pinned host memory. Measured at one lane on the default of two retained conversations, four
    # rotating agents reused 12% of their prompts (TTFT 14 s); with room for all of them, 76% (2.9 s).
    # MEMORY COST: this profile keeps the GDN state in BF16, so a StateImage is 147 MiB. The device
    # slots take 8 x 147 MiB = 1.15 GiB of VRAM, the engine default at eight lanes, so that is
    # unchanged; the host slots pin 16 x 147 MiB = 2.3 GiB of RAM. Retention is still bounded by the
    # 16,384-token KV pool.
    c8_lanes=8
    c8_host_states_per_lane=2
    profile_args=(
      --max-context 8192 --kv-capacity 16384
      --max-concurrency "$c8_lanes" --max-pending-requests 32 --pending-timeout-ms 600000
      --prefill-chunk 512 --kv-dtype int8
      --spec mtp --draft-tokens 3 --lm-head-draft
      --max-private-continuations "$((c8_lanes * 2))" --device-state-slots "$c8_lanes"
      --host-state-slots "$((c8_lanes * c8_host_states_per_lane))"
    )
    label='up to eight requests  |  8K context  |  INT8 KV  |  MTP3, ReplaySSM' ;;

  *)
    printf 'Model %s has no profile %s\n' "$model_key" "$profile" >&2
    usage >&2
    exit 2 ;;
esac

# Only `tuned` carries the context cache and vision: the reference profiles are deliberately
# minimal. Vision stays on there -- overlay residency keeps the tower host-pinned and streams each
# image through a borrowed device window, so it costs about 10 MiB of runtime reservation.
if [[ "$profile" == 'tuned' ]]; then
  VISION="${NINFER_VISION:-on}"
  case "$VISION" in
    on)  vision_args=(--vision --vision-residency "${NINFER_VISION_RESIDENCY:-overlay}")
         vision_label="vision (${NINFER_VISION_RESIDENCY:-overlay})" ;;
    off) vision_args=(); vision_label='text only' ;;
    *) printf 'NINFER_VISION must be on or off, got %s\n' "$VISION" >&2; exit 2 ;;
  esac
  label="$label  |  $vision_label"
  # Pinned host memory for the context cache: 74.5 MiB per slot on the 27B. Free on Linux; on Windows
  # WDDM charges it against the card, so a busy desktop needs fewer (see the README on startup).
  # --max-private-continuations 8 below is what keeps several rotating conversations cached: the
  # engine default is two per lane, and four agents on one lane then evict each other on every turn
  # (12% prompt reuse against 76% with room for all four, measured 2026-09-28). A retained
  # conversation costs no memory by itself; its KV pages and StateImages come from the pools above.
  HOST_STATE_SLOTS="${NINFER_HOST_STATE_SLOTS:-32}"
  profile_args+=(
    --max-pending-requests 16 --pending-timeout-ms 600000
    ${vision_args[@]+"${vision_args[@]}"}
    --max-private-continuations 8 --max-shared-prefixes 8 --host-state-slots "$HOST_STATE_SLOTS"
    --host-kv-mib 8192
    --auto-prefix-grid
  )
fi

if [[ -n "${NINFER_CHAT_TEMPLATE:-}" ]]; then
  profile_args+=(--chat-template "$NINFER_CHAT_TEMPLATE")
fi

# Same two layouts as models/: the checkout's grafts/ first, then the one beside the launcher.
graft_dir="${NINFER_GRAFT_DIR:-$root/grafts/$model_key}"
[[ -n "${NINFER_GRAFT_DIR:-}" || -d "$graft_dir" ]] || graft_dir="$script_dir/grafts/$model_key"
graft_names=()
if [[ "${NINFER_GRAFTS:-on}" != 'off' && -d "$graft_dir" ]]; then
  for graft in "$graft_dir"/*.bin; do
    [[ -f "$graft" && -f "${graft%.bin}.json" ]] || continue
    name="$(basename -- "$graft" .bin)"
    graft_names+=("$name")
    profile_args+=(--graft "$name=$graft")
  done
fi
if [[ -n "${NINFER_DEFAULT_GRAFT:-}" && "${NINFER_GRAFTS:-on}" != 'off' ]]; then
  if [[ " ${graft_names[*]-} " != *" $NINFER_DEFAULT_GRAFT "* ]]; then
    printf 'NINFER_DEFAULT_GRAFT=%s names no graft in %s\n' "$NINFER_DEFAULT_GRAFT" "$graft_dir" >&2
    exit 2
  fi
  profile_args+=(--default-graft "$NINFER_DEFAULT_GRAFT")
fi

if [[ ! -x "$server" ]]; then
  printf 'Missing ninfer-serve (looked for %s)\n' "$server" >&2
  printf 'Build it first:  ./scripts/build.sh\n' >&2
  exit 1
fi
if [[ ! -f "$MODEL" ]]; then
  printf 'Missing model: %s\n' "$MODEL" >&2
  printf 'Download it first:  ./download-model.sh %s\n' "$model_key" >&2
  exit 1
fi

printf '%s  |  %s\n' "$title" "$label"
[[ -z "${prefill_note:-}" ]] || printf '%s\n' "$prefill_note"
if [[ "$profile" == 'tuned' ]]; then
  printf 'Cache: 8 shared / 8 private / %s host states  |  automatic prefix grid on\n' "$HOST_STATE_SLOTS"
fi
[[ -z "${NINFER_CHAT_TEMPLATE:-}" ]] || printf 'Chat template: %s\n' "$NINFER_CHAT_TEMPLATE"
(( ${#graft_names[@]} == 0 )) || printf 'Grafts: %s%s\n' "${graft_names[*]}" \
  "${NINFER_DEFAULT_GRAFT:+ (default $NINFER_DEFAULT_GRAFT)}"
[[ -z "${hint:-}" ]] || printf '%s\n' "$hint"
printf 'API: http://%s:%s/v1\n\n' "$HOST" "$PORT"

# Step-down eligibility. Only the defaults of the tuned profile may be second-guessed; a value the
# caller chose is theirs. A step-down pass is a re-run of this script with the overrides below set,
# marked by NINFER_FALLBACK_RUNG, so the settings are rebuilt by the same code as a first run.
ladder=0
if [[ "$profile" == 'tuned' && "${NINFER_FALLBACK:-on}" != 'off' ]]; then
  if [[ -n "${NINFER_FALLBACK_RUNG:-}" ]]; then
    ladder=1
  elif [[ -z "${NINFER_CONTEXT:-}${NINFER_PREFILL_CHUNK:-}${NINFER_HOST_STATE_SLOTS:-}${NINFER_KV_CAPACITY:-}" ]]; then
    ladder=1
  fi
fi

# --host-kv-mib 8192 is honoured in full here: on Linux this really does pin 8 GiB of host RAM, and
# it is host RAM, not device memory. run.bat passes the same number and gets far less -- WDDM
# charges a pinned host allocation against the card, so the runtime clamps to
# (free VRAM - 1 GiB) / 2. See docs/maintainer/launcher-profiles.md.
if (( ! ladder )); then
  exec "$server" "$MODEL" --host "$HOST" --port "$PORT" "${profile_args[@]}"
fi

# Run the server with its output shown and kept, so a refusal for lack of memory can be told apart
# from any other failure. Only that failure steps down; a crash or a bad artifact does not.
rung="${NINFER_FALLBACK_RUNG:-0}"
base_context="${NINFER_FALLBACK_BASE_CONTEXT:-$CONTEXT}"
base_chunk="${NINFER_FALLBACK_BASE_CHUNK:-$PREFILL_CHUNK}"
base_slots="${NINFER_FALLBACK_BASE_SLOTS:-$HOST_STATE_SLOTS}"
server_log="$(mktemp)"
server_pipe="$server_log.pipe"
mkfifo -- "$server_pipe"
trap 'rm -f -- "$server_log" "$server_pipe"' EXIT
# The server runs as a child rather than in place of this script, so its output can be read back
# after it exits -- and a child does not get the signals sent to this script. Pass the stop
# requests on: SIGTERM, which `docker stop` sends to this script (a container runs it as PID 1, and
# PID 1 ignores a signal it does not handle), and a SIGINT that did not come from a terminal. A
# terminal's Ctrl+C already reaches the whole process group, the server included; passing it on
# again would count as the confirming second press.
tee -- "$server_log" < "$server_pipe" &
tee_pid=$!
"$server" "$MODEL" --host "$HOST" --port "$PORT" "${profile_args[@]}" > "$server_pipe" 2>&1 &
server_pid=$!
trap 'kill -TERM "$server_pid" 2>/dev/null || true' TERM
if [[ -t 0 ]]; then
  trap ':' INT
else
  trap 'kill -INT "$server_pid" 2>/dev/null || true' INT
fi
set +e
wait "$server_pid"; status=$?
# A handled signal ends the wait early, with the server still stopping; wait until it has.
while kill -0 "$server_pid" 2>/dev/null; do wait "$server_pid"; status=$?; done
wait "$tee_pid"
set -e
trap - TERM INT
if (( status != 0 && rung < 5 )) &&
   grep -q -E 'runtime reservation requires|cudaMallocHost failed' "$server_log"; then
  next=$((rung + 1))
  next_context=$(( base_context * (8 - next) / 8 / 1024 * 1024 ))
  # The first step trims context only: an eighth of it frees more than a card that just misses
  # needs, and prefill speed and cached prefixes are worth keeping. Later steps also give up the
  # wider prefill chunk and halve the host state slots every other step.
  next_chunk=$base_chunk
  (( next < 2 || base_chunk <= 2048 )) || next_chunk=2048
  next_slots=$(( base_slots >> (next / 2) ))
  printf '\nNot enough free GPU memory to start at context %s. Retrying at %s (prefill chunk %s, %s host state slots).\n' \
    "$CONTEXT" "$next_context" "$next_chunk" "$next_slots"
  printf 'Set NINFER_CONTEXT to choose your own, or NINFER_FALLBACK=off to fail instead.\n\n'
  rm -f -- "$server_log" "$server_pipe"
  exec env NINFER_CONTEXT="$next_context" NINFER_PREFILL_CHUNK="$next_chunk" \
    NINFER_HOST_STATE_SLOTS="$next_slots" NINFER_FALLBACK_RUNG="$next" \
    NINFER_FALLBACK_BASE_CONTEXT="$base_context" NINFER_FALLBACK_BASE_CHUNK="$base_chunk" \
    NINFER_FALLBACK_BASE_SLOTS="$base_slots" "$0" "$@"
fi
exit "$status"
