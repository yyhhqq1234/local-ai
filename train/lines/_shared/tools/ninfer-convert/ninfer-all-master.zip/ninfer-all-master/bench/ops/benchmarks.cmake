ninfer_add_op_bench(ninfer_silu_mul_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/silu_mul_bench.cu")
ninfer_add_op_bench(ninfer_residual_add_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/residual_add_bench.cu")
ninfer_add_op_bench(ninfer_sigmoid_mul_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/sigmoid_mul_bench.cu")
ninfer_add_op_bench(ninfer_rmsnorm_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/rmsnorm_bench.cu")
ninfer_add_op_bench(ninfer_rmsnorm_pack_tail_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/rmsnorm_pack_tail_bench.cu")
ninfer_add_op_bench(ninfer_l2norm_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/l2norm_bench.cu")
ninfer_add_op_bench(ninfer_gdn_gating_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/gdn_gating_bench.cu")
ninfer_add_op_bench(ninfer_gdn_gating_proj_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/gdn_gating_proj_bench.cu")
ninfer_add_op_bench(ninfer_dynamic_grouped_conv_prepare_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/dynamic_grouped_conv_prepare_bench.cu")
ninfer_add_op_bench(ninfer_linear_dynamic_grouped_conv_add_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/linear_dynamic_grouped_conv_add_bench.cu")
ninfer_add_op_bench(ninfer_gated_delta_net_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/gated_delta_net_bench.cu")
ninfer_add_op_bench(ninfer_gdn_replay_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/gdn_replay_bench.cu")
ninfer_add_op_bench(ninfer_rope_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/rope_bench.cu")
ninfer_add_op_bench(ninfer_rmsnorm_rope_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/rmsnorm_rope_bench.cu")
ninfer_add_op_bench(ninfer_add_bias_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/add_bias_bench.cu")
ninfer_add_op_bench(ninfer_gelu_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/gelu_bench.cu")
ninfer_add_op_bench(ninfer_layer_norm_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/layer_norm_bench.cu")
ninfer_add_op_bench(ninfer_vision_pos_embed_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/vision_pos_embed_bench.cu")
ninfer_add_op_bench(ninfer_scatter_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/scatter_bench.cu")
ninfer_add_op_bench(ninfer_scatter_bf16_batch_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/scatter_bf16_batch_bench.cu")
ninfer_add_op_bench(ninfer_packed_softmax_attention_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/packed_softmax_attention_bench.cu")
ninfer_add_op_bench(ninfer_prepare_ragged_prefix_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/prepare_ragged_prefix_bench.cu")
ninfer_add_op_bench(ninfer_embedding_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/embedding_bench.cu")
ninfer_add_op_bench(ninfer_position_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/position_bench.cu")
ninfer_add_op_bench(ninfer_cast_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/cast_bench.cu")
ninfer_add_op_bench(ninfer_argmax_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/argmax_bench.cu")
ninfer_add_op_bench(ninfer_hyper_connection_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/hyper_connection_bench.cu")
ninfer_add_op_bench(ninfer_qsa_indexer_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/qsa_indexer_bench.cu")
ninfer_add_op_bench(ninfer_causal_conv1d_silu_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/causal_conv1d_silu_bench.cu")
ninfer_add_op_bench(ninfer_linear_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/linear_bench.cu")
ninfer_add_op_bench(ninfer_linear_schedule_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/linear_schedule_bench.cu")
ninfer_add_op_bench(ninfer_linear_topk_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/linear_topk_bench.cu")
ninfer_add_op_bench(ninfer_candidate_selector_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/candidate_selector_bench.cu")
ninfer_add_op_bench(ninfer_gdn_input_proj_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/gdn_input_proj_bench.cu")
ninfer_add_op_bench(ninfer_gdn_input_proj_conv_snapshot_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/gdn_input_proj_conv_snapshot_bench.cu")
ninfer_add_op_bench(ninfer_q4_q5_gdn_input_schedule_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/q4_q5_gdn_input_schedule_bench.cu")
ninfer_add_op_bench(ninfer_attn_input_proj_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/attn_input_proj_bench.cu")
ninfer_add_op_bench(ninfer_q4_q5_attn_input_schedule_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/q4_q5_attn_input_schedule_bench.cu")
ninfer_add_op_bench(ninfer_q8_linear_swiglu_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/q8_linear_swiglu_bench.cu")
ninfer_add_op_bench(ninfer_nvfp4_linear_swiglu_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/nvfp4_linear_swiglu_bench.cu")
ninfer_add_op_bench(ninfer_fp8_linear_swiglu_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/fp8_linear_swiglu_bench.cu")
ninfer_add_op_bench(ninfer_q4_linear_swiglu_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/q4_linear_swiglu_bench.cu")
ninfer_add_op_bench(ninfer_q4_linear_swiglu_schedule_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/q4_linear_swiglu_schedule_bench.cu")
ninfer_add_op_bench(ninfer_q8_linear_add_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/q8_linear_add_bench.cu")
ninfer_add_op_bench(ninfer_q5_linear_add_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/q5_linear_add_bench.cu")
ninfer_add_op_bench(ninfer_q5_linear_add_schedule_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/q5_linear_add_schedule_bench.cu")
ninfer_add_op_bench(ninfer_dense_linear_add_schedule_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/dense_linear_add_schedule_bench.cu")
ninfer_add_op_bench(ninfer_a8_prefill_schedule_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/a8_prefill_schedule_bench.cu")
# --panel applies the load-time weight permute, so this bench needs the artifact side of it.
target_link_libraries(ninfer_a8_prefill_schedule_bench PRIVATE ninfer_artifact)
ninfer_add_op_bench(ninfer_q8_dflash2_schedule_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/q8_dflash2_schedule_bench.cu")
ninfer_add_op_bench(ninfer_q8_pair_schedule_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/q8_pair_schedule_bench.cu")
ninfer_add_op_bench(ninfer_bf16_linear_add_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/bf16_linear_add_bench.cu")
ninfer_add_op_bench(ninfer_nvfp4_linear_add_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/nvfp4_linear_add_bench.cu")
ninfer_add_op_bench(ninfer_fp8_linear_add_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/fp8_linear_add_bench.cu")
ninfer_add_op_bench(ninfer_causal_softmax_attention_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/causal_softmax_attention_bench.cu")
ninfer_add_op_bench(ninfer_context_softmax_attention_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/context_softmax_attention_bench.cu")
ninfer_add_op_bench(ninfer_sliding_window_attention_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/sliding_window_attention_bench.cu")
ninfer_add_op_bench(ninfer_kv_cache_append_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/kv_cache_append_bench.cu")
ninfer_add_op_bench(ninfer_prepare_masked_block_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/prepare_masked_block_bench.cu")
ninfer_add_op_bench(ninfer_sampling_select_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/sampling_select_bench.cu")
ninfer_add_op_bench(ninfer_sparse_moe_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/sparse_moe_bench.cu")
ninfer_add_op_bench(ninfer_q2_gpu_probe SOURCES "${CMAKE_CURRENT_LIST_DIR}/q2_gpu_probe.cpp")
ninfer_add_op_bench(ninfer_linear_pair_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/linear_pair_bench.cu")
ninfer_add_op_bench(ninfer_context_kv_materialize_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/context_kv_materialize_bench.cu")
ninfer_add_op_bench(ninfer_mtp_pack_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/mtp_pack_bench.cu")
ninfer_add_op_bench(ninfer_proposal_remap_bench SOURCES "${CMAKE_CURRENT_LIST_DIR}/proposal_remap_bench.cu")

# The opt-in cuBLAS prefill route against the integer-activation route it would replace.
ninfer_add_op_bench(ninfer_w4_cublas_prefill_bench
  SOURCES "${CMAKE_CURRENT_LIST_DIR}/w4_cublas_prefill_bench.cu")
