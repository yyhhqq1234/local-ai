#include "ninfer_build_id.h"
#include "options.h"
#include "product/logging/engine_diagnostics.h"
#include "product/logging/logging.h"
#include "product/logging/pretty_format.h"
#include "product/logging/startup_log.h"
#include "product/log_colour/log_colour.h"
#include "product/prompt_input/prompt_input.h"
#include "product/speculative_options.h"

#include "ninfer/engine.h"

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <exception>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <string>
#include <string_view>

#include <spdlog/logger.h>

namespace {

std::string format_seconds(double seconds) {
    return ninfer::product::format_pretty_duration(seconds);
}

std::string format_rate(double tokens, double seconds) {
    if (tokens <= 0.0 || seconds <= 0.0) { return "n/a"; }
    return ninfer::product::format_pretty_rate(tokens / seconds, "tok");
}

std::string format_percent(std::uint64_t numerator, std::uint64_t denominator) {
    if (denominator == 0) { return "n/a"; }
    return ninfer::product::format_pretty_percent(static_cast<double>(numerator) /
                                                  static_cast<double>(denominator));
}

std::string format_bytes(std::uint64_t bytes) {
    return ninfer::product::format_pretty_bytes(bytes);
}

std::string format_arena_used(const ninfer::ArenaMemorySummary& arena) {
    return format_bytes(arena.used_bytes) + " / " + format_bytes(arena.capacity_bytes);
}

std::string format_arena_peak(const ninfer::ArenaMemorySummary& arena) {
    return format_bytes(arena.peak_used_bytes) + " / " + format_bytes(arena.capacity_bytes);
}

std::string format_sampling(const ninfer::ResolvedSamplingParameters& sampling) {
    if (sampling.temperature <= 0.0F) { return "greedy (temperature 0)"; }
    std::ostringstream output;
    output << std::fixed << std::setprecision(2) << "temp=" << sampling.temperature
           << " top_p=" << sampling.top_p << " top_k=" << sampling.top_k
           << " min_p=" << sampling.min_p << " presence=" << sampling.presence_penalty
           << " freq=" << sampling.frequency_penalty << " seed=" << sampling.seed;
    return output.str();
}

std::string format_finish(ninfer::FinishReason reason) {
    switch (reason) {
    case ninfer::FinishReason::None:
        return "none";
    case ninfer::FinishReason::OutputLimit:
        return "output-limit";
    case ninfer::FinishReason::ContextCapacity:
        return "context-capacity";
    case ninfer::FinishReason::StopToken:
        return "stop-token";
    case ninfer::FinishReason::StopString:
        return "stop-string";
    case ninfer::FinishReason::Cancelled:
        return "cancelled";
    }
    return "unknown";
}

std::string format_kv_cache(ninfer::KvCacheStorage storage) {
    switch (storage) {
    case ninfer::KvCacheStorage::BFloat16:
        return "bf16";
    case ninfer::KvCacheStorage::Int8Group64:
        return "int8-group64";
    case ninfer::KvCacheStorage::Fp8E4M3Row256:
        return "fp8-e4m3-row256";
    case ninfer::KvCacheStorage::RotatedInt8KeyInt4ValueGroup64:
        return "rotated-k8g64-v4g32";
    case ninfer::KvCacheStorage::RotatedLloyd4KeyInt4Value:
        return "rotated-lloyd4g64-v4g32";
    case ninfer::KvCacheStorage::RotatedInt4KeyInt4ValueE8:
        return "rotated-k4e8g64-v4g32";
    case ninfer::KvCacheStorage::RotatedE8RootKeyInt4Value:
        return "rotated-k2e8g64-v4g32";
    case ninfer::KvCacheStorage::Nvfp4Group16:
        return "nvfp4";
    case ninfer::KvCacheStorage::Fp8KeyNvfp4Value:
        return "k8v4";
    }
    return "unknown";
}

std::string format_kv_capacity_mode(ninfer::KvCapacityMode mode) {
    return mode == ninfer::KvCapacityMode::Automatic ? "auto" : "explicit";
}

// Stats colouring (stderr only). Each statistic gets a stable 256-colour ANSI
// colour keyed by its name (see product/log_colour), so it keeps the same
// colour on every line and can be tracked across the log as its value
// changes. --log-colours on turns it on; the output stays plain otherwise.
std::optional<bool> log_colours_flag; // set from --log-colours before any output

bool stats_color_enabled() {
    static const bool enabled = log_colours_flag.value_or(false);
    return enabled;
}

std::string colorize(std::string_view text, std::string_view key) {
    return ninfer::product::log_colour::colourize(text, key, stats_color_enabled());
}

void print_stage(std::string_view group, std::string_view detail, double seconds) {
    const std::string elapsed = format_seconds(seconds);
    std::cerr << std::left << std::setw(12) << group << colorize(detail, detail);
    const std::size_t detail_width = std::max<std::size_t>(detail.size(), 26);
    for (std::size_t i = detail.size(); i < detail_width; ++i) { std::cerr << ' '; }
    for (std::size_t i = elapsed.size(); i < std::max<std::size_t>(elapsed.size(), 12); ++i) {
        std::cerr << ' ';
    }
    std::cerr << colorize(elapsed, detail) << '\n';
}

void print_metric(std::string_view label, std::string_view value) {
    std::cerr << std::left << std::setw(12) << "summary" << colorize(label, label);
    const std::size_t label_width = std::max<std::size_t>(label.size(), 26);
    for (std::size_t i = label.size(); i < label_width; ++i) { std::cerr << ' '; }
    std::cerr << colorize(value, label) << '\n';
}

class StreamingSink final : public ninfer::OutputSink {
public:
    void start(ninfer::GenerationStart) override {}

    void progress(ninfer::PromptProgress) override {}

    void timing(ninfer::GenerationTimingObservation) override {}

    void publish(ninfer::OutputDelta delta) override {
        std::ostream& output =
            delta.channel == ninfer::OutputChannel::Reasoning ? std::cerr : std::cout;
        output << delta.text;
        output.flush();
        if (delta.channel == ninfer::OutputChannel::Reasoning) {
            reasoning_seen_ = reasoning_seen_ || !delta.text.empty();
            if (!delta.text.empty()) { reasoning_ends_in_newline_ = delta.text.back() == '\n'; }
        } else {
            content_seen_ = content_seen_ || !delta.text.empty();
            if (!delta.text.empty()) { content_ends_in_newline_ = delta.text.back() == '\n'; }
        }
    }

    void finish_streams(bool successful = true) {
        if (finished_) { return; }
        finished_ = true;
        if ((successful && !content_seen_) || (content_seen_ && !content_ends_in_newline_)) {
            std::cout << '\n';
        }
        std::cout.flush();
        if (reasoning_seen_ && !reasoning_ends_in_newline_) { std::cerr << '\n'; }
    }

private:
    bool content_seen_              = false;
    bool content_ends_in_newline_   = false;
    bool reasoning_seen_            = false;
    bool reasoning_ends_in_newline_ = false;
    bool finished_                  = false;
};

void print_generation_summary(const ninfer::GenerationResult& result,
                              const ninfer::ResolvedSamplingParameters& sampling,
                              const ninfer::MemorySummary& memory,
                              const ninfer::RuntimeStats& stats) {
    print_stage("prepare", "render/preprocess", result.timings.prepare_seconds);
    print_stage("generate", "vision", result.timings.vision_seconds);
    print_stage("generate", "text prefill", result.timings.prefill_seconds);
    print_stage("generate", "decode", result.timings.decode_seconds);
    print_stage("generate", "total", result.timings.total_seconds);

    const std::size_t generated = result.generated_token_ids.size();
    const std::size_t decoded   = generated == 0 ? 0 : generated - 1;
    const double model_seconds  = result.timings.vision_seconds + result.timings.prefill_seconds +
                                 result.timings.decode_seconds;
    print_metric("sampling", format_sampling(sampling));
    print_metric("finish reason", format_finish(result.finish_reason));
    print_metric("prompt tokens", std::to_string(result.prompt.prompt_tokens));
    print_metric("reused prompt tokens", std::to_string(result.reused_prompt_tokens));
    print_metric("generated tokens", std::to_string(generated));
    if (result.thinking.requested_budget) {
        print_metric("thinking budget", std::to_string(*result.thinking.requested_budget));
        if (result.thinking.effective_budget &&
            *result.thinking.effective_budget != *result.thinking.requested_budget) {
            print_metric("effective thinking budget",
                         std::to_string(*result.thinking.effective_budget));
        }
        print_metric("model thinking tokens",
                     std::to_string(result.thinking.model_thinking_tokens));
        print_metric("thinking control tokens", std::to_string(result.thinking.injected_tokens));
        print_metric("thinking control", result.thinking.applied ? "applied" : "not applied");
    }
    if (result.thinking.loop_detected) {
        print_metric(
            "reasoning loop",
            "after " + std::to_string(result.thinking.loop_thinking_tokens) + " thinking tokens (" +
                std::to_string(static_cast<int>(result.thinking.loop_coverage * 100.0F + 0.5F)) +
                "% repeated), " + (result.thinking.applied ? "concluded" : "stopped"));
    }
    print_metric("model elapsed", format_seconds(model_seconds));
    print_metric("prefill speed", format_rate(static_cast<double>(result.prompt.prompt_tokens),
                                              result.timings.prefill_seconds));
    print_metric("decode speed",
                 format_rate(static_cast<double>(decoded), result.timings.decode_seconds));
    print_metric("throughput (overall)",
                 format_rate(static_cast<double>(generated), model_seconds));

    const std::uint64_t reserved = static_cast<std::uint64_t>(memory.weights.capacity_bytes) +
                                   memory.runtime_reservation_bytes;
    print_metric("device", std::to_string(memory.device));
    print_metric("max context", std::to_string(memory.max_context));
    print_metric("KV capacity policy", format_kv_capacity_mode(memory.kv_capacity_mode));
    print_metric("KV capacity", std::to_string(memory.kv_capacity));
    print_metric("KV page groups", std::to_string(memory.kv_capacity_page_groups) + " / " +
                                       std::to_string(memory.kv_capacity_max_page_groups));
    print_metric("gpu weights used", format_arena_used(memory.weights));
    print_metric("gpu sequence used", format_arena_used(memory.sequence));
    print_metric("kv cache dtype", format_kv_cache(memory.kv_cache));
    print_metric("kv cache payload", format_bytes(memory.kv_payload_bytes));
    print_metric("gpu workspace peak", format_arena_peak(memory.workspace));
    print_metric("runtime reservation", format_bytes(memory.runtime_reservation_bytes));
    print_metric("free after weights", format_bytes(memory.available_after_weights_bytes));
    print_metric("free after startup", format_bytes(memory.available_after_startup_bytes));
    print_metric("KV capacity headroom", format_bytes(memory.kv_capacity_headroom_bytes));
    print_metric("planned slack", format_bytes(memory.planned_slack_bytes));
    print_metric("CUDA Graph allowance", format_bytes(memory.cuda_graph_allowance_bytes));
    print_metric("CUDA Graph used", memory.cuda_graph_measured_bytes
                                        ? format_bytes(*memory.cuda_graph_measured_bytes)
                                        : std::string("unmeasured (no free device memory left)"));
    print_metric("planned device total", format_bytes(reserved));
    if (memory.expert_cache_bytes != 0) {
        print_metric("gpu expert cache", format_bytes(memory.expert_cache_bytes));
    }
    // A pipeline: each device's own share, the primary device's repeated from above.
    for (const auto& stage : memory.devices) {
        const std::string gpu = "gpu " + std::to_string(stage.device) + " ";
        print_metric(gpu + "weights", format_arena_used(stage.weights));
        print_metric(gpu + "sequence", format_arena_used(stage.sequence));
        print_metric(gpu + "workspace peak", format_arena_peak(stage.workspace));
        if (stage.expert_cache_bytes != 0) {
            print_metric(gpu + "expert cache", format_bytes(stage.expert_cache_bytes));
        }
    }

    const ninfer::SpeculativeStats& speculative = result.speculative;
    if (speculative.enabled) {
        const std::string backend = ninfer::product::speculative_backend_name(speculative.backend);
        print_metric(backend + " draft window", std::to_string(speculative.draft_window));
        print_metric(backend + " rounds", std::to_string(speculative.rounds));
        print_metric(backend + " fallback steps", std::to_string(speculative.fallback_steps));
        print_metric(backend + " drafted tokens", std::to_string(speculative.drafted_tokens));
        print_metric(backend + " accepted tokens", std::to_string(speculative.accepted_tokens));
        print_metric(backend + " acceptance rate",
                     format_percent(speculative.accepted_tokens, speculative.drafted_tokens));
        if (speculative.rounds != 0) {
            std::ostringstream length;
            length << std::fixed << std::setprecision(2)
                   << 1.0 + static_cast<double>(speculative.accepted_tokens) /
                                static_cast<double>(speculative.rounds)
                   << " tok/round";
            print_metric(backend + " acceptance length", length.str());
        }
        if (!speculative.accepted_per_position.empty()) {
            std::ostringstream positions;
            for (std::size_t i = 0; i < speculative.accepted_per_position.size(); ++i) {
                if (i != 0) { positions << ','; }
                positions << speculative.accepted_per_position[i];
            }
            print_metric(backend + " accepted by pos", positions.str());
        }
    }

    // Qwen3.8-Flash-Next's n-gram table reads since startup (warm-up included).
    const ninfer::NgramTableStats& rows = stats.ngram_table;
    if (rows.rows != 0) {
        std::ostringstream pass, stall;
        pass << std::fixed << std::setprecision(1)
             << 1e6 * rows.read_seconds /
                    static_cast<double>(std::max<std::uint64_t>(rows.batches, 1))
             << " us over " << rows.batches << " passes";
        stall << rows.stalls << " (" << std::fixed << std::setprecision(2)
              << 1e3 * rows.stall_seconds << " ms)";
        print_metric("ngram rows read", std::to_string(rows.rows));
        print_metric("ngram rows from RAM", format_percent(rows.resident_rows, rows.rows));
        print_metric("ngram read per pass", pass.str());
        print_metric("ngram stalls", stall.str());
    }
    const ninfer::ExpertResidencyStats& experts = stats.experts;
    if (experts.routes != 0) {
        std::ostringstream moved;
        moved << std::fixed << std::setprecision(1) << double(experts.transferred_bytes) / 1048576.0
              << " MiB, " << experts.admitted << " admitted";
        print_metric("expert slots", std::to_string(experts.slots));
        print_metric("expert hits", format_percent(experts.hits, experts.routes));
        if (experts.cpu_routes != 0) {
            print_metric("expert CPU routes", format_percent(experts.cpu_routes, experts.routes));
        }
        print_metric("expert transfers", moved.str());
    }
}

} // namespace

int main(int argc, char** argv) {
    ninfer::cli::Options cli;
    try {
        cli = ninfer::cli::parse_options(argc, argv);
    } catch (const std::exception& error) {
        std::cerr << "error: " << error.what() << '\n';
        std::cerr << ninfer::cli::usage_text(argv[0]);
        return 1;
    }
    if (cli.version_requested) {
        std::cout << "ninfer " << NINFER_VERSION << '+' << NINFER_BUILD_ID << '\n';
        return 0;
    }
    if (cli.help_requested) {
        std::cout << ninfer::cli::usage_text(argv[0]);
        return 0;
    }
    log_colours_flag = cli.log_colours;

    ninfer::product::LoggingRuntime logging(
        {.logger_name  = "ninfer",
         .level        = cli.log_level,
         .presentation = ninfer::product::LogPresentation::Tool});
    const std::shared_ptr<spdlog::logger> logger = logging.logger();
    logger->info("build {}", NINFER_BUILD_ID);
    ninfer::product::StartupLogRenderer startup_log(logging);

    try {
        ninfer::PromptInput input =
            cli.messages_path.empty()
                ? ninfer::product::prompt_from_text(cli.prompt, cli.enable_thinking)
                : ninfer::product::prompt_from_messages(cli.messages_path, cli.enable_thinking,
                                                        cli.enable_vision);
        input.options.reasoning_effort = cli.reasoning_effort;
        ninfer::product::apply_structured_output_instruction(input, cli.structured_output);

        ninfer::RequestOptions request;
        request.execution.sampling                = cli.sampling;
        request.execution.post_thinking_sampling  = cli.post_thinking_sampling;
        request.execution.structured_output       = cli.structured_output;
        request.execution.requested_output_tokens = cli.max_new;
        request.execution.thinking.budget         = cli.thinking_budget;
        request.execution.thinking.loop           = cli.reasoning_loop;
        request.stop.token_ids                    = cli.stop_token_ids;
        request.stop.strings                      = cli.stop_strings;
        request.output.raw                        = cli.raw_output;

        ninfer::EngineOptions engine_options;
        engine_options.artifact_path            = cli.artifact_path;
        engine_options.chat_template_path       = cli.chat_template_path;
        engine_options.device                   = cli.device;
        engine_options.devices                  = cli.devices;
        engine_options.stage_layers             = cli.stage_layers;
        engine_options.expert_residency              = cli.expert_residency;
        engine_options.ngram_table                   = cli.ngram_table;
        engine_options.kv_resident_positions         = cli.kv_resident_positions;
        engine_options.expert_cache_bytes            = cli.expert_cache_bytes;
        engine_options.hybrid_experts                = cli.hybrid_experts;
        engine_options.max_context              = cli.max_context;
        engine_options.kv_capacity              = cli.kv_capacity;
        engine_options.prefill_chunk            = cli.prefill_chunk;
        engine_options.kv_cache                 = cli.kv_cache;
        engine_options.speculative              = cli.speculative;
        engine_options.enable_vision            = cli.enable_vision;
        engine_options.vision_residency         = cli.vision_residency;
        engine_options.vision_max_merged_tokens = cli.vision_max_merged_tokens;
        engine_options.use_cuda_graph           = cli.use_cuda_graph;
        engine_options.gpu_clock_floor_mhz      = cli.gpu_clock_floor_mhz;
        engine_options.lm_head_q4               = cli.lm_head_q4;
        engine_options.lm_head_q6               = cli.lm_head_q6;
        engine_options.embedding_q4             = cli.embedding_q4;
        engine_options.embedding_q6             = cli.embedding_q6;
        engine_options.mtp_experts_q4           = cli.mtp_experts_q4;
        engine_options.gdn_state_fp16           = cli.gdn_state_fp16;
        engine_options.rope_yarn                = cli.rope_yarn;
        engine_options.rope_yarn_factor         = cli.rope_yarn_factor;
        engine_options.rope_scaling_factor           = cli.rope_scaling_factor;
        engine_options.rope_scaling_original_context = cli.rope_scaling_original_context;
        engine_options.structured_output =
            cli.structured_output.kind != ninfer::StructuredOutputKind::None;
        engine_options.wddm_evictable_budget    = cli.wddm_evictable_budget;
        engine_options.mlp_a8_decode            = cli.mlp_a8_decode;
        engine_options.prefill_a8               = cli.prefill_a8;
        engine_options.prefill_cublas           = cli.prefill_cublas;
        engine_options.prefill_cublas_projections = cli.prefill_cublas_projections;
        // One CLI invocation owns exactly one request, so retained cross-request context has no
        // consumer and must not reserve an extra Device StateImage or run terminal capture.
        engine_options.context_cache.enabled                = false;
        engine_options.context_cache.host_state_slots       = 0;
        engine_options.context_cache.host_kv_capacity_bytes = 0;
        engine_options.startup_observer                     = startup_log.observer();
        engine_options.diagnostic_observer = ninfer::product::engine_diagnostic_observer(logger);

        ninfer::Engine engine(std::move(engine_options));
        startup_log.engine_ready(engine.load_summary());
        engine.reset_memory_peaks();

        ninfer::PreparedPrompt prompt = engine.prepare(std::move(input));

        StreamingSink sink;
        ninfer::GenerationHandle generation = engine.submit(std::move(prompt), std::move(request),
                                                            ninfer::OutputConsumerMode::Streaming);
        const ninfer::ResolvedSamplingParameters sampling = generation.resolved_sampling();
        ninfer::GenerationResult result;
        try {
            result = generation.wait(&sink);
            sink.finish_streams();
        } catch (...) {
            sink.finish_streams(false);
            throw;
        }

        std::cerr << "phase       detail                      elapsed/progress\n";
        if (cli.print_token_ids) {
            std::cerr << std::left << std::setw(12) << "tokens" << std::setw(26) << "generated ids";
            for (std::size_t i = 0; i < result.generated_token_ids.size(); ++i) {
                if (i != 0) { std::cerr << ' '; }
                std::cerr << result.generated_token_ids[i];
            }
            std::cerr << '\n';
        }
        print_generation_summary(result, sampling, engine.memory_summary(), engine.runtime_stats());
        return 0;
    } catch (const std::exception& error) {
        logger->error("{}", ninfer::product::format_pretty_text(error.what()));
        return 1;
    }
}
