#!/usr/bin/env python3
"""Run the fixed serving corpus performance evaluation."""

from __future__ import annotations

import argparse
import csv
import dataclasses
import http.client
import json
import math
import os
import signal
import statistics
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Iterable, Sequence
from urllib.parse import quote


REPO_ROOT = Path(__file__).resolve().parents[2]
MANIFEST_PATH = REPO_ROOT / "examples/cli/manifest.json"

SPECULATIVE_MODES = {
    "mtp0": ("none", 0),
    "mtp2": ("mtp", 2),
    "mtp3": ("mtp", 3),
    "dflash7": ("dflash", 7),
    "dflash2_7": ("dflash2", 7),
}
DEFAULT_MODES = ("mtp0", "mtp3")
SAMPLING_MODES = ("stochastic", "greedy")
KV_CACHE_NAMES = {
    "bf16": "bf16",
    "int8": "int8-group64",
    "fp8": "fp8-e4m3-row256",
    "rk8v4": "rotated-k8g64-v4g32",
    "rk4v4": "rotated-lloyd4g64-v4g32",
    "rk4v4-e8": "rotated-k4e8g64-v4g32",
    "rk2v4-e8": "rotated-k2e8g64-v4g32",
    "nvfp4": "nvfp4",
    "k8v4": "k8v4",
}

SEEDS = (
    7632647173703958409,
    7968175640111700217,
    912910298659544128,
    9060622443728853932,
    4939353812939007330,
)

NIAH_FIXTURES = (
    "long_niah_8k",
    "long_niah_64k",
    "long_niah_128k",
    "long_niah_256k",
)

LONG_DECODE_FIXTURES = (
    "long_decode_aime26_01",
    "long_decode_aime26_15",
    "long_decode_aime26_30",
)

SCENARIO_FIXTURES = {
    "code": (
        "scenario_code_cuda",
        "scenario_code_python",
        "scenario_code_typescript",
    ),
    "story": (
        "scenario_story_zh_scifi",
        "scenario_story_en_mystery",
        "scenario_story_zh_dialogue",
    ),
    "translation": (
        "scenario_translation_zh_en",
        "scenario_translation_en_zh",
        "scenario_translation_markdown",
    ),
    "structured": (
        "scenario_structured_jsonl",
        "scenario_structured_csv",
        "scenario_structured_sql",
    ),
}

WARMUP_FIXTURE = "text_smoke_zh"
RUN_ARTIFACT_TYPE = "ninfer_serve_corpus_result"
RUN_SCHEMA_VERSION = 8
SERVER_LOG_ARTIFACT_TYPE = "ninfer_serve_request_log"
SERVER_LOG_SCHEMA_VERSION = 29
STARTUP_TIMEOUT_SECONDS = 1800.0
REQUEST_TIMEOUT_SECONDS = 24.0 * 60.0 * 60.0
LOG_EVENT_TIMEOUT_SECONDS = 10.0


@dataclasses.dataclass(frozen=True)
class Fixture:
    name: str
    messages: list[dict[str, Any]]
    thinking: bool
    max_new: int
    suite: str
    category: str | None = None


@dataclasses.dataclass(frozen=True)
class RunSpec:
    target: str
    model_id: str
    artifact: Path
    speculative_mode: str
    speculative_backend: str
    draft_tokens: int
    sampling_mode: str
    kv_dtype: str
    fixture: Fixture
    seed: int

    @property
    def key(self) -> tuple[str, str, str, str, int]:
        return (
            self.target,
            self.speculative_mode,
            self.sampling_mode,
            self.fixture.name,
            self.seed,
        )


class CampaignError(RuntimeError):
    pass


class ServerLogTail:
    def __init__(
        self, path: Path, process: subprocess.Popen[bytes], initial_offset: int
    ) -> None:
        self.path = path
        self.process = process
        self.offset = initial_offset
        self.buffer = b""
        self.pending: list[dict[str, Any]] = []

    def _check_process(self) -> None:
        returncode = self.process.poll()
        if returncode is not None:
            raise CampaignError(f"ninfer-serve exited unexpectedly with status {returncode}")

    def _read_new(self) -> None:
        if not self.path.exists():
            return
        with self.path.open("rb") as handle:
            handle.seek(self.offset)
            chunk = handle.read()
            self.offset = handle.tell()
        if not chunk:
            return
        self.buffer += chunk
        lines = self.buffer.split(b"\n")
        self.buffer = lines.pop()
        for raw_line in lines:
            if not raw_line:
                continue
            try:
                event = json.loads(raw_line)
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise CampaignError(f"invalid serving JSONL record in {self.path}: {exc}") from exc
            if not isinstance(event, dict):
                raise CampaignError(f"serving JSONL record is not an object in {self.path}")
            self.pending.append(event)

    def wait_for(
        self,
        predicate: Any,
        description: str,
        timeout: float = LOG_EVENT_TIMEOUT_SECONDS,
    ) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        while True:
            self._read_new()
            for index, event in enumerate(self.pending):
                if predicate(event):
                    return self.pending.pop(index)
            self._check_process()
            if time.monotonic() >= deadline:
                raise CampaignError(f"timed out waiting for {description} in {self.path}")
            time.sleep(0.05)


class RunningServer:
    def __init__(
        self,
        command: Sequence[str],
        host: str,
        port: int,
        log_path: Path,
    ) -> None:
        self.command = list(command)
        self.host = host
        self.port = port
        self.log_path = log_path
        self.process: subprocess.Popen[bytes] | None = None
        self.tail: ServerLogTail | None = None

    def __enter__(self) -> "RunningServer":
        initial_offset = self.log_path.stat().st_size if self.log_path.exists() else 0
        # A new process group on Windows is what makes GenerateConsoleCtrlEvent addressable, so
        # stop() can ask for a graceful shutdown instead of killing the server. It also detaches
        # the child from our own Ctrl+C, which is why stop() must always be reached.
        creation_flags = (
            subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == "win32" else 0
        )
        self.process = subprocess.Popen(self.command, cwd=REPO_ROOT, creationflags=creation_flags)
        self.tail = ServerLogTail(self.log_path, self.process, initial_offset)
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.stop()

    def stop(self) -> None:
        if self.process is None or self.process.poll() is not None:
            return
        # The server flushes its final partial throughput interval only on the signal path, and the
        # campaign reconciles those intervals against request_done. Popen.terminate() is SIGTERM on
        # POSIX but TerminateProcess on Windows, which delivers nothing -- so ask for CTRL_BREAK
        # there and fall back to the kill only if the server ignores it.
        if sys.platform == "win32":
            try:
                self.process.send_signal(signal.CTRL_BREAK_EVENT)
            except (OSError, ValueError):
                self.process.terminate()
        else:
            self.process.terminate()
        try:
            self.process.wait(timeout=15.0)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait()

    def wait_until_ready(self) -> dict[str, Any]:
        if self.process is None or self.tail is None:
            raise CampaignError("server process was not started")
        deadline = time.monotonic() + STARTUP_TIMEOUT_SECONDS
        while True:
            returncode = self.process.poll()
            if returncode is not None:
                raise CampaignError(f"ninfer-serve exited during startup with status {returncode}")
            connection = http.client.HTTPConnection(self.host, self.port, timeout=2.0)
            try:
                connection.request("GET", "/health", headers={"Connection": "close"})
                response = connection.getresponse()
                body = response.read()
                if response.status == 200:
                    try:
                        health = json.loads(body)
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        health = None
                    if health == {"status": "ok"}:
                        break
            except OSError:
                pass
            finally:
                connection.close()
            if time.monotonic() >= deadline:
                raise CampaignError(
                    f"timed out waiting for ninfer-serve at http://{self.host}:{self.port}"
                )
            time.sleep(0.2)

        return self.tail.wait_for(
            lambda event: event.get("event") == "server_start",
            "server_start event",
        )

    def wait_for_request_done(self, server_instance_id: str) -> dict[str, Any]:
        if self.tail is None:
            raise CampaignError("server log tail is unavailable")

        def matches(event: dict[str, Any]) -> bool:
            if event.get("server_instance_id") != server_instance_id:
                return False
            if event.get("event") == "request_error":
                message = event.get("error", {}).get("message", "unknown generation error")
                raise CampaignError(f"serving request failed: {message}")
            return event.get("event") == "request_done"

        return self.tail.wait_for(matches, "request_done event")


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--serve",
        type=Path,
        default=REPO_ROOT / "build/apps/ninfer-serve",
        help="ninfer-serve executable",
    )
    parser.add_argument(
        "--artifact",
        action="append",
        required=True,
        metavar="LABEL=PATH",
        help="artifact label and server model alias; repeat to benchmark multiple instances",
    )
    parser.add_argument(
        "--mode",
        action="append",
        choices=tuple(SPECULATIVE_MODES),
        help="benchmark only this mode; repeat to select multiple (default: mtp0 and mtp3)",
    )
    parser.add_argument(
        "--sampling",
        choices=SAMPLING_MODES,
        default="stochastic",
        help="sampling profile for all requests (default: stochastic)",
    )
    parser.add_argument("--output", type=Path, required=True, help="campaign output directory")
    parser.add_argument("--port", type=int, default=8080, help="loopback serving port")
    parser.add_argument("--device", type=int, default=0, help="CUDA device index")
    parser.add_argument("--kv-dtype", choices=tuple(KV_CACHE_NAMES), default="int8")
    return parser.parse_args(argv)


def filename_label(label: str) -> str:
    """Keep arbitrary public aliases distinct inside one report filename component."""
    return quote(label, safe="")


def parse_artifacts(values: Sequence[str]) -> list[tuple[str, Path]]:
    parsed: dict[str, Path] = {}
    for value in values:
        target, separator, raw_path = value.partition("=")
        if not separator or not target or not raw_path:
            raise CampaignError(f"invalid --artifact value {value!r}; expected LABEL=PATH")
        if not target.strip():
            raise CampaignError("artifact label must not be empty")
        if target in parsed:
            raise CampaignError(f"duplicate artifact label: {target}")
        path = Path(raw_path).expanduser().resolve()
        if not path.is_file():
            raise CampaignError(f"artifact not found: {path}")
        parsed[target] = path
    return list(parsed.items())


def fixture_metadata(name: str) -> tuple[str, str | None]:
    if name in NIAH_FIXTURES:
        return "long_niah", None
    if name in LONG_DECODE_FIXTURES:
        return "long_decode", "reasoning"
    for category, names in SCENARIO_FIXTURES.items():
        if name in names:
            return "scenario", category
    if name == WARMUP_FIXTURE:
        return "warmup", None
    raise CampaignError(f"fixture has no campaign assignment: {name}")


def load_fixtures() -> dict[str, Fixture]:
    try:
        manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise CampaignError(f"failed to read {MANIFEST_PATH}: {exc}") from exc
    cases = {case["name"]: case for case in manifest["cases"]}
    selected_names = (
        *NIAH_FIXTURES,
        *LONG_DECODE_FIXTURES,
        *(name for names in SCENARIO_FIXTURES.values() for name in names),
        WARMUP_FIXTURE,
    )
    fixtures: dict[str, Fixture] = {}
    for name in selected_names:
        try:
            case = cases[name]
            messages_path = MANIFEST_PATH.parent / case["messages"]
            messages = json.loads(messages_path.read_text(encoding="utf-8"))
            suite, category = fixture_metadata(name)
            fixtures[name] = Fixture(
                name=name,
                messages=messages,
                thinking=bool(case["thinking"]),
                max_new=int(case["max_new"]),
                suite=suite,
                category=category,
            )
        except (KeyError, OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
            raise CampaignError(f"failed to load fixture {name!r} from the examples manifest: {exc}") from exc
    return fixtures


def block_fixture_names(speculative_backend: str) -> tuple[str, ...]:
    scenarios = tuple(name for names in SCENARIO_FIXTURES.values() for name in names)
    if speculative_backend == "none":
        return NIAH_FIXTURES
    if speculative_backend in {"mtp", "dflash", "dflash2"}:
        return (*LONG_DECODE_FIXTURES, *scenarios)
    raise CampaignError(f"unsupported speculative backend: {speculative_backend}")


def build_specs(
    artifacts: Sequence[tuple[str, Path]],
    fixtures: dict[str, Fixture],
    mode_names: Sequence[str],
    sampling_mode: str,
    kv_dtype: str,
) -> list[RunSpec]:
    specs: list[RunSpec] = []
    for target, artifact in artifacts:
        for mode_name in mode_names:
            backend, draft_tokens = SPECULATIVE_MODES[mode_name]
            for fixture_name in block_fixture_names(backend):
                for seed in SEEDS:
                    specs.append(
                        RunSpec(
                            target=target,
                            model_id=target,
                            artifact=artifact,
                            speculative_mode=mode_name,
                            speculative_backend=backend,
                            draft_tokens=draft_tokens,
                            sampling_mode=sampling_mode,
                            kv_dtype=kv_dtype,
                            fixture=fixtures[fixture_name],
                            seed=seed,
                        )
                    )
    return specs


def request_payload(model_id: str, fixture: Fixture, seed: int) -> dict[str, Any]:
    return {
        "model": model_id,
        "messages": fixture.messages,
        "max_completion_tokens": fixture.max_new,
        "seed": seed,
        "stream": False,
        "enable_thinking": fixture.thinking,
    }


def send_json(connection: http.client.HTTPConnection, payload: dict[str, Any]) -> None:
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    try:
        connection.request(
            "POST",
            "/v1/chat/completions",
            body=body,
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Content-Length": str(len(body)),
                "Connection": "keep-alive",
            },
        )
    except (OSError, http.client.HTTPException) as exc:
        raise CampaignError(f"HTTP request failed: {exc}") from exc


def receive_json(connection: http.client.HTTPConnection) -> dict[str, Any]:
    try:
        response = connection.getresponse()
        response_body = response.read()
    except (OSError, http.client.HTTPException) as exc:
        raise CampaignError(f"HTTP request failed: {exc}") from exc
    if response.status != 200:
        detail = response_body.decode("utf-8", errors="replace")
        raise CampaignError(f"HTTP {response.status} {response.reason}: {detail}")
    try:
        parsed = json.loads(response_body)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise CampaignError(f"serving response is not valid JSON: {exc}") from exc
    if not isinstance(parsed, dict):
        raise CampaignError("serving response is not a JSON object")
    return parsed


def post_json(connection: http.client.HTTPConnection, payload: dict[str, Any]) -> dict[str, Any]:
    send_json(connection, payload)
    return receive_json(connection)


def require_server_log_identity(event: dict[str, Any], event_name: str) -> None:
    identity = (
        event.get("artifact_type"),
        event.get("schema_version"),
        event.get("event"),
    )
    expected = (SERVER_LOG_ARTIFACT_TYPE, SERVER_LOG_SCHEMA_VERSION, event_name)
    if identity != expected:
        raise CampaignError(f"unexpected serving log identity {identity!r}; expected {expected!r}")


def validate_server_start(event: dict[str, Any], spec: RunSpec, device: int) -> tuple[str, str]:
    require_server_log_identity(event, "server_start")
    engine = event.get("engine", {})
    actual = {
        "device": engine.get("device"),
        "max_context": engine.get("max_context"),
        "kv_capacity": engine.get("kv_capacity"),
        "prefill_chunk": engine.get("prefill_chunk"),
        "kv_cache": engine.get("kv_cache"),
        "cuda_graph": engine.get("cuda_graph"),
        "prefix_reuse": engine.get("prefix_reuse"),
        "speculative_backend": engine.get("speculative_backend"),
        "speculative_draft_window": engine.get("speculative_draft_window"),
        "proposal_head": engine.get("proposal_head"),
    }
    expected = {
        "device": device,
        "max_context": 262144,
        "kv_capacity": 262144,
        "prefill_chunk": 1024,
        "kv_cache": KV_CACHE_NAMES[spec.kv_dtype],
        "cuda_graph": True,
        "prefix_reuse": False,
        "speculative_backend": spec.speculative_backend,
        "speculative_draft_window": spec.draft_tokens,
        "proposal_head": "optimized" if spec.draft_tokens else "full",
    }
    if actual != expected:
        raise CampaignError(f"server_start Engine configuration mismatch: {actual!r}")
    if event.get("sampling_defaults", {}).get("greedy") != (
        spec.sampling_mode == "greedy"
    ):
        raise CampaignError("server_start sampling mode does not match the campaign")
    if Path(event.get("artifact", {}).get("path", "")).resolve() != spec.artifact.resolve():
        raise CampaignError("loaded artifact path does not match the campaign")
    prefill_signature = event.get("artifact", {}).get("prefill_signature")
    if not isinstance(prefill_signature, str) or not prefill_signature:
        raise CampaignError("server_start has no canonical artifact prefill_signature")
    if event.get("server", {}).get("public_model_id") != spec.model_id:
        raise CampaignError("server_start public model id does not match the campaign target")
    server_instance_id = event.get("server_instance_id")
    if not isinstance(server_instance_id, str) or not server_instance_id:
        raise CampaignError("server_start has no server_instance_id")
    return server_instance_id, prefill_signature


def safe_ratio(numerator: float, denominator: float) -> float | None:
    if denominator <= 0.0:
        return None
    return numerator / denominator


def build_result_record(
    spec: RunSpec,
    prefill_signature: str,
    payload: dict[str, Any],
    response: dict[str, Any],
    server_event: dict[str, Any],
) -> dict[str, Any]:
    require_server_log_identity(server_event, "request_done")
    request = server_event.get("request", {})
    result = server_event.get("result", {})
    timings = server_event.get("timings_seconds", {})
    speculative = server_event.get("speculative", {})
    engine_timing = server_event.get("engine_timing", {})
    host_exposed = engine_timing.get("host_exposed_seconds", {})
    decode_engine = engine_timing.get("decode", {})

    expected_request = {
        "model": spec.model_id,
        "requested_output_tokens": spec.fixture.max_new,
        "enable_thinking": spec.fixture.thinking,
        "seed": spec.seed,
    }
    actual_request = {
        "model": request.get("model"),
        "requested_output_tokens": request.get("requested_output_tokens"),
        "enable_thinking": request.get("enable_thinking"),
        "seed": request.get("sampling", {}).get("seed"),
    }
    if actual_request != expected_request:
        raise CampaignError(
            f"request_done does not match the submitted request: {actual_request!r}"
        )

    try:
        prompt_tokens = int(result["prompt_tokens"])
        completion_tokens = int(result["completion_tokens"])
        prepare_seconds = float(timings["prepare"])
        vision_seconds = float(timings["vision"])
        prefill_seconds = float(timings["prefill"])
        decode_seconds = float(timings["decode"])
        total_seconds = float(timings["total"])
        backend = str(speculative["backend"])
        speculative_rounds = int(speculative["rounds"])
        drafted_tokens = int(speculative["drafted_tokens"])
        accepted_tokens = int(speculative["accepted_tokens"])
        fallback_steps = int(speculative["fallback_steps"])
        queue_wait_seconds = float(engine_timing["queue_wait_seconds"])
        engine_boundary_exposed_seconds = float(host_exposed["engine_boundary"])
        program_submit_exposed_seconds = float(host_exposed["program_submit"])
        program_post_exposed_seconds = float(host_exposed["program_post"])
        engine_commit_output_exposed_seconds = float(host_exposed["engine_commit_output"])
        engine_maintenance_exposed_seconds = float(host_exposed["engine_maintenance"])
        engine_host_exposed_seconds = float(host_exposed["total"])
        device_wait_exposed_seconds = float(engine_timing["device_wait_exposed_seconds"])
        decode_host_exposed_seconds = float(decode_engine["host_exposed_seconds"])
        decode_device_wait_exposed_seconds = float(
            decode_engine["device_wait_exposed_seconds"]
        )
        decode_rounds = int(decode_engine["rounds"])
    except (KeyError, TypeError, ValueError) as exc:
        raise CampaignError(f"request_done is missing required metrics: {exc}") from exc

    host_phase_sum = (
        engine_boundary_exposed_seconds
        + program_submit_exposed_seconds
        + program_post_exposed_seconds
        + engine_commit_output_exposed_seconds
        + engine_maintenance_exposed_seconds
    )
    if not math.isclose(
        host_phase_sum, engine_host_exposed_seconds, rel_tol=1.0e-12, abs_tol=1.0e-12
    ):
        raise CampaignError("request_done engine Host phase total is inconsistent")

    if backend != spec.speculative_backend:
        raise CampaignError(
            f"request_done speculative backend {backend!r} != "
            f"{spec.speculative_backend!r}"
        )

    usage = response.get("usage", {})
    if (
        usage.get("prompt_tokens") != prompt_tokens
        or usage.get("completion_tokens") != completion_tokens
    ):
        raise CampaignError("HTTP response usage does not match request_done token counts")

    decode_tokens = max(completion_tokens - 1, 0)
    metrics = {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "decode_tokens": decode_tokens,
        "finish_reason": result.get("finish_reason"),
        "prepare_seconds": prepare_seconds,
        "vision_seconds": vision_seconds,
        "prefill_seconds": prefill_seconds,
        "decode_seconds": decode_seconds,
        "total_seconds": total_seconds,
        "prefill_tok_s": safe_ratio(float(prompt_tokens), prefill_seconds),
        "server_ttft_ms": 1000.0 * (prepare_seconds + vision_seconds + prefill_seconds),
        "decode_tok_s": safe_ratio(float(decode_tokens), decode_seconds),
        "speculative_rounds": speculative_rounds,
        "drafted_tokens": drafted_tokens,
        "accepted_tokens": accepted_tokens,
        "speculative_acceptance": safe_ratio(float(accepted_tokens), float(drafted_tokens)),
        "speculative_tokens_per_round": (
            1.0 + accepted_tokens / speculative_rounds if speculative_rounds > 0 else None
        ),
        "fallback_steps": fallback_steps,
        # Request values are latency exposure, not worker cost. They are valid for distribution
        # and per-request normalization but must not be summed across concurrent requests.
        "queue_wait_seconds": queue_wait_seconds,
        "engine_boundary_exposed_seconds": engine_boundary_exposed_seconds,
        "program_submit_exposed_seconds": program_submit_exposed_seconds,
        "program_post_exposed_seconds": program_post_exposed_seconds,
        "engine_commit_output_exposed_seconds": engine_commit_output_exposed_seconds,
        "engine_maintenance_exposed_seconds": engine_maintenance_exposed_seconds,
        "engine_host_exposed_seconds": engine_host_exposed_seconds,
        "device_wait_exposed_seconds": device_wait_exposed_seconds,
        "decode_host_exposed_seconds": decode_host_exposed_seconds,
        "decode_device_wait_exposed_seconds": decode_device_wait_exposed_seconds,
        "decode_rounds": decode_rounds,
        "queue_wait_ms": queue_wait_seconds * 1000.0,
        "engine_host_exposed_ms": engine_host_exposed_seconds * 1000.0,
        "decode_host_us_per_round": safe_ratio(
            decode_host_exposed_seconds * 1.0e6, float(decode_rounds)
        ),
        "decode_device_wait_us_per_round": safe_ratio(
            decode_device_wait_exposed_seconds * 1.0e6, float(decode_rounds)
        ),
    }
    return {
        "artifact_type": RUN_ARTIFACT_TYPE,
        "schema_version": RUN_SCHEMA_VERSION,
        "target": spec.target,
        "prefill_signature": prefill_signature,
        "model": spec.model_id,
        "artifact_path": str(spec.artifact),
        "fixture": spec.fixture.name,
        "suite": spec.fixture.suite,
        "category": spec.fixture.category,
        "seed": spec.seed,
        "speculative_mode": spec.speculative_mode,
        "speculative_backend": spec.speculative_backend,
        "draft_tokens": spec.draft_tokens,
        "sampling_mode": spec.sampling_mode,
        "kv_dtype": spec.kv_dtype,
        "request": payload,
        "response": response,
        "server_event": server_event,
        "metrics": metrics,
    }


def record_key(record: dict[str, Any]) -> tuple[str, str, str, str, int]:
    try:
        return (
            str(record["target"]),
            str(record["speculative_mode"]),
            str(record["sampling_mode"]),
            str(record["fixture"]),
            int(record["seed"]),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise CampaignError(f"invalid corpus result record key: {exc}") from exc


def load_existing_records(
    path: Path,
    expected_specs: dict[tuple[str, str, str, str, int], RunSpec],
) -> dict[tuple[str, str, str, str, int], dict[str, Any]]:
    records: dict[tuple[str, str, str, str, int], dict[str, Any]] = {}
    if not path.exists():
        return records
    try:
        with path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                record = json.loads(line)
                identity = (record.get("artifact_type"), record.get("schema_version"))
                expected_identity = (RUN_ARTIFACT_TYPE, RUN_SCHEMA_VERSION)
                if identity != expected_identity:
                    raise CampaignError(
                        f"{path}:{line_number}: unexpected record identity {identity!r}"
                    )
                key = record_key(record)
                if key not in expected_specs:
                    raise CampaignError(f"{path}:{line_number}: result is outside this campaign")
                if key in records:
                    raise CampaignError(f"{path}:{line_number}: duplicate result for {key!r}")
                spec = expected_specs[key]
                if record.get("kv_dtype") != spec.kv_dtype:
                    raise CampaignError(
                        f"{path}:{line_number}: KV dtype differs from the current command"
                    )
                if Path(record.get("artifact_path", "")).resolve() != spec.artifact:
                    raise CampaignError(
                        f"{path}:{line_number}: artifact path differs from the current command"
                    )
                records[key] = record
    except (OSError, json.JSONDecodeError) as exc:
        raise CampaignError(f"failed to read existing results from {path}: {exc}") from exc
    return records


def append_record(handle: Any, record: dict[str, Any]) -> None:
    handle.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
    handle.flush()
    os.fsync(handle.fileno())


def server_command(
    serve: Path,
    spec: RunSpec,
    server_log: Path,
    port: int,
    device: int,
) -> list[str]:
    command = [
        str(serve),
        str(spec.artifact),
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        "--model-id",
        spec.model_id,
        "--max-context",
        "262144",
        "--kv-capacity",
        "262144",
        "--prefill-chunk",
        "1024",
        "--log-stats-interval-ms",
        "0",
        "--device",
        str(device),
        "--request-log-jsonl",
        str(server_log),
        "--kv-dtype",
        spec.kv_dtype,
        "--no-prefix-reuse",
    ]
    if spec.speculative_backend != "none":
        command.extend(
            [
                "--spec",
                spec.speculative_backend,
                "--draft-tokens",
                str(spec.draft_tokens),
                "--lm-head-draft",
            ]
        )
    if spec.sampling_mode == "greedy":
        command.append("--greedy")
    else:
        # Published stochastic measurements use this explicit profile; they must not drift when
        # product defaults follow a newly registered model recommendation.
        command.extend(
            [
                "--temperature",
                "0.6",
                "--top-p",
                "0.95",
                "--top-k",
                "20",
                "--min-p",
                "0",
                "--presence-penalty",
                "1.0",
                "--frequency-penalty",
                "0",
            ]
        )
    return command


def run_block(
    serve: Path,
    block_specs: Sequence[RunSpec],
    fixtures: dict[str, Fixture],
    output_dir: Path,
    port: int,
    device: int,
    run_handle: Any,
    records: dict[tuple[str, str, str, str, int], dict[str, Any]],
    completed_before_block: int,
    total: int,
) -> None:
    first = block_specs[0]
    server_log = (
        output_dir
        / "server"
        / f"{filename_label(first.target)}_{first.kv_dtype}_{first.speculative_mode}_{first.sampling_mode}.jsonl"
    )
    command = server_command(serve, first, server_log, port, device)
    print(
        f"start {first.target}/{first.speculative_mode}: "
        f"{len(block_specs)} missing request(s)",
        flush=True,
    )
    with RunningServer(command, "127.0.0.1", port, server_log) as server:
        server_start = server.wait_until_ready()
        server_instance_id, prefill_signature = validate_server_start(server_start, first, device)

        connection = http.client.HTTPConnection(
            "127.0.0.1", port, timeout=REQUEST_TIMEOUT_SECONDS
        )
        last_request_id: int | None = None
        try:
            warmup = fixtures[WARMUP_FIXTURE]
            post_json(connection, request_payload(first.model_id, warmup, SEEDS[0]))
            warmup_done = server.wait_for_request_done(server_instance_id)
            require_server_log_identity(warmup_done, "request_done")
            last_request_id = int(warmup_done.get("request", {}).get("request_id"))

            for block_index, spec in enumerate(block_specs, start=1):
                payload = request_payload(spec.model_id, spec.fixture, spec.seed)
                response = post_json(connection, payload)
                request_done = server.wait_for_request_done(server_instance_id)
                request_id = int(request_done.get("request", {}).get("request_id"))
                if request_id != last_request_id + 1:
                    raise CampaignError(
                        f"non-sequential serving request id {request_id}; expected {last_request_id + 1}"
                    )
                last_request_id = request_id
                record = build_result_record(spec, prefill_signature, payload, response, request_done)
                append_record(run_handle, record)
                records[spec.key] = record
                completed = completed_before_block + block_index
                print(
                    f"[{completed}/{total}] {spec.target}/{spec.speculative_mode} "
                    f"{spec.fixture.name} seed={spec.seed}",
                    flush=True,
                )
        finally:
            connection.close()


def metric_values(records: Iterable[dict[str, Any]], name: str) -> list[float]:
    values: list[float] = []
    for record in records:
        value = record["metrics"].get(name)
        if value is not None:
            values.append(float(value))
    return values


def sample_stats(records: Sequence[dict[str, Any]], name: str) -> tuple[int, float | None, float | None]:
    values = metric_values(records, name)
    if not values:
        return 0, None, None
    mean = statistics.fmean(values)
    stddev = statistics.stdev(values) if len(values) > 1 else 0.0
    return len(values), mean, stddev


def select_records(
    records: dict[tuple[str, str, str, str, int], dict[str, Any]],
    target: str,
    speculative_mode: str,
    sampling_mode: str,
    fixtures: Sequence[str],
) -> list[dict[str, Any]]:
    return [
        records[(target, speculative_mode, sampling_mode, fixture, seed)]
        for fixture in fixtures
        for seed in SEEDS
    ]


SUMMARY_FIELDS = (
    "section",
    "target",
    "prefill_signature",
    "group",
    "fixture",
    "speculative_mode",
    "sampling_mode",
    "kv_dtype",
    "samples",
    "prompt_tokens_mean",
    "prompt_tokens_stddev",
    "prefill_tok_s_mean",
    "prefill_tok_s_stddev",
    "server_ttft_ms_mean",
    "server_ttft_ms_stddev",
    "completion_tokens_mean",
    "completion_tokens_stddev",
    "decode_tok_s_mean",
    "decode_tok_s_stddev",
    "queue_wait_ms_mean",
    "queue_wait_ms_stddev",
    "engine_host_exposed_ms_mean",
    "engine_host_exposed_ms_stddev",
    "decode_host_us_per_round_mean",
    "decode_host_us_per_round_stddev",
    "decode_device_wait_us_per_round_mean",
    "decode_device_wait_us_per_round_stddev",
    "speculative_acceptance_mean",
    "speculative_acceptance_stddev",
    "speculative_tokens_per_round_mean",
    "speculative_tokens_per_round_stddev",
)


def set_stats(
    row: dict[str, Any],
    prefix: str,
    records: Sequence[dict[str, Any]],
    metric: str,
) -> None:
    _, mean, stddev = sample_stats(records, metric)
    row[f"{prefix}_mean"] = mean
    row[f"{prefix}_stddev"] = stddev


def summary_row(
    section: str,
    target: str,
    group: str,
    fixture: str,
    speculative_mode: str,
    sampling_mode: str,
    records: Sequence[dict[str, Any]],
) -> dict[str, Any]:
    prefill_signatures = {str(record.get("prefill_signature", "")) for record in records}
    if len(prefill_signatures) != 1 or not next(iter(prefill_signatures)):
        raise CampaignError("summary group does not have one canonical prefill_signature")
    kv_dtypes = {record["kv_dtype"] for record in records}
    if len(kv_dtypes) != 1:
        raise CampaignError("summary group mixes KV dtypes")
    row: dict[str, Any] = {
        "section": section,
        "target": target,
        "prefill_signature": next(iter(prefill_signatures)),
        "group": group,
        "fixture": fixture,
        "speculative_mode": speculative_mode,
        "sampling_mode": sampling_mode,
        "kv_dtype": next(iter(kv_dtypes)),
        "samples": len(records),
    }
    set_stats(row, "prompt_tokens", records, "prompt_tokens")
    set_stats(row, "prefill_tok_s", records, "prefill_tok_s")
    set_stats(row, "server_ttft_ms", records, "server_ttft_ms")
    set_stats(row, "completion_tokens", records, "completion_tokens")
    set_stats(row, "decode_tok_s", records, "decode_tok_s")
    set_stats(row, "queue_wait_ms", records, "queue_wait_ms")
    set_stats(row, "engine_host_exposed_ms", records, "engine_host_exposed_ms")
    set_stats(row, "decode_host_us_per_round", records, "decode_host_us_per_round")
    set_stats(
        row,
        "decode_device_wait_us_per_round",
        records,
        "decode_device_wait_us_per_round",
    )
    set_stats(row, "speculative_acceptance", records, "speculative_acceptance")
    set_stats(
        row,
        "speculative_tokens_per_round",
        records,
        "speculative_tokens_per_round",
    )
    return row


def build_summary_rows(
    records: dict[tuple[str, str, str, str, int], dict[str, Any]],
    target_order: Sequence[str],
    mode_names: Sequence[str],
    sampling_mode: str,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for target in target_order:
        for mode_name in mode_names:
            backend, _ = SPECULATIVE_MODES[mode_name]
            if backend == "none":
                for fixture in NIAH_FIXTURES:
                    rows.append(
                        summary_row(
                            "context_profile",
                            target,
                            fixture,
                            fixture,
                            mode_name,
                            sampling_mode,
                            select_records(
                                records, target, mode_name, sampling_mode, (fixture,)
                            ),
                        )
                    )
                continue

            for fixture in LONG_DECODE_FIXTURES:
                rows.append(
                    summary_row(
                        "long_decode",
                        target,
                        "reasoning",
                        fixture,
                        mode_name,
                        sampling_mode,
                        select_records(
                            records, target, mode_name, sampling_mode, (fixture,)
                        ),
                    )
                )

            for category, fixture_names in SCENARIO_FIXTURES.items():
                for fixture in fixture_names:
                    rows.append(
                        summary_row(
                            "scenario_fixture",
                            target,
                            category,
                            fixture,
                            mode_name,
                            sampling_mode,
                            select_records(
                                records, target, mode_name, sampling_mode, (fixture,)
                            ),
                        )
                    )

                rows.append(
                    summary_row(
                        "scenario_category",
                        target,
                        category,
                        "",
                        mode_name,
                        sampling_mode,
                        select_records(
                            records, target, mode_name, sampling_mode, fixture_names
                        ),
                    )
                )
    return rows


def csv_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, float) and not math.isfinite(value):
        raise CampaignError("summary contains a non-finite value")
    return value


def format_mean_stddev(row: dict[str, Any], prefix: str, digits: int = 1) -> str:
    mean = row.get(f"{prefix}_mean")
    stddev = row.get(f"{prefix}_stddev")
    if mean is None or stddev is None:
        return "—"
    return f"{float(mean):.{digits}f} ± {float(stddev):.{digits}f}"


def format_percent_mean_stddev(row: dict[str, Any], prefix: str) -> str:
    mean = row.get(f"{prefix}_mean")
    stddev = row.get(f"{prefix}_stddev")
    if mean is None or stddev is None:
        return "—"
    return f"{100.0 * float(mean):.1f}% ± {100.0 * float(stddev):.1f}%"


def markdown_table(headers: Sequence[str], rows: Sequence[Sequence[str]]) -> str:
    header = "| " + " | ".join(headers) + " |"
    divider = "| " + " | ".join("---" for _ in headers) + " |"
    body = ["| " + " | ".join(row) + " |" for row in rows]
    return "\n".join((header, divider, *body))


def mode_display_name(mode_name: str) -> str:
    if mode_name == "mtp0":
        return "MTP0"
    if mode_name == "mtp3":
        return "MTP3"
    if mode_name == "dflash7":
        return "DFlash block=8 (k=7)"
    if mode_name == "dflash2_7":
        return "DFlash2 block=8 (k=7)"
    raise CampaignError(f"unsupported summary mode: {mode_name}")


def write_summaries(rows: Sequence[dict[str, Any]], output_dir: Path) -> None:
    with (output_dir / "summary.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=SUMMARY_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(
            {field: csv_value(row.get(field)) for field in SUMMARY_FIELDS} for row in rows
        )

    sections: list[str] = []
    mode_names = list(dict.fromkeys(str(row["speculative_mode"]) for row in rows))
    for mode_name in mode_names:
        label = mode_display_name(mode_name)
        mode_rows = [row for row in rows if row["speculative_mode"] == mode_name]
        context_rows = [
            row for row in mode_rows if row["section"] == "context_profile"
        ]
        long_decode_rows = [
            row for row in mode_rows if row["section"] == "long_decode"
        ]
        category_rows = [
            row for row in mode_rows if row["section"] == "scenario_category"
        ]

        if context_rows:
            table = markdown_table(
                (
                    "Target",
                    "Weights",
                    "Fixture",
                    "n",
                    "Prompt tokens",
                    "Prefill tok/s",
                    "Server TTFT ms",
                    "Decode tok/s",
                    "Host exposure ms",
                    "Decode Host us/round",
                ),
                [
                    (
                        row["target"],
                        row["prefill_signature"],
                        row["fixture"],
                        str(row["samples"]),
                        format_mean_stddev(row, "prompt_tokens"),
                        format_mean_stddev(row, "prefill_tok_s"),
                        format_mean_stddev(row, "server_ttft_ms"),
                        format_mean_stddev(row, "decode_tok_s"),
                        format_mean_stddev(row, "engine_host_exposed_ms"),
                        format_mean_stddev(row, "decode_host_us_per_round"),
                    )
                    for row in context_rows
                ],
            )
            sections.append(f"## {label} context-length profile\n\n{table}")

        if long_decode_rows:
            table = markdown_table(
                (
                    "Target",
                    "Weights",
                    "Fixture",
                    "n",
                    "Completion tokens",
                    "Decode tok/s",
                    "Decode Host us/round",
                    "Device wait us/round",
                    "Spec acceptance",
                    "Spec tokens/round",
                ),
                [
                    (
                        row["target"],
                        row["prefill_signature"],
                        row["fixture"],
                        str(row["samples"]),
                        format_mean_stddev(row, "completion_tokens"),
                        format_mean_stddev(row, "decode_tok_s"),
                        format_mean_stddev(row, "decode_host_us_per_round"),
                        format_mean_stddev(row, "decode_device_wait_us_per_round"),
                        format_percent_mean_stddev(row, "speculative_acceptance"),
                        format_mean_stddev(
                            row, "speculative_tokens_per_round", digits=2
                        ),
                    )
                    for row in long_decode_rows
                ],
            )
            sections.append(f"## {label} long-decode reasoning\n\n{table}")

        if category_rows:
            table = markdown_table(
                (
                    "Target",
                    "Weights",
                    "Category",
                    "n",
                    "Decode tok/s",
                    "Decode Host us/round",
                    "Device wait us/round",
                    "Spec acceptance",
                    "Spec tokens/round",
                ),
                [
                    (
                        row["target"],
                        row["prefill_signature"],
                        row["group"],
                        str(row["samples"]),
                        format_mean_stddev(row, "decode_tok_s"),
                        format_mean_stddev(row, "decode_host_us_per_round"),
                        format_mean_stddev(row, "decode_device_wait_us_per_round"),
                        format_percent_mean_stddev(row, "speculative_acceptance"),
                        format_mean_stddev(
                            row, "speculative_tokens_per_round", digits=2
                        ),
                    )
                    for row in category_rows
                ],
            )
            sections.append(f"## {label} cross-scenario decode\n\n{table}")
    markdown = (
        "# Serving corpus performance summary\n\n"
        "All values are arithmetic mean ± sample standard deviation. "
        f"Sampling: {rows[0]['sampling_mode'] if rows else 'n/a'}. "
        f"KV: {rows[0]['kv_dtype'] if rows else 'n/a'}.\n\n"
        + "\n\n".join(sections)
        + "\n"
    )
    (output_dir / "summary.md").write_text(markdown, encoding="utf-8")


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    if args.port < 1 or args.port > 65535:
        raise CampaignError("--port must be in [1, 65535]")
    if args.device < 0:
        raise CampaignError("--device must be nonnegative")

    serve = args.serve.expanduser().resolve()
    if not serve.is_file():
        raise CampaignError(f"ninfer-serve executable not found: {serve}")
    if not os.access(serve, os.X_OK):
        raise CampaignError(f"ninfer-serve is not executable: {serve}")

    artifacts = parse_artifacts(args.artifact)
    mode_names = args.mode or list(DEFAULT_MODES)
    if len(mode_names) != len(set(mode_names)):
        raise CampaignError("duplicate --mode value")
    fixtures = load_fixtures()
    specs = build_specs(artifacts, fixtures, mode_names, args.sampling, args.kv_dtype)
    expected_specs = {spec.key: spec for spec in specs}
    total = len(expected_specs)

    output_dir = args.output.expanduser().resolve()
    (output_dir / "server").mkdir(parents=True, exist_ok=True)
    run_path = output_dir / "run.jsonl"
    records = load_existing_records(run_path, expected_specs)
    print(f"resume state: {len(records)}/{total} formal request(s) complete", flush=True)

    with run_path.open("a", encoding="utf-8") as run_handle:
        for target, _ in artifacts:
            for mode_name in mode_names:
                block_specs = [
                    spec
                    for spec in specs
                    if spec.target == target
                    and spec.speculative_mode == mode_name
                    and spec.key not in records
                ]
                if not block_specs:
                    print(f"skip {target}/{mode_name}: block complete", flush=True)
                    continue
                run_block(
                    serve,
                    block_specs,
                    fixtures,
                    output_dir,
                    args.port,
                    args.device,
                    run_handle,
                    records,
                    len(records),
                    total,
                )

    missing = set(expected_specs) - set(records)
    if missing:
        raise CampaignError(f"campaign ended with {len(missing)} missing formal request(s)")
    target_order = [target for target, _ in artifacts]
    summary_rows = build_summary_rows(records, target_order, mode_names, args.sampling)
    write_summaries(summary_rows, output_dir)
    print(
        f"completed {total} formal requests; summary: {output_dir / 'summary.md'}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except CampaignError as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(1) from None
    except KeyboardInterrupt:
        print("interrupted; completed results remain in run.jsonl", file=sys.stderr)
        raise SystemExit(130) from None
