#pragma once

#include "models/qwen3_5/program/text_graph.h"
#include "ninfer/types.h"

namespace ninfer::models::qwen3_5 {
namespace execution {
class Parameters;
}

// Within one startup configuration, only MoE residency changes the required graph variants.
struct GraphPreparationPlan {
    bool segmented = false;
    std::vector<moe::GraphPlan> layers_by_batch;
    friend bool operator==(const GraphPreparationPlan&, const GraphPreparationPlan&) = default;
};

struct GraphCalibration {
    GraphPreparationPlan plan;
    std::size_t rebuild_bytes                = 0;
    std::int64_t preparation_increment_bytes = 0;
    std::int64_t retained_increment_bytes    = 0;
};

[[nodiscard]] GraphPreparationPlan describe_graph_preparation(const EngineOptions&,
                                                              const moe::Plan*);
// The loaded model outlives calibration. No probe resources survive this call.
[[nodiscard]] GraphCalibration calibrate_graphs(const execution::Parameters&, DeviceContext&,
                                                const EngineOptions&,
                                                std::shared_ptr<const moe::Plan>);

} // namespace ninfer::models::qwen3_5
