#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""t11_plan_cats.py -- 决策树必须说清「看到了哪些类、缺了哪些类」。

缺陷现象（第 12 例，来自反扫 probe_layers 的 L944）
    ① 未知类别：cats_to_mix 用 CAT_TO_DIR.get(cat, "rest") 兜底 → 新类别（如 forge-pe）
       的权重静默并进**回放池**；而 rest 一进 mix，build_mix 就不再追加回放项 →
       回放权重无声变 0。plan 里看不出这一类存在过。
    ② 缺类别：probe 侧某类 <8 条会被 skip，probe_by_cat.json 就那么少一类；
       决策树静默少看它，而兜底分支的 note 写「峰不分离且不在后段」——归因错了
       （你会去调层段，实际该补数据）。
正确的断言
    未知类别 → cats_to_mix 抛 FATAL（不是落 rest）；
    缺类别   → 输出里出现「缺失 [...]」的 warn，且 plan.note 带「本结论不含这几类」；
                report 里 missing_cats 有值。
如果这条 FAIL 说明什么
    未知类别又走 .get(cat,"rest") 兜底了，或 missing/unknown 的报告字段被删。
"""
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
KITTY = os.path.dirname(os.path.dirname(HERE))
PY = sys.executable
SCRIPT = os.path.join(KITTY, "scripts", "plan_layers.py")

spec = importlib.util.spec_from_file_location("plan_layers_t11", SCRIPT)
PL = importlib.util.module_from_spec(spec)
sys.modules["plan_layers_t11"] = PL
spec.loader.exec_module(PL)

fails = []

# ---------- 1) 未知类别不再落 rest ----------
print("=== 未知类别 ===")
try:
    got = PL.cats_to_mix({"forge-pe": 2})
    fails.append(f"未知类别没报错，得到 {got}")
    print(f"[FAIL] cats_to_mix({{'forge-pe':2}}) = {got}（应当 FATAL）")
except SystemExit as e:
    ok = "未知类别" in str(e)
    print(f"[{'✓' if ok else '✗'}] FATAL: {str(e).splitlines()[0][:96]}")
    if not ok:
        fails.append("FATAL 没点明未知类别")

# 已知类别照旧相加
m = PL.cats_to_mix({"kb-re": 3, "action-reverse": 1})
print(f"[✓] 已知类别相加: {m}")
if m != {"re-train": 4.0}:
    fails.append(f"已知类别相加结果不对: {m}")

# ---------- 2) 缺类别要 warn + note ----------
print("\n=== 缺类别 ===")
tmp = tempfile.mkdtemp(prefix="rg-t11-")
try:
    base = os.path.join(KITTY, "tmp", "fake-probe")
    probe = os.path.join(tmp, "probe")
    shutil.copytree(base, probe)
    p = os.path.join(probe, "probe_by_cat.json")
    d = json.load(open(p, encoding="utf-8"))
    if "cats" not in d:
        fails.append("fake-probe 的 probe_by_cat.json 不是信封格式，测试前提失效")
    dropped = "tool-route"
    d["cats"].pop(dropped, None)
    if "ablation_dloss" in d:
        d["ablation_dloss"].pop(dropped, None)
    json.dump(d, open(p, "w", encoding="utf-8"), ensure_ascii=False)

    out = os.path.join(tmp, "plan.json")
    r = subprocess.run([PY, SCRIPT, "--probe-dir", probe, "--out", out],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    txt = (r.stdout or "") + (r.stderr or "")
    has_warn = "缺失" in txt and dropped in txt
    print(f"[{'✓' if has_warn else '✗'}] 缺类 warn: "
          f"{next((l for l in txt.splitlines() if '缺失' in l), '(没有)')[:100]}")
    if not has_warn:
        fails.append("缺类别没有 warn")

    if os.path.exists(out):
        rep = json.load(open(out, encoding="utf-8"))
        mc = rep.get("missing_cats")
        note = (rep.get("plan") or {}).get("note", "")
        print(f"[{'✓' if mc else '✗'}] report.missing_cats = {mc}")
        print(f"[note] {note[:110]}")
        if not mc:
            fails.append("report 里没有 missing_cats")
        if "不含它们" not in note:
            fails.append("plan.note 没有追加「本结论不含它们」")
    else:
        fails.append("plan.json 没写出来")
finally:
    shutil.rmtree(tmp, ignore_errors=True)

print("\nPASS: 未知类别 FATAL、缺类别 warn + note 归因正确"
      if not fails else f"\nFAIL: {fails}")
sys.exit(0 if not fails else 1)
