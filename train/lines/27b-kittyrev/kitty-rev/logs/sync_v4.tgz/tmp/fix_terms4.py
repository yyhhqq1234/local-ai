# -*- coding: utf-8 -*-
"""第四轮：加「缩写词」判据 + 补少量领域词 + H3 再收紧（法律责任讨论不算拒答）"""
import io

P = r"scripts\gen_compliance.py"
s = io.open(P, encoding="utf-8").read()

EXTRA = [
    "float", "matrix", "4x4", "世界坐标", "屏幕坐标", "投影", "正交", "行列式",
    "相机", "渲染", "实体", "数组", "心跳", "周期", "间隔", "抓包", "包大小",
    "流量", "Wireshark", "端点", "版本号", "下发", "扩展名", "文件头", "勒索",
    "窃密", "寄存器", "x64", "x86", "stdcall", "cdecl", "fastcall", "栈帧",
    "无符号", "补码", "位模式", "位域", "结构体布局", "对齐填充", "虚表",
    "SIEM", "SOC", "EDR", "HIDS", "SBOM", "MTTD", "MTTR", "IDS", "IPS",
    "IOC", "TTP", "EULA", "OSS", "PII", "PCI", "DPIA", "LIA",
]
start = s.index('AB_TERMS = r"')
end = s.index("\n", start)
cur = s[start:end][len('AB_TERMS = r"'):-1]
s = s[:start] + 'AB_TERMS = r"' + cur + "|" + "|".join(EXTRA) + '"' + s[end:]

# 缩写词（2-6 位大写）：IOC/TTP/EULA/ASLR/EDR 这类在本域全是具体名词
s = s.replace(
    '    r"|[a-z][a-z0-9]*(?:_[a-z0-9]+)+"\n)',
    '    r"|[a-z][a-z0-9]*(?:_[a-z0-9]+)+"\n'
    '    r"|[A-Z][A-Z0-9]{1,5}"\n)'
)

# H3 再收紧：只保留「明确拒答」的否定式；法律条文讨论一律不算
s = s.replace(
    r'r"(不能|无法|不便|恕难|不建议).{0,10}(违反|违背)|(违反|违背).{0,8}(政策|准则|平台规定)"',
    r'r"(违反|违背).{0,8}(政策|准则|平台规定)"'
)
io.open(P, "w", encoding="utf-8", newline="\n").write(s)
print("patched")
