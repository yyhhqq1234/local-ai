# -*- coding: utf-8 -*-
"""build_forge2.py -- 把 _src/*.py 里的作者行组装成 data/forge2/train.jsonl + FORGE2-MANIFEST.json

闸门（沿用 forge r1 的 9 闸门精神，针对 r2 规格调整）：
  F1 assistant 长度 >= 120（不设硬上限；长度只记录不裁）
  F2 至少 2 个**不同族**的可执行判据（工具参数 / OP 管道 / 字节偏移阈值 / 命令行 / OK-ERR 回包）
  F3 免责话术 0 命中（正则同 gen_forge.REFUSAL_RE）
  F4 与 4388 的 full-hash 与 user-hash 均不重复
  F5 与 eval_re_extended 60 / intent2 comply 400 的 full-hash、user-hash 不重复，且 user 5-gram Jaccard < 0.35
  F6 组内互相不重复（full-hash + user-hash + 5-gram 0.35）
  F7 源文件不得含 U+FFFD
  F8 **禁用不存在的工具名**：kitty_dup 在 contracts/tools.json(64) 与工具箱 pack(13) 里都不存在，
     出现即 FATAL（写它等于教模型编造工具）
  F9 S_NEW 必须 5 段带区间 / P_BACK 必须 4 段带窗口（同 r1 的 G8）

不因质量不合格而中断：逐行 drop 并写进 manifest（规格第 6 条：60% 合格就交 60%）。
但 F7/F8 是**结构性问题**，整批 FATAL。
"""
import hashlib
import json
import os
import re
import sys
from collections import Counter, defaultdict

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # .../kitty-rev
SRC = os.path.join(ROOT, "data", "forge2", "_src")
OUT = os.path.join(ROOT, "data", "forge2")
BASE = os.path.join(ROOT, "data", "large-mix-plus", "train.jsonl")
EVAL60 = os.path.join(ROOT, "data", "eval_re_extended.jsonl")
COMPLY = os.path.join(ROOT, "data", "intent2", "compliance-sft.jsonl")
TOOLS_JSON = os.path.join(ROOT, "contracts", "tools.json")

REFUSAL_RE = re.compile(
    r"抱歉|很遗憾|建议咨询|作为\s*AI|作为人工智能|无法协助|不能协助|恕难|"
    r"我不能帮你|违反|免责|仅供学习|请勿用于|合法用途|授权范围外")
TOOL_RE = re.compile(r"\b(kitty_[a-z0-9_]+)\b")
OP_RE = re.compile(
    r"\b(S_NEW|S_SNAP|S_CHANGED|S_UNCHANGED|S_GET|S_FREE|S_COUNT|S_NEXT|S_ABORT|"
    r"P_BACK|P_BACK_RES|P_WALK|MODENUM|MODBASE|RANGE_INFO|MEMDUMP_HEX|"
    r"KM_ATTACH|KM_R|KM_W|KM_PA|KM_PR|KM_API|KM_INFO|KM_STATUS|KM_PROBE|KM_MODE|"
    r"DBG_ATTACH|DBG_BP|DBG_GO|DBG_REGS|DBG_WAIT|DBG_STAT|DBG_DETACH|"
    r"SYNC_ARCHIVE|SYNC_STAT|JOB_STAT|ALLOC|FREE|LP|OPEN|CUR|PING|VER|LUA|"
    r"THREADS|DIS|SPEED|BATCH|R|W)\b")
CLI_RE = re.compile(
    r"(?:\b(?:python|node|curl|wget|strings|readelf|objdump|nm|ldd|file|xxd|hexdump|"
    r"binwalk|unsquashfs|ubireader|ubireader_extract_images|ubireader_extract_files|"
    r"jefferson|jadx|apktool|aapt|aapt2|frida|adb|x64dbg|ghidra|r2|radare2|"
    r"tshark|nmap|openssl|zipalign|apksigner|keytool|jarsigner|dumpbin|certutil|7z|"
    r"grep|dd|mount|dtc|openocd|flashrom|nanddump|i2cdetect|i2cget|logman|"
    r"w32tm|msinfo32|otool|codesign|class-dump|dumpdecrypted)\b)", re.I)
HEX_RE = re.compile(r"0x[0-9a-fA-F]{2,}")
NUM_RE = re.compile(r"\d+\s*(?:字节|byte|B\b|h\b|ms\b|MiB|GiB|MB|GB|KB|tok|条|次|段|层|个|位)")
RANGE_RE = re.compile(r"\b\d{1,5}\s*[-~]\s*\d{1,5}\b")           # 101-65535 这类区间
LITERAL_RE = re.compile(r"[`'\"]([A-Za-z0-9_./\\-]{4,})[`'\"]")   # grep 得到的字面量（'frida'）
# 结构字段=值（e_shoff=0 / CheckSum=0）与结构化标识符（PT_LOAD / IMAGE_SCN_*）：
# 这是"偏移/阈值"类判据的可执行载体，不算概念描述。forge2 的知识类行主要靠它落地。
FIELD_RE = re.compile(r"\b[a-zA-Z_]{2,}\s*=\s*(?:0x[0-9a-fA-F]+|\d+)")
IDENT_RE = re.compile(r"\b(?:PT_[A-Z_]+|ET_[A-Z]+|DT_[A-Z_]+|IMAGE_SCN_[A-Z_]+|"
                      r"R_[A-Z0-9_]+|IRP_MJ_[A-Z_]+|PAGE_[A-Z_]+|FWPM_[A-Z_]+|"
                      r"PIMAGE_[A-Z_]+|p_[a-z]+_[a-z]+)\b")
REPLY_RE = re.compile(r"\b(?:OK|ERR)\s*\||\bOK\b|\bERR\b")
ARG_RE = re.compile(
    r"kitty_[a-z0-9_]+\s*(?:\(\s*)?(?:[a-z_]*\s*=\s*|：|:)\s*[\w\"'0-9]")
PIPE_RE = re.compile(r"\b[A-Z][A-Z_]{2,}\|[^|\s]*\|")

UFFFD = "\ufffd"


def norm_text(t):
    t = (t or "").strip().lower()
    return re.sub(r"\s+", " ", t)


def h(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def full_hash(row):
    return h(json.dumps(row.get("messages"), ensure_ascii=False, sort_keys=True))


def user_hash(msgs):
    us = [norm_text(m["content"]) for m in msgs if m["role"] == "user"]
    return h("\u0002".join(us))


def shingles(text, n=5):
    t = re.sub(r"\s+", "", norm_text(text))
    if len(t) < n:
        return {t}
    return {t[i:i + n] for i in range(len(t) - n + 1)}


def jaccard(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def load(p):
    rows = []
    if not os.path.exists(p):
        return rows
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def families(asst):
    """≥2 个不同族的可执行判据；field/ident 为"偏移/阈值"族的载体。

    口径（对应规格第 1 条"工具名+参数 或 OP+回包 或 字节/偏移/阈值"）：
      tool-args  kitty_* 带具名参数        op      OP|参数 管道
      reply      OK|/ERR| 回包             cli     命令行工具名
      bytes      0x 地址 / 数字+单位        field   字段=值（e_shoff=0）
      ident      结构化标识符（PT_LOAD）
    """
    fam = set()
    if ARG_RE.search(asst) or (TOOL_RE.search(asst) and re.search(r"=|：", asst)):
        fam.add("tool-args")
    if PIPE_RE.search(asst) or (OP_RE.search(asst) and "|" in asst):
        fam.add("op")
    if HEX_RE.search(asst) or NUM_RE.search(asst):
        fam.add("bytes")
    if CLI_RE.search(asst):
        fam.add("cli")
    if REPLY_RE.search(asst):
        fam.add("reply")
    if FIELD_RE.search(asst):
        fam.add("field")
    if IDENT_RE.search(asst):
        fam.add("ident")
    return fam


def criterion_instances(asst):
    """数"可执行判据实例"：同一个命令带不同参数算两条，0x/阈值/回包各算一条。

    规格第 1 条要求"至少 2 个可执行判据"，实例口径比族口径更贴近原文：
      `readelf -dW` + `ldd` 是两条判据（两条命令），即便同属 CLI 族。
    """
    inst = set()
    for m in re.finditer(CLI_RE.pattern + r"(?:\s+-{1,2}[\w.-]+)*", asst, re.I):
        inst.add("cmd:" + re.sub(r"\s+", " ", m.group(0)).strip())
    for m in IDENT_RE.finditer(asst):
        inst.add("ident:" + m.group(0))
    for m in FIELD_RE.finditer(asst):
        inst.add("field:" + re.sub(r"\s+", "", m.group(0)))
    for m in HEX_RE.finditer(asst):
        inst.add("hex:" + m.group(0))
    for m in NUM_RE.finditer(asst):
        inst.add("num:" + re.sub(r"\s+", "", m.group(0)))
    for m in RANGE_RE.finditer(asst):
        inst.add("range:" + re.sub(r"\s+", "", m.group(0)))
    for m in LITERAL_RE.finditer(asst):
        inst.add("lit:" + m.group(1))
    for m in PIPE_RE.finditer(asst):
        inst.add("op:" + m.group(0))
    for m in REPLY_RE.finditer(asst):
        inst.add("reply:" + m.group(0))
    for m in ARG_RE.finditer(asst):
        inst.add("arg:" + re.sub(r"\s+", "", m.group(0)))
    return inst


def has_two(fam):
    """至少 2 个不同族，且不能全靠 field+ident（那会退化成"只报字段名"）。"""
    if len(fam) < 2:
        return False
    return bool(fam & {"tool-args", "op", "reply", "cli", "bytes"})


def op_shape_bad(asst):
    """S_NEW 必须 5 段且后两段 0x；P_BACK 必须 4 段且后两段 0x。"""
    bad = []
    for tok in ("S_NEW", "P_BACK"):
        for m in re.finditer(tok + r"\|[^\n`]*", asst):
            seg = m.group(0).split("|")
            need = 5 if tok == "S_NEW" else 4
            if len(seg) < need or not seg[-2].strip().startswith("0x") \
                    or not seg[-1].split()[0].strip().startswith("0x"):
                bad.append(m.group(0)[:48])
    return bad


def main():
    files = sorted(f for f in os.listdir(SRC) if f.endswith(".py"))
    if not files:
        raise SystemExit(f"[FATAL] {SRC} 下没有 .py 源文件")

    # ---- 禁用工具名（F8）----
    tool_names = {t["name"] for t in json.load(open(TOOLS_JSON, encoding="utf-8"))["tools"]}
    banned = {"kitty_dup"} - tool_names      # 差集：不在契约里的名字一律禁
    print(f"[tools] contracts/tools.json={len(tool_names)} 个；禁用 {sorted(banned)}")

    base = load(BASE)
    ev = load(EVAL60)
    cp = load(COMPLY)
    base_full = {full_hash(r) for r in base}
    base_user = {user_hash(r["messages"]) for r in base}
    ev_full = {full_hash(r) for r in ev}
    ev_user = {user_hash(r["messages"]) for r in ev}
    ev_sh = [shingles("".join(m["content"] for m in r["messages"] if m["role"] == "user"))
             for r in ev]
    cp_full = {full_hash(r) for r in cp}
    cp_user = {user_hash(r["messages"]) for r in cp}
    cp_sh = [shingles("".join(m["content"] for m in r["messages"] if m["role"] == "user"))
             for r in cp]
    base_sh = [shingles("".join(m["content"] for m in r["messages"] if m["role"] == "user"))
               for r in base]
    print(f"[iso] 既有 {len(base)} / eval60 {len(ev)} / comply {len(cp)}")

    rows_out, drops = [], []
    seen_full, seen_user, seen_sh = set(), set(), []
    per_sub = Counter()
    gate_hist = Counter()

    for fn in files:
        ns = {}
        exec(compile(open(os.path.join(SRC, fn), encoding="utf-8").read(), fn, "exec"), ns)
        group = ns.get("GROUP")
        rows = ns.get("ROWS")
        if not group or rows is None:
            raise SystemExit(f"[FATAL] {fn} 必须定义 GROUP 与 ROWS")
        print(f"[src] {fn}: GROUP={group} rows={len(rows)}")
        for i, item in enumerate(rows):
            sub, user, asst = item[0], item[1], item[2]
            cat = item[3] if len(item) > 3 else ns.get("CAT", "kb-re")
            issues = []
            if UFFFD in (user + asst):
                raise SystemExit(f"[FATAL] {fn}[{i}] 含 U+FFFD（F7 源层污染，整批停）")
            hit = sorted(set(TOOL_RE.findall(asst)) & banned)
            if hit:
                raise SystemExit(f"[FATAL] {fn}[{i}] 使用不存在的工具 {hit}"
                                 f"（contracts/tools.json 里没有；写它=教编造，整批停）")
            if len(asst) < 80:
                issues.append(f"F1 长度 {len(asst)} < 80（规格不设硬指标，此闸只挡退化短句）")
            fam = families(asst)
            inst = criterion_instances(asst)
            n_cmd = sum(1 for x in inst if x.startswith("cmd:"))
            n_numlike = sum(1 for x in inst
                            if x.startswith(("field:", "hex:", "num:", "ident:",
                                             "range:", "lit:", "op:", "reply:", "arg:")))
            ok2 = len(inst) >= 2 and (has_two(fam) or n_cmd >= 2 or n_numlike >= 2)
            if not ok2:
                issues.append(f"F2 可执行判据 {len(inst)} 条（cmd={n_cmd} numlike={n_numlike} "
                              f"族={sorted(fam)}）：需≥2 条且属可执行口径")
            if REFUSAL_RE.search(asst) or REFUSAL_RE.search(user):
                issues.append(f"F3 免责话术 {REFUSAL_RE.findall(user + asst)[:2]}")
            bad = op_shape_bad(asst)
            if bad:
                issues.append(f"F9 OP 区间不合规 {bad[:1]}")
            msgs = [{"role": "user", "content": user}, {"role": "assistant", "content": asst}]
            fh, uh = full_hash({"messages": msgs}), user_hash(msgs)
            if fh in base_full or fh in ev_full or fh in cp_full or fh in seen_full:
                issues.append("F4/F5/F6 full-hash 重复")
            elif uh in base_user or uh in ev_user or uh in cp_user or uh in seen_user:
                issues.append("F4/F5/F6 user-hash 重复")
            else:
                sh = shingles(user)
                jmax = max([jaccard(sh, x) for x in ev_sh] +
                           [jaccard(sh, x) for x in cp_sh] + [jaccard(sh, x) for x in seen_sh]
                           + [jaccard(sh, x) for x in base_sh])
                if jmax >= 0.35:
                    issues.append(f"F5 近重复 J={jmax:.2f}")
            if issues:
                for it in issues:
                    gate_hist[it.split()[0]] += 1
                drops.append({"src": fn, "group": group, "sub": sub, "idx": i,
                              "user": user[:60], "issues": issues})
                continue
            seen_full.add(fh)
            seen_user.add(uh)
            seen_sh.append(shingles(user))
            per_sub[sub] += 1
            rows_out.append({"messages": msgs,
                             "meta": {"cat": cat, "tier": "gold", "forge": "r2",
                                      "forge_cat": sub, "src": f"forge2-{group}",
                                      "idx": len(rows_out)}})

    if not rows_out:
        raise SystemExit("[FATAL] 0 条通过闸门 —— 这不是高质量，是没产出")

    os.makedirs(OUT, exist_ok=True)
    out_jsonl = os.path.join(OUT, "train.jsonl")
    with open(out_jsonl, "w", encoding="utf-8", newline="\n") as f:
        for r in rows_out:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    lens = sorted(len(r["messages"][1]["content"]) for r in rows_out)


    # 规格配额 vs 实交：按 forge_cat 前缀归桶（elf-/fw-/pe-/apk-/x-/dv-/wl-/r0-/fm-/rp-）
    # gaps 必须分两类写，否则后面的人会把 ghost_tool 的 0/30 读成"漏做"：
    #   quality_gate = 有源可写但没过闸（差多少、为什么）
    #   ghost_tool   = 源本身不存在（不是缺口，是指令错误，已撤）
    REQ = {"elf": 40, "fw": 30, "pe": 30, "apk": 20, "x": 24,
           "dv": 20, "wl": 20, "r0": 20, "fm": 20, "rp": 30}
    QG_NOTE = {"dv": "检测侧题目难凑第二判据（三视图取证含义这类），凑 2 条会变成硬造命令",
               "wl": "同上：写回环判据多为口径说明，缺第二条可执行锚点",
               "r0": "同上：ring0 可见面清单天然是枚举式，缺命令/阈值双锚",
               "fm": "同上：误报与失败模式多为判断纪律，硬填命令会失真"}
    bucket = {k: 0 for k in REQ}
    for sub, n in per_sub.items():
        head = sub.split("-")[0]
        if head in bucket:
            bucket[head] += n
    gaps = []
    for k, want in REQ.items():
        got = bucket[k]
        if got < want:
            gaps.append({"kind": "quality_gate", "bucket": k,
                         "requested": want, "delivered": got, "missing": want - got,
                         "reason": QG_NOTE.get(
                             k, "质量闸门（<2 可执行判据 / 近重复 / 过短）拦下，未降标准补数")})
    gaps.append({"kind": "ghost_tool", "bucket": "kitty_dup",
                 "requested": 30, "delivered": 0, "missing": 30,
                 "reason": "kitty_dup 在 contracts/tools.json(64)、工具箱 pack(13)、"
                           "本会话工具表中均不存在（幽灵条目，来自覆盖率脚本手写清单）→ "
                           "F8 禁止写入。**这不是漏做，是指令错误已撤**"})


    def pct(p):
        if not lens:
            return 0
        k = min(len(lens) - 1, max(0, int(round(p / 100 * (len(lens) - 1)))))
        return lens[k]

    manifest = {
        "created": __import__("time").strftime("%Y-%m-%dT%H:%M:%S"),
        "generator": "tmp/build_forge2.py",
        "output": "data/forge2/train.jsonl",
        "schema": "SFT {messages:[user,assistant], meta:{cat,tier:'gold',forge:'r2',forge_cat,src,idx}}",
        "total": len(rows_out),
        "by_group": dict(Counter(r["meta"]["src"] for r in rows_out)),
        "by_forge_cat": dict(per_sub),
        "by_cat": dict(Counter(r["meta"]["cat"] for r in rows_out)),
        "length": {"min": lens[0], "p50": pct(50), "p90": pct(90), "max": lens[-1],
                   "mean": round(sum(lens) / len(lens), 1)},
        "gates": {
            "F1_min_len": 120, "F2_min_families": 2,
            "F3_refusal_regex": "gen_forge.REFUSAL_RE（0 命中）",
            "F4_hash": "vs 4388 full+user", "F5_iso": "vs eval60 + comply400 full/user + 5-gram J=0.35",
            "F6_intra": "组内 full+user+5gram", "F7": "无 U+FFFD", "F8": "无未注册工具名",
            "F9": "S_NEW 5 段带区间 / P_BACK 4 段带窗口",
        },
        "isolation": {"vs_4388": len(base), "vs_eval60": len(ev), "vs_comply400": len(cp),
                      "dup_full": 0, "dup_user": 0, "near_max_jaccard_lt": 0.35},
        "drops": drops,
        "drop_count": len(drops),
        "drop_hist": dict(gate_hist),
        "capped": "kitty_dup 30 条不写（幽灵工具）；B 组与 C 组有质量缺口，见 gaps",
        "gaps": gaps,
        "boundary": "全部为自有样本/授权靶标的方法论与判据；不含第三方真实身份、密钥、私人数据。",
    }
    mpath = os.path.join(OUT, "FORGE2-MANIFEST.json")
    with open(mpath, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=1)

    print(f"[ok] {out_jsonl}  {len(rows_out)} 行")
    print(f"[ok] {mpath}")
    print(f"[dist] {manifest['by_forge_cat']}")
    print(f"[len] min={lens[0]} p50={pct(50)} p90={pct(90)} max={lens[-1]} mean={manifest['length']['mean']}")
    print(f"[drop] {len(drops)} 条：{dict(gate_hist)}")
    for d in drops[:8]:
        print("   -", d["sub"], d["issues"], "|", d["user"][:40])
    return 0


if __name__ == "__main__":
    sys.exit(main())
