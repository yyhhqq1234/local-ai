# -*- coding: utf-8 -*-
"""patch_cache_fp.py -- 给 train_partial_lora.py 加"消费侧 base 指纹守卫"。

三点改动（都幂等：已存在则跳过）：
  1) argparse: --expect-base-fp / --allow-cache-base-mismatch
  2) 模块级 check_cache_base_fp()（不符 FATAL，打印两边 fp + 前 3 差异项）
  3) 三处 MultiCache 构造后各调一次（train / val / refusal）
"""
import io
import os
import sys

P = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                 "scripts", "train_partial_lora.py")
src = io.open(P, encoding="utf-8").read()
orig = src

# ---------------- 1) argparse ------------------------------------------------
A = '    ap.add_argument("--act-cache", default=None, help="单源 act-cache 目录（*.pt）")'
ADD = A + '''
    ap.add_argument("--expect-base-fp", default="",
                    help="期望的 base 指纹（precompute manifest 的 model_fp；JSON 串或 "
                         "config16/index16/first_shard16 十六进制）。不给则只记录不比对")
    ap.add_argument("--allow-cache-base-mismatch", action="store_true",
                    help="显式放行 act-cache 与 base 指纹不符（会打印 WARNING；默认关）")'''
if "--expect-base-fp" not in src:
    assert A in src, "anchor A 未命中"
    src = src.replace(A, ADD, 1)

# ---------------- 2) 守卫函数 ------------------------------------------------
HELPERS = '''
# --------------------------------------------------------------------------- #
# 消费侧 base 指纹守卫（v4 起）
#   precompute 侧已有 model_fp + resume 比对（t28 覆盖），但**新目录没有 resume**：
#   把 v3 的 act-cache 拷成 act-cache-v4 传进来，precompute 一次都不会跑。
#   同架构 ⇒ hidden/labels 形状完全一致 ⇒ 不报错、loss 照常下降 ⇒ 静默训错。
#   所以 trainer 这一侧必须再查一次，这是"缓存与 base 逐比特绑定"的唯一兜底。
# --------------------------------------------------------------------------- #
def _fp_diffs(old, new):
    keys = sorted(set(old or {}) | set(new or {}))
    return [f"model_fp.{k}: 期望={ (old or {}).get(k)!r} 实际={ (new or {}).get(k)!r}"
            for k in keys if (old or {}).get(k) != (new or {}).get(k)]


def resolve_expect_fp(a):
    """--expect-base-fp 优先；否则从 --base-shards / --layer-dir 现场算。"""
    raw = (getattr(a, "expect_base_fp", "") or "").strip()
    if raw:
        try:
            return json.loads(raw), "--expect-base-fp"
        except Exception:
            return {"config16": raw}, "--expect-base-fp(raw)"
    for p in (getattr(a, "base_shards", None), getattr(a, "layer_dir", None)):
        if not p:
            continue
        has_index = os.path.exists(os.path.join(p, "model.safetensors.index.json"))
        has_shard = bool(glob.glob(os.path.join(p, "*.safetensors")))
        if not (has_index or has_shard):
            continue
        try:
            here = os.path.dirname(os.path.abspath(__file__))
            if here not in sys.path:
                sys.path.insert(0, here)
            from precompute_activations import model_fingerprint
            return model_fingerprint(p), os.path.abspath(p)
        except Exception as e:                                    # noqa: BLE001
            print(f"[cache-fp][warn] 无法从 {p} 计算指纹（{type(e).__name__}: {e}）")
    return None, ""


def check_cache_base_fp(cache, expect_fp, expect_src, allow_mismatch, label="train"):
    """每个 act-cache 源的 manifest.model_fp 与期望指纹比对。"""
    if cache is None:
        return
    if not expect_fp:
        print(f"[cache-fp][warn] {label}: 未给 --expect-base-fp 且无法从模型目录推导 ——"
              f" 本次不校验缓存与 base 的绑定（只记录各源指纹）")
    n_ok = n_warn = 0
    for s in cache.specs:
        mf = os.path.join(s["root"], "manifest.json")
        if not os.path.exists(mf):
            print(f"[cache-fp][warn] {label}/{s['name']}: 无 manifest.json，无法证明来源")
            n_warn += 1
            continue
        try:
            m = json.load(open(mf, encoding="utf-8"))
        except Exception as e:                                    # noqa: BLE001
            raise SystemExit(f"[FATAL] {mf} 读取失败: {e}")
        got = m.get("model_fp")
        if not got:
            raise SystemExit(
                f"[FATAL] {mf} 没有 model_fp：旧版缓存，无法证明来自哪份权重。\\n"
                f"        act-cache 与 base 逐比特绑定（同架构=同形状=不会报错），"
                f"重建该源后再训：\\n"
                f"        precompute_activations.py --model <本次 base> ... --out {s['root']}")
        if not expect_fp:
            print(f"[cache-fp] {label}/{s['name']}: config16={got.get('config16')} "
                  f"idx16={got.get('index16')} shard16={got.get('first_shard16')}（未比对）")
            n_ok += 1
            continue
        diffs = _fp_diffs(expect_fp, got)
        if not diffs:
            print(f"[cache-fp] {label}/{s['name']}: 一致（来自 {expect_src}）"
                  f" config16={got.get('config16')} shard16={got.get('first_shard16')}")
            n_ok += 1
            continue
        head = "；".join(diffs[:3])
        if allow_mismatch:
            print(f"[cache-fp][WARNING] {label}/{s['name']} 与 base 指纹不符，"
                  f"因 --allow-cache-base-mismatch 放行：{head}")
            n_warn += 1
            continue
        raise SystemExit(
            f"[FATAL] act-cache 与 base 指纹不符（{label}/{s['name']}，{s['root']}）：\\n"
            f"        cache.model_fp = {got}\\n"
            f"        期望 base      = {expect_fp}（来源 {expect_src}）\\n"
            f"        差异 {len(diffs)} 项，前 3 项：{head}\\n"
            f"        形状一致不会报错，训练会静默跑在错误激活上。\\n"
            f"        重建该源，或确属实验目的再显式加 --allow-cache-base-mismatch。")
    if n_warn:
        print(f"[cache-fp][warn] {label}: {n_warn} 个源未通过指纹校验")


'''
if "def check_cache_base_fp(" not in src:
    anchor = "class MultiCache:"
    assert anchor in src, "anchor class MultiCache 未命中"
    src = src.replace(anchor, HELPERS.lstrip("\n") + anchor, 1)

# ---------------- 3) 三处调用 ------------------------------------------------
C1 = "    cache = MultiCache(build_specs(a.data_mix, a.act_cache), a.ctx, a.limit)"
if "check_cache_base_fp(cache" not in src:
    assert C1 in src, "anchor C1 未命中"
    src = src.replace(
        C1,
        C1 + '\n    check_cache_base_fp(cache, *resolve_expect_fp(a), a.allow_cache_base_mismatch, "train")',
        1)

C2 = "    val_cache = MultiCache(build_specs(a.eval_cache), a.ctx) if a.eval_cache else None"
if C2 in src and "check_cache_base_fp(val_cache" not in src:
    src = src.replace(
        C2,
        C2 + '\n    check_cache_base_fp(val_cache, *resolve_expect_fp(a), '
             'a.allow_cache_base_mismatch, "val")',
        1)

C3 = "            ref_cache = MultiCache(build_specs(a.refusal_cache), a.ctx)"
if C3 in src and "check_cache_base_fp(ref_cache" not in src:
    src = src.replace(
        C3,
        C3 + '\n            check_cache_base_fp(ref_cache, *resolve_expect_fp(a), '
             'a.allow_cache_base_mismatch, "refusal")',
        1)

if src == orig:
    print("[skip] 已打过补丁（无改动）")
else:
    io.open(P, "w", encoding="utf-8", newline="\n").write(src)
    print(f"[ok] patched {P}  +{len(src) - len(orig)} 字符")
