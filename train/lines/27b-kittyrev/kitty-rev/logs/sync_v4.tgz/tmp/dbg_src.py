# -*- coding: utf-8 -*-
import sys, os
SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts", "forge_src")
sys.path.insert(0, SRC)
import importlib

specs = [("pe_structure_a","PE_A"),("pe_structure_b","PE_B"),
         ("op_semantics_a","OP_A"),("op_semantics_b","OP_B"),
         ("chain_a1","CHAIN_A1"),("chain_a2","CHAIN_A2"),("chain_a3","CHAIN_A3"),
         ("det_a","DET_A"),("det_b","DET_B")]
for m, v in specs:
    seq = getattr(importlib.import_module(m), v)
    print(m, v, "count=", len(seq))
    for i, (u, a) in enumerate(seq):
        for k, s in enumerate((u, a)):
            p = s.find("\ufffd")
            if p >= 0:
                print(f"   [{i}][{'user' if k==0 else 'asst'}] ctx={s[max(0,p-24):p+24]!r}")
    us = [x[0] for x in seq]
    d = sorted({u for u in us if us.count(u) > 1})
    if d:
        print("   DUP users:", d)
