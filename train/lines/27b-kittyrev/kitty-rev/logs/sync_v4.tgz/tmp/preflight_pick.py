# -*- coding: utf-8 -*-
"""preflight_pick.py -- 训练 DONE 后跑 pick_checkpoint 之前的一分钟体检（只读）。

设计原则（§14 签名 S1/S5/S6 的教训）：
  · 所有**期望值**都从 manifest 读，不在脚本里写死 —— 否则 forge 一扩容，
    这份体检自己先假红（把好的数据报成坏的）。
  · 「数据变了」与「清单坏了」分开报：前者是扩容（--allow-row-drift 放行，
    并提醒重跑 make_subsets），后者是清单 identity 不成立（永远 FAIL）。
  · 只核「子集 ↔ manifest」不够：两个 val 文件之间若重行，VAL_WEIGHT 的
    re-val 2.0 / forge-val 1.0 会被悄悄放大成 3 倍 —— 所以再核 uhash 交集。

检查项：
  1) 文件存在 + 行数（期望值全部来自 manifest；仅 eval.jsonl 无 manifest）
  2) sha256_16（行数不变、内容换过也能抓到）
  3) manifest identity（corruption 永不放行；数据 drift 单独报）
  4) 跨文件重叠：re-train∩re-val、forge-train∩forge-val、re-val∩forge-val 全为 0
  5) pick_checkpoint --dry-run 的 val 数 == 实测两个 val 之和

用法：
  python tmp/preflight_pick.py                    # 严格
  python tmp/preflight_pick.py --allow-row-drift  # 数据有意扩容时放行「行数变了」

口径说明（两个数都对，别混用）：
  · **行数**：val 里有几行与 train 同问 → re-val 是 14/72 = 19.4%（pick_checkpoint 的
    `same_q` 就是这个口径，本脚本 Section 5 按它对账）。
  · **唯一问句**：同一问句在 val 内重复出现（72 行 / 67 唯一 user）→ 14 行只对应 10 个问句。
  实测三种指纹（user 侧 / system+user / 整条 messages）在**行数**上都是 14；
  整条指纹看不出来（同问不同答时整条必然不同），所以答案指纹必须单独算。
  一句话：口径差异不在哈希，在「按行还是按问句」。
"""
import argparse
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys

os.environ.setdefault("PYTHONIOENCODING", "utf-8")
os.environ.setdefault("PYTHONUTF8", "1")
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
KITTY = os.path.dirname(HERE)
PY = sys.executable
fails, warns = [], []


def load_mod(rel, name):
    spec = importlib.util.spec_from_file_location(name, os.path.join(KITTY, rel))
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


# 复用 merge_forge 的 norm/hh/uhash —— 同一套哈希口径，不在这里另写一份
MF = load_mod("scripts/merge_forge.py", "merge_forge_preflight")


def jlines(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def nrows(p):
    with open(p, "rb") as f:
        return sum(1 for line in f if line.strip())


def sha16(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--allow-row-drift", action="store_true",
                    help="数据有意扩容时放行「行数与 manifest 不同」（清单 corruption 仍 FAIL）")
    ap.add_argument("--allow-val-overlap", action="store_true",
                    help="已知并裁决过 train/val 同问句时，把重叠降为 warn（默认 FAIL）")
    a = ap.parse_args()

    sub_man = json.load(open(os.path.join(KITTY, "data", "subsets", "subsets_manifest.json"),
                             encoding="utf-8"))
    re_man = json.load(open(os.path.join(KITTY, "data", "eval_re_extended_manifest.json"),
                            encoding="utf-8"))

    def drift(msg):
        (warns.append(msg) if a.allow_row_drift else fails.append(msg))

    # ---------------- 1) 行数（期望值 = manifest，非硬编码） ----------------
    print("=== 1) 行数（期望值来自 manifest）===")
    jobs = [
        ("data/subsets/re-subset.val.jsonl", sub_man["groups"]["re"]["files"]["val"]["rows"], "subsets_manifest.re.val"),
        ("data/subsets/forge-subset.val.jsonl", sub_man["groups"]["forge"]["files"]["val"]["rows"], "subsets_manifest.forge.val"),
        ("data/subsets/re-subset.train.jsonl", sub_man["groups"]["re"]["files"]["train"]["rows"], "subsets_manifest.re.train"),
        ("data/subsets/forge-subset.train.jsonl", sub_man["groups"]["forge"]["files"]["train"]["rows"], "subsets_manifest.forge.train"),
        ("data/eval_re_extended.jsonl", re_man["rows"], "eval_re_extended_manifest"),
        # eval.jsonl 是唯一没有 manifest 的判据集（23 题基线）—— 无源可读，标明来源
        ("data/eval.jsonl", 23, "人工基线(无manifest)"),
    ]
    live = {}
    for rel, want, src in jobs:
        p = os.path.join(KITTY, rel)
        if not os.path.isfile(p):
            fails.append(f"缺文件 {rel}")
            print(f"[✗] {rel} 不存在")
            continue
        got = nrows(p)
        live[rel] = got
        ok = got == want
        tag = "✓" if ok else ("≈" if a.allow_row_drift else "✗")
        print(f"[{tag}] {rel:42s} {got:4d} 行（期望 {want:4d} ← {src}）")
        if not ok:
            drift(f"{rel} 行数 {got} != manifest {want}：数据变了（有意扩容→--allow-row-drift，"
                  f"然后重跑 make_subsets；否则查是谁改的）")

    # ---------------- 2) sha16 ----------------
    print("\n=== 2) 内容同源（sha256_16 vs manifest）===")
    for g in ("re", "forge"):
        for split in ("train", "val"):
            rec = sub_man["groups"][g]["files"][split]
            p = os.path.join(KITTY, "data", "subsets", rec["file"])
            if not os.path.isfile(p):
                continue
            got, want = sha16(p), rec["sha256_16"]
            ok = got == want
            print(f"[{'✓' if ok else '✗'}] {g}-{split:5s} {got} vs {want}")
            if not ok:
                drift(f"{g}-{split} sha16 {got} != manifest {want}（行数没变但内容被改过）")
    p = os.path.join(KITTY, "data", "eval_re_extended.jsonl")
    if os.path.isfile(p) and "sha256_16" in re_man:
        got, want = sha16(p), re_man["sha256_16"]
        ok = got == want
        print(f"[{'✓' if ok else '✗'}] eval_re_extended {got} vs {want}")
        if not ok:
            # md5 判定三件套：sha + mtime + 谁改的。清单旧于数据 = 清单过期，
            # 数据旧于清单 = 数据被事后改动（这两种的处理方向相反，不能混成一句）。
            t_data = os.path.getmtime(p)
            t_man = os.path.getmtime(os.path.join(KITTY, "data", "eval_re_extended_manifest.json"))
            if t_man < t_data:
                warns.append(
                    f"eval_re_extended 清单过期：数据 {got} 写于 "
                    f"{__import__('time').strftime('%H:%M', __import__('time').localtime(t_data))}，"
                    f"清单 {want} 写于 "
                    f"{__import__('time').strftime('%H:%M', __import__('time').localtime(t_man))} "
                    f"→ 需重生成清单的 sha/bytes（不是数据坏；别直接跑 make_re_eval 默认参数）")
                print(f"     [≈] 清单旧于数据（{got[:8]} 数据较新）→ 判为清单过期，不判数据坏")
            else:
                fails.append(f"eval_re_extended 内容与清单不符且清单不比数据旧："
                             f"{got} != {want}（数据被事后改动？）")

    # ---------------- 3) manifest identity ----------------
    print("\n=== 3) manifest identity（corruption 永不放行）===")
    src = os.path.join(KITTY, "data", "large-mix-plus", "train.jsonl")
    live_n = nrows(src) if os.path.isfile(src) else -1
    m_rows, sumg, un = sub_man.get("rows"), sub_man.get("sum_groups"), sub_man.get("unassigned")
    print(f"    manifest: rows={m_rows} Σ组={sumg} 未分组={un} identity_ok={sub_man.get('identity_ok')}")
    print(f"    实测 large-mix-plus = {live_n} 行（manifest 记录 {m_rows}）")
    if live_n != m_rows:
        drift(f"数据变了：large-mix-plus 实测 {live_n} != manifest {m_rows}"
              f"（扩容→--allow-row-drift + 重跑 make_subsets；否则是数据被误改）")
    if not (isinstance(sumg, int) and isinstance(un, int) and m_rows == sumg + un):
        fails.append(f"清单自身不成立：rows={m_rows} != Σ组 {sumg} + 未分组 {un}"
                     f"（corruption，与数据无关，别去查数据）")
    if not sub_man.get("identity_ok"):
        fails.append("manifest identity_ok=False（清单自检没过）")

    # ---------------- 4) 跨文件重叠 ----------------
    print("\n=== 4) 重叠：train∩val、re-val∩forge-val ===")

    cache = {}

    def rows_of(rel):
        if rel not in cache:
            p = os.path.join(KITTY, "data", "subsets", rel)
            cache[rel] = jlines(p) if os.path.isfile(p) else []
        return cache[rel]

    def umap(rel):
        m = {}
        for r in rows_of(rel):
            m.setdefault(MF.uhash(r.get("messages") or []), []).append(r)
        return m

    pairs = [
        ("re-train", "re-subset.train.jsonl", "re-val", "re-subset.val.jsonl", False),
        ("forge-train", "forge-subset.train.jsonl", "forge-val", "forge-subset.val.jsonl", False),
        ("re-val", "re-subset.val.jsonl", "forge-val", "forge-subset.val.jsonl", True),
    ]
    for na, fa, nb, fb, is_val_pair in pairs:
        ua, ub = umap(fa), umap(fb)
        inter = set(ua) & set(ub)
        ok = not inter
        print(f"[{'✓' if ok else '✗'}] uhash({na}) ∩ uhash({nb}) = {len(inter)}")
        if ok:
            continue
        # 分类：同一问句同一答案 = 真泄漏；同一问句不同答案 = 标签冲突（学不到，只会抖）
        same = [h for h in inter
                if MF.fhash(ua[h][0]["messages"]) == MF.fhash(ub[h][0]["messages"])]
        conflict = len(inter) - len(same)
        # 「条数」有两个口径，必须都报：唯一问句数（inter）与受影响 val 行数（rows_hit）。
        # 只报一个就会与 pick_checkpoint 的 same_q（按行）差 4 —— 数字没错，解释错了。
        rows_hit = sum(1 for r in rows_of(fb) if MF.uhash(r.get("messages") or []) in ua)
        print(f"     ↳ 完全重复（同问同答）{len(same)} 个问句 · 标签冲突（同问不同答）{conflict} 个问句")
        print(f"     ↳ 受影响 {nb} 行数 {rows_hit}/{len(rows_of(fb))}"
              f"（{100.0 * rows_hit / max(1, len(rows_of(fb))):.0f}% 行权重；"
              f"唯一问句 {len(inter)}，重复问句使行数 > 问句数）")
        for h in (same or list(inter))[:3]:
            q = next((m["content"][:60] for m in ua[h][0]["messages"] if m["role"] == "user"), "")
            print(f"       例：{q!r}")
        msg = (f"{nb} 有 {rows_hit}/{len(rows_of(fb))} 行"
               f"（{100.0 * rows_hit / max(1, len(rows_of(fb))):.1f}%）与 {na} 同问不同答"
               f"——唯一问句 {len(inter)} 个（重复问句把行数放大）"
               + ("；val 权重被叠加：re-val 2.0 + forge-val 1.0 = 3 倍" if is_val_pair else
                  "；val 里出现训练原题，val_loss 偏乐观"))
        (warns.append(msg) if a.allow_val_overlap else fails.append(msg))
    for rel in ("re-subset.val.jsonl", "forge-subset.val.jsonl"):
        u = umap(rel)
        n = live.get(f"data/subsets/{rel}", 0)
        if len(u) != n:
            warns.append(f"{rel} 内部重复 user 样本：{n} 行 / {len(u)} 唯一（不跨文件，但重复计权）")
            print(f"[≈] {rel} {n} 行 / {len(u)} 唯一 user")
        else:
            print(f"[✓] {rel} {n} 行 / {n} 唯一 user")

    # ---------------- 5) pick_checkpoint --dry-run ----------------
    # 注：不在这里落 val-audit.json —— audit-fix-2 已在 pick_checkpoint 里原生实现
    # `--train-data` + val_train_overlap()（第 21 例）。同一事实两处实现 = 两个真相源，
    # 这里改为**交叉校验**：他们打出的「答案不同 K」必须等于本脚本按**行**统计的同一个数。
    print("\n=== 5) pick_checkpoint --dry-run（带 --train-data，核 val↔train 同问）===")
    want_val = (live.get("data/subsets/re-subset.val.jsonl", 0)
                + live.get("data/subsets/forge-subset.val.jsonl", 0))
    cmd = [
        PY, os.path.join(KITTY, "scripts", "pick_checkpoint.py"), "--dry-run",
        "--base-model", "base/Qwen3.8-27B",
        "--candidates", "245:out/checkpoint-245,490:out/checkpoint-490,full3ep:out/adapter-full3ep",
        "--re-eval", "data/eval_re_extended.jsonl",
        "--kitty-eval", "data/eval.jsonl",
        "--val-data", "data/subsets/re-subset.val.jsonl,data/subsets/forge-subset.val.jsonl",
        "--train-data", "data/subsets/re-subset.train.jsonl,data/subsets/forge-subset.train.jsonl",
        "--refresh",
        "--out", "logs/pick",
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", cwd=KITTY, timeout=120)
    txt = (r.stdout or "") + (r.stderr or "")
    plan = next((l for l in txt.splitlines() if l.startswith("[plan] 评测集")), "")
    print(f"[{'✓' if r.returncode == 0 else '✗'}] rc={r.returncode}  {plan}")
    if r.returncode != 0:
        fails.append(f"dry-run rc={r.returncode}: {txt.strip().splitlines()[-1:]}")
    elif f"val={want_val}" not in plan:
        fails.append(f"dry-run 的 val 与实测之和不符（期望 {want_val}）: {plan!r}")

    # 交叉校验：pick_checkpoint 的 same_q 按**行**统计，本脚本按**唯一问句**统计，
    # 所以比对的是行数（14），不是问句数（10）—— 两个数都对，混用才是错。
    ov = next((l for l in txt.splitlines()
               if l.startswith("[plan] val re-subset.val.jsonl")), "")
    print(f"    {ov or '(没打出 re-val 的同问行)'}")
    re_train = umap("re-subset.train.jsonl")
    rows_hit_re = sum(1 for r in rows_of("re-subset.val.jsonl")
                      if MF.uhash(r.get("messages") or []) in re_train)
    m = re.search(r"答案不同\s*(\d+)", ov or "")
    if m:
        k = int(m.group(1))
        same = k == rows_hit_re
        print(f"[{'✓' if same else '✗'}] 交叉校验（按行）：pick 自算 {k} vs preflight 自算 {rows_hit_re}"
              f"（唯一问句 {len(re_train) and len(set(re_train) & set(umap('re-subset.val.jsonl')))}）")
        if not same:
            fails.append(f"两处实现不一致：pick_checkpoint diff_a={k} vs preflight={rows_hit_re} 行"
                         f"（哈希口径不同，选一个为准）")
    elif r.returncode == 0:
        fails.append("pick_checkpoint 没打出 re-val 的同问行：--train-data 没生效？")
    for line in txt.splitlines():
        if line.startswith("[cand]"):
            print(f"     {line}   （本地不存在属正常，路径是云端的）")

    # ---------------- 6) 可粘贴命令 ----------------
    print("\n=== 6) 训练 DONE 后的命令（末尾加 --dry-run 可先空跑）===")
    print("cd /root/autodl-tmp/kitty-rev")
    print("python kitty-rev/scripts/pick_checkpoint.py \\")
    print("  --base-model base/Qwen3.8-27B \\")
    print('  --candidates "245:out/checkpoint-245,490:out/checkpoint-490,full3ep:out/adapter-full3ep" \\')
    print("  --re-eval kitty-rev/data/eval_re_extended.jsonl \\")
    print("  --kitty-eval kitty-rev/data/eval.jsonl \\")
    print('  --val-data "kitty-rev/data/subsets/re-subset.val.jsonl,kitty-rev/data/subsets/forge-subset.val.jsonl" \\')
    print('  --train-data "kitty-rev/data/subsets/re-subset.train.jsonl,kitty-rev/data/subsets/forge-subset.train.jsonl" \\')
    print("  --refresh \\")
    print("  --out logs/pick")
    print("# --refresh 必带：旧 logs/pick/*.json 没有 span_scheme 戳（第 20 例，缓存不看版本），")
    print("#   不带会 FATAL；复用旧产物 = 用旧 val_loss 算法选 checkpoint，报告却看不出来")

    if warns:
        print("\n[warn] " + "\n[warn] ".join(warns))
    print("\nPASS: 选优前置全部就绪（行数/sha16/identity/重叠/dry-run 全对）"
          if not fails else f"\nFAIL: {fails}")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
