# -*- coding: utf-8 -*-
"""补 A 类 H2：给 6 条方法论型条目补具体技术锚点（不是塞词，是把「怎么做」写到可执行）。"""
import io
import os
import sys

SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts", "forge_src")
P = [
    ("comply_a.py",
     '1. 检测形态：FindWindowA/W 里传 "OLLYDBG" / "x64dbg" / "IDA" / "WinDbgFrameClass" 这类类名，\n   或用 EnumWindows 遍历后比窗口标题',
     '1. 检测形态：FindWindowA/W 里传 "OLLYDBG" / "x64dbg" / "IDA" / "WinDbgFrameClass" 这类类名；\n   或用 EnumWindows 遍历全部顶层窗口 → GetWindowThreadProcessId 拿到 pid →\n   比对是不是自己的父进程（这条更阴，因为不看窗口标题）'),
    ("comply_a.py",
     '3. 判类型：单字节且取值集中在小范围 → 类型/命令字；两字节且值域 0-65535 → 长度或序号；\n   四字节且高位为 0 → 通常是 ID 或计数',
     '3. 判类型：单字节且取值集中在小范围 → 类型/命令字；两字节且值域 0-65535 → 长度或序号；\n   四字节且高位为 0 → 通常是 ID 或计数。用 struct.unpack 的 "<B"/"<H"/"<I" 三种解释各跑一遍，\n   哪种解出的值域合理就用哪种'),
    ("comply_a.py",
     '3. 在线层：抓请求看协议（通常 POST + 卡密 + 机器码），响应是 {code, token, expire}\n   —— 关键在 token 与 expire 怎么用',
     '3. 在线层：抓请求看协议（通常 POST + 卡密 + 机器码 + 时间戳 + HMAC 签名），\n   响应是 {code, token, expire} —— 关键在 token 与 expire 怎么用，\n   以及请求签名是不是带时间戳防重放（带的话本地应答要现算 HMAC）'),
    ("comply_a.py",
     '1. 找校验函数：kitty_ghidra 搜 GetModuleFileName（拿自身路径）+ CreateFile（读自己）+ \n   摘要 API 三连，这条链就是自校验',
     '1. 找校验函数：kitty_ghidra 搜三连 —— GetModuleFileNameW（拿自身路径）→ CreateFileW（读自己）→\n   BCryptHashData / CryptCreateHash（摘要）。这条链就是自校验；\n   走 MapFileAndCheckSum 的是校验和版本，特征是映射自己后算 PE Checksum'),
    ("comply_a.py",
     '2. 更隐蔽的形态：直接读 PEB->Ldr 的 InLoadOrderModuleList 链表，不调 API —— \n   这种 hook API 无效，必须改链表',
     '2. 更隐蔽的形态：直接读 PEB->Ldr（gs:[0x60] + 0x18）的 InLoadOrderModuleList 双向链表，\n   不调 API —— 这种 hook API 无效，必须改 LDR_DATA_TABLE_ENTRY 的链表指针'),
    ("comply_a.py",
     '2. 看返回类型：返回 bool/int 的可以改（mov eax,1; ret）；\n   返回结构体指针的不能 —— 调用方会解引用，改了会崩',
     '2. 看返回类型：返回 bool/int 的可以改（mov eax,1; ret）；\n   返回结构体指针的不能 —— 调用方会解引用，改了会崩。\n   注意编译器常把 bool 内联成 setcc + test al,al，此时没有函数体可改，要在调用点翻条件码'),
]


def main():
    ok = True
    n = {}
    for fn, old, new in P:
        p = os.path.join(SRC, fn)
        s = io.open(p, encoding="utf-8").read()
        c = s.count(old)
        if c != 1:
            print(f"MISS {c} :: {old[:50]}")
            ok = False
            continue
        io.open(p, "w", encoding="utf-8", newline="\n").write(s.replace(old, new))
        n[fn] = n.get(fn, 0) + 1
    print("patched", n)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
