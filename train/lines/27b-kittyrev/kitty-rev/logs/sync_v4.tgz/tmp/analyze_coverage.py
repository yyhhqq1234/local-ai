#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""训练数据覆盖度分析 —— 只读，不改任何数据。
输出：各类目条数 / 长度分布 / 工具命中 / 代表性提问抽样。
"""
import json
import os
import re
import sys
from collections import Counter, defaultdict

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data", "large-mix-plus", "train.jsonl")
SUBS = os.path.join(ROOT, "data", "subsets")

TOOLS = ["kitty_ce", "kitty_km", "kitty_pchain", "kitty_dup", "kitty_dump", "kitty_patch",
         "kitty_asm", "kitty_sym", "kitty_ghidra", "kitty_ida", "kitty_idamcp", "kitty_rea",
         "kitty_x64dbg", "kitty_dbg", "kitty_inject", "kitty_prot", "kitty_wpb", "kitty_acescan",
         "kitty_dualview", "kitty_apkscan", "kitty_jadx", "kitty_frida", "kitty_il2cppdumper",
         "kitty_ue4ss", "kitty_uedump", "kitty_gdre", "kitty_engines", "kitty_variants",
         "kitty_drv", "kitty_drvio", "kitty_init", "kitty_settings", "kitty_trail", "kitty_ops",
         "kitty_patch", "kitty_lua", "kitty_net", "kitty_die", "kitty_bepinex"]


def load(p):
    rows = []
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def cat_of(r):
    m = r.get("meta") or {}
    return m.get("cat") or ("forge:" + str(m.get("forge_cat")) if m.get("forge") else "unknown")


def user_text(r):
    for m in r.get("messages") or []:
        if m.get("role") == "user":
            return m.get("content") or ""
    return ""


def asst_text(r):
    for m in reversed(r.get("messages") or []):
        if m.get("role") == "assistant":
            return m.get("content") or ""
    return ""


def pct(vals, q):
    if not vals:
        return 0
    vals = sorted(vals)
    i = min(len(vals) - 1, max(0, int(round((len(vals) - 1) * q))))
    return vals[i]


def main():
    rows = load(DATA)
    print("=" * 78)
    print("文件 %s" % DATA)
    print("总行数 %d" % len(rows))
    meta_keys = Counter()
    for r in rows:
        for k in (r.get("meta") or {}):
            meta_keys[k] += 1
    print("meta 字段: %s" % dict(meta_keys.most_common()))
    print("=" * 78)

    by = defaultdict(list)
    for r in rows:
        by[cat_of(r)].append(r)

    print("\n## 类目分布")
    print("%-22s %6s %8s %8s %8s %8s" % ("cat", "n", "u_min", "u_avg", "a_avg", "a_max"))
    for c, rs in sorted(by.items(), key=lambda kv: -len(kv[1])):
        ul = [len(user_text(r)) for r in rs]
        al = [len(asst_text(r)) for r in rs]
        print("%-22s %6d %8d %8.0f %8.0f %8d" % (
            c, len(rs), min(ul), sum(ul) / len(ul), sum(al) / len(al), max(al)))

    # 工具覆盖
    print("\n## 工具/OP 覆盖（按出现在 assistant 正文里的次数）")
    cnt = Counter()
    per_cat_tools = defaultdict(set)
    for r in rows:
        a = asst_text(r)
        for t in set(TOOLS):
            if t in a:
                cnt[t] += 1
                per_cat_tools[cat_of(r)].add(t)
    print("命中工具数 %d / 登记 %d" % (len(cnt), len(TOOLS)))
    print("零命中: %s" % [t for t in TOOLS if t not in cnt])
    print("Top20: %s" % dict(cnt.most_common(20)))
    print("\n## 每类的工具广度")
    for c, ts in sorted(per_cat_tools.items(), key=lambda kv: -len(kv[1])):
        print("  %-22s %2d 种  %s" % (c, len(ts), ",".join(sorted(ts)[:12])))

    # 提问形态
    print("\n## 提问形态（user 首 30 字去重后 Top 形态）")
    heads = Counter()
    for r in rows:
        u = user_text(r).strip()
        h = u[:24]
        heads[h] += 1
    dup = [(h, n) for h, n in heads.items() if n > 5]
    print("重复 ≥6 次的提问前缀: %d 组，共 %d 行" % (len(dup), sum(n for _, n in dup)))
    for h, n in sorted(dup, key=lambda x: -x[1])[:12]:
        print("  %3d  %s" % (n, h))

    # 抽样
    print("\n## 每类抽样 3 条（提问前 60 字 / 答前 80 字）")
    for c, rs in sorted(by.items(), key=lambda kv: -len(kv[1])):
        print("\n[%s] n=%d" % (c, len(rs)))
        step = max(1, len(rs) // 3)
        for r in rs[::step][:3]:
            u = user_text(r).replace("\n", " ")[:60]
            a = asst_text(r).replace("\n", " ")[:80]
            print("  Q: %s" % u)
            print("  A: %s" % a)

    # subsets
    print("\n## 已切分子集")
    if os.path.isdir(SUBS):
        for fn in sorted(os.listdir(SUBS)):
            if fn.endswith(".jsonl"):
                p = os.path.join(SUBS, fn)
                n = sum(1 for l in open(p, encoding="utf-8") if l.strip())
                print("  %-38s %5d 行  %8d B" % (fn, n, os.path.getsize(p)))
    mf = os.path.join(SUBS, "subsets_manifest.json")
    if os.path.exists(mf):
        m = json.load(open(mf, encoding="utf-8"))
        print("  manifest: rows=%s sum_groups=%s identity_ok=%s sha16=%s" % (
            m.get("rows"), m.get("sum_groups"), m.get("identity_ok"), m.get("source_sha16")))


if __name__ == "__main__":
    main()
