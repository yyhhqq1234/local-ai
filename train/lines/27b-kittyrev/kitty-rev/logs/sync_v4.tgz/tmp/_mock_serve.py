# -*- coding: utf-8 -*-
"""mock OpenAI endpoint for eval_bare self-check: records each request body."""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

REC = "tmp/_mock_recv.jsonl"
REPLY = ("回包就是一行 `OK|pong`。用 `kitty_ce(op=\"PING\")` 取，"
         "失败则是 `ERR|` 前缀，先看码再决定换路径。")


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n).decode("utf-8", "replace")
        try:
            body = json.loads(raw)
        except Exception:
            body = {"_raw": raw}
        with open(REC, "a", encoding="utf-8") as f:
            f.write(json.dumps({"path": self.path, "keys": sorted(body.keys()),
                                "tools": len(body.get("tools") or []),
                                "n_msg": len(body.get("messages") or [])},
                               ensure_ascii=False) + "\n")
        out = {"choices": [{"message": {"role": "assistant", "content": REPLY,
                                        "tool_calls": []},
                            "finish_reason": "stop"}],
               "usage": {"prompt_tokens": 1, "completion_tokens": 1}}
        b = json.dumps(out, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 18099
    ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()
