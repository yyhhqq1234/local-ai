#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""eval_bare.py -- base-only（无 adapter）评测 wrapper：一份数据，三种判据，口径全部显式打印。

为什么存在
    `pick_checkpoint.py` 的候选必须是 adapter 目录 → 跑不出「base 本身」的数字；
    `eval_re_extended.py` 的判据读 `meta.expect`，而 `data/eval.jsonl`(23) 与
    `data/large-mix/eval.jsonl`(304) 的 meta 只有 cat/tier/tool → 直接跑会全 FAIL
    （v3「0/60 假失败」同族）。所以 base-only 需要一个不带 adapter、不猜口径、
    失败即响的 wrapper。

模块加载口径（不许照抄猜测版，这里是实测值）
    `scripts/eval_re_extended.py` L67-75 是唯一权威：
        p = os.path.join(HERE, "eval", "eval_kitty.py")      # HERE = .../train/kitty-rev
        spec_from_file_location("eval_kitty_re", p)
        sys.modules[spec.name] = mod
    → 真实路径是 **train/kitty-rev/eval/eval_kitty.py**（不是 scripts/eval_kitty.py，
      那个文件不存在；SUPPLEMENT §二 的 40 行草稿照抄了错误路径）。
    本脚本按真实路径/真实模块名加载，并在加载后断言三件事（路径、HERE、必需属性），
    任何一条不符直接 FATAL —— 用错模块会让 ek.SYS / ek.post 口径整体漂移，且不会报错。

FATAL 纪律（本项目 19 个静默错的共同签名：看起来成功，其实跳过了检查）
    · 数据文件缺失 / 0 行                              → FATAL
    · 索引越界 / 重复 / 与固定索引冲突                  → FATAL
    · 行结构缺 user 或缺参考答（判据需要时）             → FATAL（带行号）
    · 判据不可用（auto 选不出）/ cat 不在 RULES        → FATAL
    · 全部请求失败（0 成功）                           → FATAL（带首个异常原文）
    · 全部空答（chars=0）                              → FATAL（S6 家族：模板 EOS）
    · 计数不自洽（n != ok + err）                       → FATAL
    · --out 写后回读行数不符                            → FATAL
    每次 FATAL 都打印 `触发源:` 一行，指明是哪个参数/哪一行/哪个模块触发的。

判据
    expect  eval_re_extended.judge（meta.expect 规则：required/forbidden/order/min_kitty…）
    cat     eval_kitty.judge（RULES 按 meta.cat 分派；cat 必须全部有专属规则，否则 FATAL）
    ref     字符二元组 F1 + 参考覆盖率 recall（bench 行自带 assistant 参考答案）
    none    只记 chars / calls（不算分）

用法
    # 0) 不联网自检
    python tmp/eval_bare.py --selftest
    # 1) dry：只校验数据/选择/判据，不发请求
    python tmp/eval_bare.py --suite bench40 --dry-run
    # 2) bench40（固定 40 条，训练前后同一批）
    python tmp/eval_bare.py --suite bench40 \
        --base http://127.0.0.1:18000 --model huihui-base \
        --out logs/base-only/bench40.json
    # 3) re60（tools=off，与 pick_checkpoint --tools-for kitty 同口径）
    python tmp/eval_bare.py --suite re60 --out logs/base-only/re-eval.json ...
    # 4) kitty23（tools=on，判据要 tool_calls）
    python tmp/eval_bare.py --suite kitty23 ...
"""
import argparse
import hashlib
import importlib.util
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from collections import Counter

try:            # Windows 控制台默认 GBK：ek 在 import 时会把 stdout 切到 utf-8，
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")   # 不先切会造成半程乱码
except Exception:
    pass

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # .../train/kitty-rev
EK_REL = os.path.join("eval", "eval_kitty.py")        # eval_re_extended.py:68 的真实路径
EK_NAME = "eval_kitty_re"                             # eval_re_extended.py:71 的真实模块名
RE_REL = os.path.join("scripts", "eval_re_extended.py")
RE_NAME = "eval_re_extended_bare"

# bench40 固定索引（0 基行号，data/large-mix/eval.jsonl，304 行）
# 生成规则：按 meta.cat 分层，配额 = round(该类行数 × 40/304)，kb-guard/real-kitty
# 两个稀有类各保 1 条（从最大的两类各让 1 条），类内按 floor(i*m/k) 等距取点，无随机数。
# 15/15 类全覆盖。改动此表 = 换队列 = 训练前后不再可比。
BENCH40 = [0, 1, 2, 3, 5, 6, 8, 15, 35, 36, 44, 45, 46, 61, 71, 74, 75, 77, 97, 101,
           106, 108, 116, 118, 135, 144, 148, 166, 169, 175, 190, 191, 194, 208, 209,
           227, 239, 245, 246, 252]

SUITE = {
    "bench40": {"data": os.path.join("data", "large-mix", "eval.jsonl"),
                "judge": "ref", "tools": "off", "indices": BENCH40,
                "why": "304 行抽 40（15 类分层）；训练后复跑同一批才叫对照"},
    "re60": {"data": os.path.join("data", "eval_re_extended.jsonl"),
             "judge": "expect", "tools": "off", "indices": None,
             "why": "60 题 expect 规则；tools=off 与 pick_checkpoint --tools-for kitty 对齐"},
    "kitty23": {"data": os.path.join("data", "eval.jsonl"),
                "judge": "cat", "tools": "on", "indices": None,
                "why": "23 题 RULES；op-precision/closeout 等判据必须看到 tool_calls"},
}

_WS = re.compile(r"\s+")


def fatal(msg, src=""):
    """任何「看起来能继续、其实跳过了检查」的分支都走这里。"""
    print("[FATAL] " + msg, flush=True)
    if src:
        print("触发源: " + src, flush=True)
    raise SystemExit(2)


def _load(rel, name, must_attrs):
    p = os.path.join(HERE, rel)
    if not os.path.exists(p):
        fatal("模块文件不存在：" + p, "expected path " + rel)
    spec = importlib.util.spec_from_file_location(name, p)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod                      # 与 eval_re_extended.py:73 一致
    try:
        spec.loader.exec_module(mod)
    except Exception as e:
        fatal(f"模块加载失败 {p}: {e}", "spec.loader.exec_module")
    got = os.path.normcase(os.path.abspath(mod.__file__))
    if got != os.path.normcase(os.path.abspath(p)):
        fatal(f"加载到的不是目标文件：{mod.__file__} != {p}", "module path assert")
    if hasattr(mod, "HERE") and os.path.normcase(os.path.abspath(mod.HERE)) != os.path.normcase(HERE):
        fatal(f"模块 HERE 与 wrapper HERE 不一致：{mod.HERE} != {HERE}", "module HERE assert")
    miss = [a for a in must_attrs if not hasattr(mod, a)]
    if miss:
        fatal(f"{os.path.basename(p)} 缺属性 {miss}：口径会静默漂移", "module attr assert")
    print(f"[load] {name} <- {p}", flush=True)
    return mod


def load_ek():
    return _load(EK_REL, EK_NAME, ("post", "SYS", "TOOLS", "text_of", "calls_of", "judge"))


def load_re_judge():
    return _load(RE_REL, RE_NAME, ("judge",))


def sha16(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


def _bg(s):
    s = _WS.sub("", s or "")
    return Counter(s[i:i + 2] for i in range(len(s) - 1))


def overlap(out, ref):
    """字符二元组：f1 与参考覆盖率 recall。只用于 bench 这类无 expect 的对照。"""
    a, b = _bg(out), _bg(ref)
    if not a or not b:
        return 0.0, 0.0
    inter = sum((a & b).values())
    return (round(2 * inter / (sum(a.values()) + sum(b.values())), 4),
            round(inter / sum(b.values()), 4))


def post_bare(ek, base, model, messages, max_tokens, tools_on, timeout):
    """与 ek.post 同口径（temperature 0.0 / stream False），唯一差别：tools 可关。

    ek.post 无条件带 tools；re/bench 的参考答案是散文，带 tools 时模型只出
    tool_call、散文判据永远打不到（pick_checkpoint 已按同一理由默认 re 不带）。
    """
    body = {"model": model, "messages": messages, "temperature": 0.0,
            "max_tokens": max_tokens, "stream": False}
    if tools_on:
        body["tools"] = ek.TOOLS
    req = urllib.request.Request(base.rstrip("/") + "/v1/chat/completions",
                                 data=json.dumps(body).encode("utf-8"),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def prompt_parts(row, use_history=True):
    """返回 (messages, reference)。参考答 = 最后一条 assistant；其余全部进 prompt。"""
    msgs = row.get("messages") or []
    if not msgs:
        return None, None
    ref = ""
    last = msgs[-1]
    if last.get("role") == "assistant":
        ref = last.get("content") or ""
        body = msgs[:-1]
    else:
        body = msgs
    if not use_history:
        body = msgs[:1]
    body = [{"role": m.get("role") or "user", "content": m.get("content") or ""} for m in body]
    return body, ref


def select(rows, cfg, args):
    fixed = cfg.get("indices")
    if args.indices:
        if fixed and not args.allow_index_override:
            fatal(f"--suite {args.suite} 自带固定索引，不能再叠加 --indices"
                  f"（要换队列加 --allow-index-override，并接受对照失效）",
                  "argparse:--indices")
        try:
            idx = [int(x) for x in args.indices.replace(" ", "").split(",") if x != ""]
        except ValueError:
            fatal(f"--indices 不是整数列表：{args.indices!r}", "argparse:--indices")
        if len(set(idx)) != len(idx):
            dup = [k for k, v in Counter(idx).items() if v > 1]
            fatal(f"--indices 有重复项 {dup}：同一题算两次会污染均值", "argparse:--indices")
        idx = sorted(idx)
        if idx and (idx[0] < 0 or idx[-1] >= len(rows)):
            fatal(f"--indices 越界：min={idx[0]} max={idx[-1]} 但数据只有 {len(rows)} 行",
                  "argparse:--indices")
    elif fixed:
        if args.limit:
            fatal("bench40 的固定索引与 --limit 互斥（截断=换队列=对照失效）", "argparse:--limit")
        idx = list(fixed)
        bad = [i for i in idx if i >= len(rows)]
        if bad:
            fatal(f"BENCH40 索引越界 {bad}：数据只有 {len(rows)} 行（换过文件？）",
                  "BENCH40 constant vs data")
    else:
        idx = list(range(len(rows)))
        if args.limit:
            if not args.debug:
                fatal("--limit 会改变对照队列；确认只是调试请加 --debug", "argparse:--limit")
            idx = idx[:args.limit]
    if not idx:
        fatal("选择结果 0 条：0 条但 rc=0 是本项目最经典的静默错", "select()")
    return idx


def check_rows(rows, idx, judge):
    """行级结构检查：缺什么就报哪一行，不允许带着缺口往下跑。"""
    for pos, i in enumerate(idx):
        row = rows[i]
        body, ref = prompt_parts(row)
        if not body:
            fatal(f"第 {i} 行没有 messages", f"data row {i}")
        if not body[0].get("content"):
            fatal(f"第 {i} 行首条消息 content 为空", f"data row {i}")
        if judge == "ref" and not ref:
            fatal(f"第 {i} 行没有 assistant 参考答案，ref 判据无从计算", f"data row {i}")
        if judge == "expect" and not (row.get("meta") or {}).get("expect"):
            fatal(f"第 {i} 行 meta 缺 expect，expect 判据会把它判 FAIL 而不报错", f"data row {i}")


def run_selftest():
    print("=== selftest（不联网、不加载模型）===", flush=True)
    checks = []

    def chk(name, cond, detail=""):
        checks.append(bool(cond))
        print(f"[{'✓' if cond else '✗'}] {name:42s} {detail}")

    ek = load_ek()
    chk("ek 模块路径绑定", os.path.basename(ek.__file__) == "eval_kitty.py", ek.__file__)
    chk("ek.SYS 非空", bool(ek.SYS.strip()), f"{len(ek.SYS)} 字")
    chk("ek.TOOLS 有 4 个 schema", len(ek.TOOLS) == 4, str(len(ek.TOOLS)))
    chk("overlap 同文 =1.0", overlap("用 kitty_dump 转储", "用 kitty_dump 转储") == (1.0, 1.0))
    chk("overlap 无关 =0.0", overlap("abcd", "wxyz")[0] == 0.0)
    chk("overlap 部分覆盖", 0 < overlap("kitty_dump 转储镜像", "kitty_dump 转储镜像并核对")[1] < 1)
    chk("BENCH40 40 条且唯一", len(BENCH40) == 40 and len(set(BENCH40)) == 40)
    chk("BENCH40 升序", BENCH40 == sorted(BENCH40))
    try:
        fatal("selftest 自触发", "selftest")
        ok = False
    except SystemExit as e:
        ok = (e.code == 2)
    chk("fatal() 返回码 2", ok)
    good = sum(checks)
    print(f"SELFTEST {good}/{len(checks)}")
    return 0 if good == len(checks) else 1


def main():
    ap = argparse.ArgumentParser(
        description="base-only 评测 wrapper（bench40 / re60 / kitty23），口径显式、失败即响")
    ap.add_argument("--suite", default="bench40", choices=["bench40", "re60", "kitty23"],
                    help="预设：数据+判据+tools+索引 一起定（默认 bench40）")
    ap.add_argument("--data", default="", help="覆盖 preset 的数据文件（相对 kitty-rev 根）")
    ap.add_argument("--indices", default="", help="逗号分隔的 0 基行号（与固定索引互斥）")
    ap.add_argument("--allow-index-override", action="store_true",
                    help="允许覆盖 preset 的固定索引（对照失效，仅调试）")
    ap.add_argument("--limit", type=int, default=0, help="只跑前 N 条（需 --debug）")
    ap.add_argument("--base", default="http://127.0.0.1:18000")
    ap.add_argument("--model", default="huihui-base")
    ap.add_argument("--judge", default="", choices=["", "expect", "cat", "ref", "none"])
    ap.add_argument("--tools", default="", choices=["", "on", "off"])
    ap.add_argument("--sys", default="kitty", choices=["kitty", "none"])
    ap.add_argument("--prompt", default="history", choices=["history", "first"],
                    help="history=多轮行的全部历史；first=只发首条（旧脚本口径）")
    ap.add_argument("--max-tokens", type=int, default=512)
    ap.add_argument("--timeout", type=int, default=300)
    ap.add_argument("--out", default="")
    ap.add_argument("--tag", default="", help="写进报告的口径标签，如 base-only")
    ap.add_argument("--dry-run", action="store_true", help="不联网：只校验数据/选择/判据")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--debug", action="store_true", help="允许 --limit 截断队列")
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args()

    if a.selftest:
        return run_selftest()
    if a.max_tokens <= 0:
        fatal(f"--max-tokens={a.max_tokens} 非法（0 会让服务端只回空串，看起来像模型崩了）",
              "argparse:--max-tokens")

    cfg = SUITE[a.suite]
    data_path = os.path.join(HERE, a.data) if a.data else os.path.join(HERE, cfg["data"])
    judge = a.judge or cfg["judge"]
    tools_on = (a.tools or cfg["tools"]) == "on"

    if not os.path.exists(data_path):
        fatal("数据文件不存在：" + data_path, "argparse:--data")
    rows = []
    with open(data_path, "r", encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                fatal(f"第 {ln} 行不是合法 JSON: {e}", f"data {data_path}:{ln}")
    if not rows:
        fatal("数据文件 0 行：" + data_path, "data row count")

    idx = select(rows, cfg, a)
    check_rows(rows, idx, judge)

    dsig = sha16(data_path)
    print(f"[口径] suite={a.suite} judge={judge} tools={'on' if tools_on else 'off'} "
          f"sys={a.sys} prompt={a.prompt} max_tokens={a.max_tokens} "
          f"data={os.path.basename(data_path)} sha16={dsig} rows={len(rows)}", flush=True)
    print(f"[口径] 选样={len(idx)} 条 "
          f"({'固定 BENCH40' if idx == BENCH40 and a.suite == 'bench40' else '按 --indices/全量'}) "
          f"why={cfg['why']}", flush=True)

    if a.dry_run:
        print(f"[dry] 不联网、不加载模型：条数={len(idx)} 异常条数=0", flush=True)
        for pos, i in enumerate(idx, 1):
            row = rows[i]
            body, ref = prompt_parts(row, a.prompt == "history")
            print(f"[dry {pos:>3}/{len(idx)}] idx={i:<4d} "
                  f"cat={(row.get('meta') or {}).get('cat', '?'):<20s} "
                  f"turns={len(body):<3d} user_chars={len(body[0].get('content') or ''):<5d} "
                  f"ref_chars={len(ref):<5d}", flush=True)
        print(f"[dry] OK — {len(idx)} 条就绪，判据={judge}；未发任何请求", flush=True)
        return 0

    ek = load_ek()
    ek_re = load_re_judge() if judge == "expect" else None
    if judge == "cat":
        unknown = sorted({(rows[i].get("meta") or {}).get("cat", "?") for i in idx}
                         - set(ek.RULES))
        if unknown:
            fatal(f"cat 判据缺规则 {unknown}：会静默落到 r_generic（判据换了）",
                  "eval_kitty.RULES")

    sys_msg = [{"role": "system", "content": ek.SYS}] if a.sys == "kitty" else []
    results, t0 = [], time.time()
    n_err = n_empty = 0
    first_err = ""
    for pos, i in enumerate(idx, 1):
        row = rows[i]
        body, ref = prompt_parts(row, a.prompt == "history")
        msgs = sys_msg + body
        ts = time.time()
        try:
            resp = post_bare(ek, a.base, a.model, msgs, a.max_tokens, tools_on, a.timeout)
            txt, calls = ek.text_of(resp), ek.calls_of(resp)
        except Exception as e:
            n_err += 1
            if not first_err:
                first_err = f"{type(e).__name__}: {e}"
            results.append({"i": pos, "idx": i, "cat": (row.get("meta") or {}).get("cat"),
                            "err": f"{type(e).__name__}: {e}"})
            print(f"[{pos:>3}/{len(idx)}] idx={i:<4d} ERR {type(e).__name__}: {e}", flush=True)
            continue
        chars = len(txt or "")
        if chars == 0:
            n_empty += 1
        rec = {"i": pos, "idx": i, "cat": (row.get("meta") or {}).get("cat"),
               "turns": len(body), "chars": chars, "calls": len(calls),
               "sec": round(time.time() - ts, 2), "head": (txt or "")[:80]}
        if judge == "expect":
            ok, why = ek_re.judge(row, txt, calls)
            rec.update({"pass": bool(ok), "why": why})
        elif judge == "cat":
            ok, why = ek.judge(row, txt, calls)
            rec.update({"pass": bool(ok), "why": why})
        elif judge == "ref":
            rec["f1"], rec["ref_recall"] = overlap(txt, ref)
        results.append(rec)
        extra = ""
        if judge in ("expect", "cat"):
            extra = f"{'PASS' if rec['pass'] else 'FAIL'} {rec['why'][:40]}"
        elif judge == "ref":
            extra = f"f1={rec['f1']:.3f} rec={rec['ref_recall']:.3f}"
        print(f"[{pos:>3}/{len(idx)}] idx={i:<4d} cat={str(rec['cat']):<20s} "
              f"chars={chars:<5d} calls={rec['calls']:<2d} {rec['sec']:>5.1f}s {extra}", flush=True)
        if a.verbose and chars:
            print("      " + (txt or "")[:200].replace("\n", " "), flush=True)

    n = len(results)
    n_ok = n - n_err
    if n_ok + n_err != n:
        fatal(f"计数不自洽：ok={n_ok} err={n_err} n={n}", "counter integrity")
    if n_ok == 0:
        fatal(f"0/{n} 请求成功 —— 这不是 0 分，是没测成。首个异常: {first_err or '(none)'}",
              f"post {a.base}")
    if n_empty == n_ok:
        fatal(f"{n_ok}/{n_ok} 条空答（chars=0）：模板 EOS/断头 prompt 家族，信号无效",
              "empty-content check")

    ok_rows = [r for r in results if "err" not in r]
    mean_chars = sum(r["chars"] for r in ok_rows) / max(1, len(ok_rows))
    mean_calls = sum(r["calls"] for r in ok_rows) / max(1, len(ok_rows))
    summary = {"n": n, "n_ok": n_ok, "n_err": n_err, "n_empty": n_empty,
               "mean_chars": round(mean_chars, 1), "mean_calls": round(mean_calls, 3),
               "sec": round(time.time() - t0, 1)}
    if judge in ("expect", "cat"):
        p = sum(1 for r in ok_rows if r.get("pass"))
        summary["pass"] = p
        summary["pass_rate"] = round(p / max(1, len(ok_rows)), 4)
    if judge == "ref":
        summary["mean_f1"] = round(sum(r["f1"] for r in ok_rows) / max(1, len(ok_rows)), 4)
        summary["mean_ref_recall"] = round(
            sum(r["ref_recall"] for r in ok_rows) / max(1, len(ok_rows)), 4)

    print("\n" + "=" * 72)
    print(f"[sum] 条数={n} 成功={n_ok} 异常={n_err} 空答={n_empty} "
          f"mean_chars={summary['mean_chars']} mean_calls={summary['mean_calls']} "
          f"用时={summary['sec']}s")
    if judge in ("expect", "cat"):
        print(f"[sum] 通过 {summary['pass']}/{len(ok_rows)} = {summary['pass_rate'] * 100:.1f}%")
    if judge == "ref":
        print(f"[sum] mean_f1={summary['mean_f1']} mean_ref_recall={summary['mean_ref_recall']}")
    if n_err:
        print(f"[warn] {n_err} 条异常（对均值无贡献，已在上面逐条打印）：{first_err}")
    print("=" * 72)

    if a.out:
        outp = a.out if os.path.isabs(a.out) else os.path.join(HERE, a.out)
        os.makedirs(os.path.dirname(outp), exist_ok=True)
        payload = {"suite": a.suite, "tag": a.tag, "judge": judge,
                   "protocol": {"tools": "on" if tools_on else "off", "sys": a.sys,
                                "prompt": a.prompt, "max_tokens": a.max_tokens,
                                "temperature": 0.0, "base": a.base, "model": a.model},
                   "data": {"path": data_path, "sha16": dsig, "rows": len(rows)},
                   "indices": idx, "indices_fixed": idx == BENCH40 and a.suite == "bench40",
                   "debug": bool(a.debug or a.limit),
                   "summary": summary, "rows": results}
        with open(outp, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=1)
        back = json.load(open(outp, encoding="utf-8"))           # 写后回读
        if len(back.get("rows") or []) != n:
            fatal(f"回读行数不符：写 {n} 读 {len(back.get('rows') or [])}", "out readback")
        print(f"[ok] 报告 → {outp}（回读 {len(back['rows'])} 行 一致）")
    return 1 if n_err else 0


if __name__ == "__main__":
    sys.exit(main())
