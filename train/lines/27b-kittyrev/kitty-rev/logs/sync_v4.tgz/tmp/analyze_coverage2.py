#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""覆盖度分析 pass2 —— forge 明细 / tier / 领域关键词 / 子集 / 抽样尾部。只读。"""
import json, os, sys
from collections import Counter, defaultdict

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data", "large-mix-plus", "train.jsonl")


def load(p):
    return [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]


def u(r):
    for m in r.get("messages") or []:
        if m.get("role") == "user":
            return m.get("content") or ""
    return ""


def a(r):
    for m in reversed(r.get("messages") or []):
        if m.get("role") == "assistant":
            return m.get("content") or ""
    return ""


rows = load(DATA)

print("## meta.tier 分布")
print(dict(Counter((r.get("meta") or {}).get("tier") for r in rows).most_common()))

print("\n## meta.src 分布（Top 15）")
print(dict(Counter((r.get("meta") or {}).get("src") for r in rows).most_common(15)))

print("\n## forge 480 条明细（meta.forge / forge_cat / cat）")
fr = [r for r in rows if (r.get("meta") or {}).get("forge")]
print("forge 行数:", len(fr))
k = Counter()
for r in fr:
    m = r["meta"]
    k[(m.get("forge_cat") or m.get("cat"), m.get("tier"))] += 1
for kk, n in sorted(k.items(), key=lambda x: -x[1]):
    print("  %-28s %-8s %3d" % (kk[0], kk[1], n))
print("  forge 字段样例:", {kk: vv for kk, vv in list(fr[0]["meta"].items())})

print("\n## 领域关键词覆盖（含该词的 assistant 行数 / 占比）")
DOM = {
    "PE/EXE": r"\.text|PE 头|节表|导入表|IMAGE_|熵",
    "ELF/SO": r"ELF|\.so\b|AArch64|PT_LOAD",
    "APK/DEX": r"APK|smali|dex|jadx|apktool",
    "Unity/IL2CPP": r"il2cpp|global-metadata|GameAssembly|Unity",
    "Unreal/UE": r"UE4SS|UEDumper|\.pak|Unreal|GName",
    "Godot": r"Godot|\.pck|gdsdecomp",
    "驱动/内核": r"驱动|ring0|KM_|EPROCESS|PTE|Dbg",
    "反调试/反作弊": r"反调试|反作弊|ACE|EAC|BattlEye|hook 检测",
    "协议/网络": r"协议|抓包|pcap|WebSocket|protobuf",
    "固件/IoT": r"固件|firmware|binwalk|UART|JTAG",
    "iOS": r"iOS|IPA|Mach-O|dyld",
    "JS/前端": r"JavaScript|sourcemap|webpack|signature 参数",
    "移动动态": r"Frida|Xposed|adb",
    "内存扫描": r"S_NEW|S_SNAP|P_BACK|P_WALK|指针链",
    "补丁/字节": r"kitty_patch|PATCH_BYTE|expect|机器码",
}
import re
for name, pat in DOM.items():
    rx = re.compile(pat)
    n = sum(1 for r in rows if rx.search(a(r)))
    print("  %-16s %4d  %5.1f%%" % (name, n, 100.0 * n / len(rows)))

print("\n## 逆向相关度（assistant 含 kitty_ 的行）")
n_kitty = sum(1 for r in rows if "kitty_" in a(r))
print("  %d / %d = %.1f%%" % (n_kitty, len(rows), 100.0 * n_kitty / len(rows)))

print("\n## 长度总体")
al = sorted(len(a(r)) for r in rows)
ul = sorted(len(u(r)) for r in rows)
print("  assistant  p10=%d p50=%d p90=%d max=%d" % (al[len(al)//10], al[len(al)//2], al[len(al)*9//10], al[-1]))
print("  user       p10=%d p50=%d p90=%d max=%d" % (ul[len(ul)//10], ul[len(ul)//2], ul[len(ul)*9//10], ul[-1]))
print("  assistant <100 字: %d 行" % sum(1 for x in al if x < 100))

print("\n## 剩余类别抽样（trajectory / guard / error / real-* / 单例类）")
by = defaultdict(list)
for r in rows:
    m = r.get("meta") or {}
    by[m.get("cat")].append(r)
for c in ["trajectory", "real-kitty", "real-trajectory", "guard", "kb-guard", "error-recovery",
          "next-action", "op-tool-map", "transition-syntax"]:
    rs = by.get(c) or []
    if not rs:
        continue
    print("\n[%s] n=%d" % (c, len(rs)))
    step = max(1, len(rs) // 2)
    for r in rs[::step][:2]:
        print("  Q: %s" % u(r).replace("\n", " ")[:70])
        print("  A: %s" % a(r).replace("\n", " ")[:90])

SUBS = os.path.join(ROOT, "data", "subsets")
print("\n## 已切分子集")
for fn in sorted(os.listdir(SUBS)):
    if fn.endswith(".jsonl"):
        p = os.path.join(SUBS, fn)
        n = sum(1 for l in open(p, encoding="utf-8") if l.strip())
        print("  %-38s %5d 行  %10d B" % (fn, n, os.path.getsize(p)))
mf = os.path.join(SUBS, "subsets_manifest.json")
if os.path.exists(mf):
    m = json.load(open(mf, encoding="utf-8"))
    print("  manifest keys:", list(m)[:14])
    print("  rows=%s sum_groups=%s identity_ok=%s" % (m.get("rows"), m.get("sum_groups"), m.get("identity_ok")))
