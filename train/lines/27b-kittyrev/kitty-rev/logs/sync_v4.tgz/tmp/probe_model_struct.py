#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""probe_model_struct.py -- print the module tree of a tiny Qwen3_5 CausalLM.

Needed because backbone_of() assumed `model.model.layers`, but this build puts
the decoder layers somewhere else. Read-only; tiny random weights on CPU.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts"))

import torch
from transformers import AutoModelForCausalLM

from train_partial_lora import tiny_config

base = sys.argv[1] if len(sys.argv) > 1 else r"train/base/Qwen3.8-27B"
cfg = tiny_config(os.path.join(base, "config.json"))
print("cfg type", type(cfg).__name__, "text", type(cfg.text_config).__name__)

model = AutoModelForCausalLM.from_config(cfg, trust_remote_code=True)
print("model", type(model).__name__)
print("children:", [n for n, _ in model.named_children()])
for n, c in model.named_children():
    print(f"  {n}: {type(c).__name__}")
    kids = [m for m, _ in c.named_children()]
    print(f"     kids: {kids[:12]}")
    for kn, kc in list(c.named_children())[:8]:
        gk = [m for m, _ in kc.named_children()][:8]
        if gk:
            print(f"       {kn}: {type(kc).__name__} -> {gk}")

# find ModuleList of decoder layers
for name, mod in model.named_modules():
    if isinstance(mod, torch.nn.ModuleList) and len(mod) >= 2:
        print(f"ModuleList {name!r} len={len(mod)} first={type(mod[0]).__name__}")
print("has .model:", hasattr(model, "model"), "has .language_model:", hasattr(model, "language_model"))
print("has .lm_head:", hasattr(model, "lm_head"), "has .norm:", hasattr(model, "norm"))
print("PROBE_OK")
