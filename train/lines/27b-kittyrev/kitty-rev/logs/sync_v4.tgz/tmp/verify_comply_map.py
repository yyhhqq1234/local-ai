# -*- coding: utf-8 -*-
"""verify_comply_map.py -- plan_layers.py 加 comply-* 映射后的三组验收。

case A  未知类别：cats_to_mix 直接 FATAL（不落 rest）；probe 里塞未知类别时
        必须 warn + report.unknown_cats，且 mix 里不出现它、也不因此多出 rest 权重。
case B  全 9 类都在 probe（comply 用 kb-re 曲线占位）后 删掉 comply-c →
        必须 warn + report.missing_cats == ['comply-c'] + plan.note 追加「不含它们」。
case C  9 类齐 → missing/unknown 都空，且 mix 里**没有** comply-train
        （证明「登记 = 可见」，但硬编码 cats_to_mix 调用点不会自动给权重）。
"""
import importlib.util
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
KITTY = os.path.dirname(HERE)
SCRIPT = os.path.join(KITTY, "scripts", "plan_layers.py")
FAKE = os.path.join(KITTY, "tmp", "fake-probe")
WORK = os.path.join(HERE, "verify-comply")
PY = sys.executable
ENV = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")

spec = importlib.util.spec_from_file_location("plan_layers_verify", SCRIPT)
PL = importlib.util.module_from_spec(spec)
sys.modules["plan_layers_verify"] = PL
spec.loader.exec_module(PL)

fails = []


def run(probe_dir, out):
    r = subprocess.run([PY, SCRIPT, "--probe-dir", probe_dir, "--out", out,
                        "--act-root", "/nonexistent/act", "--forge", "off"],
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace", env=ENV)
    return r.returncode, (r.stdout or "") + (r.stderr or ""), out


def load_cats(path):
    return json.load(open(path, encoding="utf-8"))


def mk(name, cats):
    """copy fake-probe, replace cats/ablation_dloss with the given cat list."""
    d = os.path.join(WORK, name)
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(FAKE, d)
    p = os.path.join(d, "probe_by_cat.json")
    src = load_cats(p)
    base_curve = src["cats"]["kb-re"]["probe_by_layer"]
    new = {}
    for c in cats:
        if c in src["cats"]:
            new[c] = src["cats"][c]
        else:                                    # comply-* / 未知类别都借 kb-re 曲线
            new[c] = {"probe_by_layer": dict(base_curve)}
    src["cats"] = new
    src["ablation_dloss"] = {c: dict(base_curve) for c in cats}
    json.dump(src, open(p, "w", encoding="utf-8"), ensure_ascii=False)
    return d


ALL9 = ["kb-re", "action-reverse", "tool-route", "op-syntax", "real-discipline",
        "comply-a", "comply-b", "comply-c", "comply-d"]

shutil.rmtree(WORK, ignore_errors=True)
os.makedirs(WORK, exist_ok=True)

# ---------------- case A: 未知类别 ----------------
print("=== A1 直接调 cats_to_mix（决策树调用点）===")
try:
    got = PL.cats_to_mix({"comply-z": 2})
    print(f"[FAIL] 没报错，得到 {got}（应当 FATAL）")
    fails.append("A1 未知类别没 FATAL")
except SystemExit as e:
    ok = "未知类别" in str(e) and "rest" in str(e)
    print(f"[{'✓' if ok else '✗'}] SystemExit: {str(e).splitlines()[0][:110]}")
    if not ok:
        fails.append("A1 FATAL 文案没点明未知类别/rest")

print("\n=== A2 假 probe 塞未知类别 comply-z ===")
dA = mk("caseA", ALL9 + ["comply-z"])
rc, txt, out = run(dA, os.path.join(WORK, "caseA.json"))
warn = next((l for l in txt.splitlines() if "未登记" in l), "")
print(f"[{'✓' if warn else '✗'}] {warn[:110] or '(没有 warn)'}")
if not warn:
    fails.append("A2 probe 未知类别没 warn")
rep = load_cats(out)
if "comply-z" not in rep.get("unknown_cats", []):
    fails.append(f"A2 report.unknown_cats 缺 comply-z: {rep.get('unknown_cats')}")
else:
    print(f"[✓] report.unknown_cats = {rep['unknown_cats']}")
mixes = [s["mix"] for s in rep["plan"]["segments"]]
leak = [m for m in mixes if any("comply-z" in k for k in m)]
print(f"[{'✓' if not leak else '✗'}] mix 未被 comply-z 污染: {mixes}")
if leak:
    fails.append(f"A2 未知类别进了 mix: {leak}")
print(f"[✓] 各段 data_mix = {[s['data_mix'] for s in rep['plan']['segments']]}")

# ---------------- case B: 删一类 ----------------
print("\n=== B 9 类齐 → 删 comply-c ===")
dB = mk("caseB", [c for c in ALL9 if c != "comply-c"])
rc, txt, out = run(dB, os.path.join(WORK, "caseB.json"))
line = next((l for l in txt.splitlines() if "缺失" in l), "")
print(f"[{'✓' if line else '✗'}] {line[:120] or '(没有 warn)'}")
if not line:
    fails.append("B 缺类别没 warn")
rep = load_cats(out)
mc = rep.get("missing_cats")
print(f"[{'✓' if mc == ['comply-c'] else '✗'}] report.missing_cats = {mc}")
if mc != ["comply-c"]:
    fails.append(f"B missing_cats 应恰为 ['comply-c']，实际 {mc}")
note = (rep.get("plan") or {}).get("note", "")
print(f"[{'✓' if '不含它们' in note else '✗'}] plan.note = {note[:130]}")
if "不含它们" not in note:
    fails.append("B plan.note 没追加「本结论不含它们」")

# ---------------- case C: 9 类齐，comply 有权重吗 ----------------
print("\n=== C 9 类齐（登记可见 ≠ 自动加权）===")
dC = mk("caseC", ALL9)
rc, txt, out = run(dC, os.path.join(WORK, "caseC.json"))
rep = load_cats(out)
print(f"[{'✓' if not rep['unknown_cats'] and not rep['missing_cats'] else '✗'}] "
      f"unknown={rep['unknown_cats']} missing={rep['missing_cats']}")
if rep["unknown_cats"] or rep["missing_cats"]:
    fails.append(f"C 9 类齐仍有 unknown/missing: {rep['unknown_cats']}/{rep['missing_cats']}")
spans = rep.get("spans", {})
print(f"[{'✓' if 'comply-a' in spans else '✗'}] comply-a 有 span（决策树看得见）: "
      f"{spans.get('comply-a')}")
if "comply-a" not in spans:
    fails.append("C comply-a 没进 spans（登记后应可见）")
mixes = [s["mix"] for s in rep["plan"]["segments"]]
has_comply = any("comply-train" in m for m in mixes)
print(f"[{'✓' if not has_comply else '✗'}] mix 里没有 comply-train（硬编码调用点不加权，设计如此）: {mixes}")
if has_comply:
    fails.append("C comply 被自动加权了（不该）")

print("\nPASS: comply 映射可见、不自动加权；未知 FATAL；缺类 warn+note"
      if not fails else f"\nFAIL: {fails}")
sys.exit(0 if not fails else 1)
