# -*- coding: utf-8 -*-
"""one-off: v4 数据侧风险核算（只读，不改任何数据文件）。

输出：
  1) 当前 4388 的有效权重占比（train 行数 × 权重）
  2) comply 启用后 4788 的占比，以及 lead 给的 19.4/24.9 的口径反推
  3) 数据完整性复核：sha16 / 行数 / forge 行数 / comply 行数 / meta 字段分布
"""
import collections
import hashlib
import json

TRAIN = "data/large-mix-plus/train.jsonl"
SUBSETS = "data/subsets/subsets_manifest.json"


def sha16(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()[:16]


rows = [json.loads(l) for l in open(TRAIN, encoding="utf-8") if l.strip()]
print(f"[data] {TRAIN} rows={len(rows)} sha16={sha16(TRAIN)}")

# --- 完整性 --------------------------------------------------------------
forge = sum(1 for r in rows if (r.get("meta") or {}).get("forge"))
comply_like = sum(1 for r in rows
                  if "comply" in json.dumps(r.get("meta") or {}, ensure_ascii=False).lower()
                  or "compliance" in json.dumps(r.get("meta") or {}, ensure_ascii=False).lower())
srcs = collections.Counter(str((r.get("meta") or {}).get("src")) for r in rows)
print(f"[data] meta.forge 行={forge}  含 comply/compliance 元数据的行={comply_like}")

m = json.load(open(SUBSETS, encoding="utf-8"))
g = m["groups"]
g_train = {k: v.get("train", 0) for k, v in g.items()}
g_total = {k: v.get("total", 0) for k, v in g.items()}
g_val = {k: v.get("val", 0) for k, v in g.items()}
ungrouped = len(rows) - sum(g_total.values())
print(f"[manifest] source_sha16={m['source_sha16']} groups total={sum(g_total.values())} "
      f"ungrouped={ungrouped} train_sum={sum(g_train.values())} val_sum={sum(g_val.values())}")

W_CUR = {"forge": 4, "re": 2, "rest": 1}


def shares(pairs):
    tot = sum(v for _, v in pairs)
    return [(k, v, round(v / tot * 100, 2)) for k, v in pairs], tot


cur = [("forge", g_train["forge"] * W_CUR["forge"]),
       ("re", g_train["re"] * W_CUR["re"]),
       ("rest", ungrouped * W_CUR["rest"])]
out, tot = shares(cur)
print(f"[mix-4388] 有效权重合计={tot} " + " | ".join(f"{k}={v}({p}%)" for k, v, p in out))

W_NEW = {"comply": 3, "forge": 4, "re": 2, "rest": 1}
new = [("comply-train", 320 * W_NEW["comply"]), ("forge-train", g_train["forge"] * W_NEW["forge"]),
       ("re-train", g_train["re"] * W_NEW["re"]), ("rest", ungrouped * W_NEW["rest"])]
out, tot = shares(new)
print(f"[mix-4788] 有效权重合计={tot} " + " | ".join(f"{k}={v}({p}%)" for k, v, p in out))

# lead 口径反推：comply 用组总数 400、re 用旧值 335
lead = [("comply-total400", 400 * 3), ("forge", g_train["forge"] * 4),
        ("re-old335", 335 * 2), ("rest", ungrouped)]
out, tot = shares(lead)
print(f"[lead-反推] 合计={tot} " + " | ".join(f"{k}={v}({p}%)" for k, v, p in out))

# 敏感性：comply 权重 5 时 forge 是否跌破 25%
for cw in (3, 4, 5):
    for fw in (4, 4.5, 5):
        t = 320 * cw + g_train["forge"] * fw + g_train["re"] * 2 + ungrouped
        print(f"[敏感] comply:{cw} forge:{fw} → comply={320*cw/t*100:.1f}% "
              f"forge={g_train['forge']*fw/t*100:.1f}% re={g_train['re']*2/t*100:.1f}% "
              f"rest={ungrouped/t*100:.1f}%")

# val 不参与训练：把 val 也算进去的错误口径是多少（对照用）
wrong = [("forge", 480 * 4), ("re", g_total["re"] * 2), ("rest", ungrouped)]
out, tot = shares(wrong)
print(f"[错口径-val进分母] 合计={tot} " + " | ".join(f"{k}={v}({p}%)" for k, v, p in out))
print("[src 分布 top]", dict(srcs.most_common(6)))
