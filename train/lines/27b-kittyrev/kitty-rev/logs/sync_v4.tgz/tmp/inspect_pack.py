#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""inspect_pack.py -- 只读检查 kittyrev-local-pack.tar（不整包解压，不写产物）。

读什么
    merged-layers/layer_48.safetensors   前 1 MB（safetensors 头 + 少量数据）
    merged-layers/head.safetensors       前 1 MB
    merged-layers/layers_index.json      全文（9.7 KB）
    act-cache/re-train/*.pt              第一个（完整，几 MB）
    act-cache/forge-train/*.pt           第一个
    act-cache/rest/*.pt                  第一个
    每个成员的真实字节数（tar 索引里有，不必读数据区）

为什么要它
    「包能不能训」= 三个硬条件：层文件/head 的键名能被 load_layer 吃下、
    .pt 的 hidden/labels/attn 形状与 MultiCache._load 的期望一致、11 个目录名与
    --data-mix 的源名对得上。这三件事只能看真产物，不能看文档。
"""
import io
import json
import os
import struct
import sys
import tarfile

PACK = sys.argv[1] if len(sys.argv) > 1 else \
    r"D:\BaiduNetdiskDownload\Local-AI\train\local-pack\kittyrev-local-pack.tar"

WANT_PREFIX = ("merged-layers/layer_48.safetensors",
               "merged-layers/head.safetensors",
               "merged-layers/layers_index.json")


def st_header_bytes(blob):
    n = struct.unpack("<Q", blob[:8])[0]
    meta = json.loads(blob[8:8 + n].decode("utf-8"))
    return meta, 8 + n


def main():
    print(f"=== inspect {PACK} ===")
    print(f"包大小 {os.path.getsize(PACK) / 2 ** 30:.2f} GiB")
    got = {}
    pt_seen = {}
    n_member = 0
    sizes = {}
    with tarfile.open(PACK, "r:") as tf:
        for m in tf:
            n_member += 1
            name = m.name
            sizes[name] = m.size
            if name in WANT_PREFIX:
                f = tf.extractfile(m)
                got[name] = f.read(1024 * 1024 if m.size > 1024 * 1024 else m.size)
                continue
            # act-cache：每个目录取第一个 .pt
            if name.startswith("act-cache/") and name.endswith(".pt"):
                d = name.split("/")[1]
                if d not in pt_seen:
                    pt_seen[d] = name
                    f = tf.extractfile(m)
                    got[name] = f.read()
            if len(got) >= len(WANT_PREFIX) + 3:
                # 已经有 3 个目录的 .pt；继续扫到 act-cache 结束没必要，
                # 但 tar 顺序是 11 个目录连续，多读几个也无所谓 —— 直接收工
                if len(pt_seen) >= 3:
                    break

    print(f"扫描成员 {n_member} 个（提前停止）")
    # ---- merged-layers ----
    for name in ("merged-layers/layer_48.safetensors",
                 "merged-layers/head.safetensors"):
        blob = got.get(name)
        if not blob:
            print(f"[FAIL] 缺 {name}")
            continue
        meta, hdr = st_header_bytes(blob)
        keys = [k for k in meta if not k.startswith("__")]
        tot = sizes.get(name, 0)
        print(f"\n[{name}]  {tot / 2 ** 30:.3f} GiB  张量 {len(keys)}  头 {hdr} B")
        for k in sorted(keys)[:6]:
            print(f"    {k:52s} {meta[k]['dtype']:8s} {meta[k]['shape']}")
        if len(keys) > 6:
            print(f"    … 共 {len(keys)} 个")
        # load_layer 依赖的键名形态
        q = [k for k in keys if "q_proj" in k]
        print(f"    q_proj 键 {len(q)} 个  例: {q[:2]}")
    idx = got.get("merged-layers/layers_index.json")
    if idx:
        j = json.loads(idx.decode("utf-8"))
        print(f"\n[layers_index.json] 顶层键 {list(j)[:8]}")
        s = json.dumps(j)[:400]
        print(f"    {s}")
    # ---- act-cache .pt ----
    print("\n=== act-cache 抽样 .pt ===")
    import torch
    for d, name in sorted(pt_seen.items()):
        raw = got[name]
        try:
            obj = torch.load(io.BytesIO(raw), map_location="cpu", weights_only=False)
        except Exception as e:
            print(f"[FAIL] {name} 读不了: {type(e).__name__}: {e}")
            continue
        if isinstance(obj, dict):
            print(f"[{d}] {name}  {len(raw) / 2 ** 20:.2f} MiB  键={sorted(obj)}")
            for k in ("hidden", "labels", "attn", "n", "src", "mask"):
                if k not in obj:
                    continue
                v = obj[k]
                if hasattr(v, "shape"):
                    print(f"      {k:7s} shape={tuple(v.shape)} dtype={v.dtype}")
                else:
                    print(f"      {k:7s} = {v!r}"[:120])
        else:
            print(f"[warn] {name} 不是 dict 而是 {type(obj)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
