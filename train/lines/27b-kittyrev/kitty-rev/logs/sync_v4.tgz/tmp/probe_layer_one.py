#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""probe_layer_one.py -- load ONE real decoder layer from the local base with
the same code path train_partial_lora.py uses (meta skeleton + bnb Linear4bit),
then run one forward pass on a fake hidden tensor.

Why only one layer: it exercises the two fragile parts (per-layer 4bit
quantisation of a real 5120-hidden layer, and the layer forward signature)
while staying under ~1 GiB VRAM. Loading all 16 layers is the real run's job and
needs operator approval (~7 GiB VRAM, 11.6 GiB of disk reads).

Read-only with respect to the base; nothing is written.
"""
import json
import os
import sys

import torch

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(HERE, "scripts"))

from train_partial_lora import backbone_of, build_skeleton, load_layer  # noqa: E402

BASE = sys.argv[1] if len(sys.argv) > 1 else r"train/base/Qwen3.8-27B"
LAYER = int(sys.argv[2]) if len(sys.argv) > 2 else 48
CTX = 32


def main():
    from transformers import AutoConfig
    cfg = AutoConfig.from_pretrained(BASE, trust_remote_code=True)
    cfg.language_model_only = True
    tcfg = getattr(cfg, "text_config", cfg)
    print(f"[cfg] layers={tcfg.num_hidden_layers} hidden={tcfg.hidden_size} "
          f"vocab={tcfg.vocab_size}")

    idx = None
    for n in os.listdir(BASE):
        if n.endswith(".safetensors.index.json"):
            idx = os.path.join(BASE, n)
    wm = json.load(open(idx, encoding="utf-8"))["weight_map"]
    prefix = f"model.language_model.layers.{LAYER}."
    keys = [k for k in wm if k.startswith(prefix)]
    print(f"[idx] layer {LAYER}: {len(keys)} tensors in "
          f"{sorted({wm[k] for k in keys})}")

    from safetensors import safe_open
    sd = {}
    for sh in sorted({wm[k] for k in keys}):
        with safe_open(os.path.join(BASE, sh), framework="pt", device="cpu") as f:
            for k in f.keys():
                if k in keys:
                    sd[k] = f.get_tensor(k)
    cpu_bytes = sum(t.numel() * t.element_size() for t in sd.values())
    print(f"[read] {len(sd)} tensors  {cpu_bytes / 2 ** 20:.1f} MiB (bf16, CPU)")

    model = build_skeleton(cfg)
    bb = backbone_of(model)
    print(f"[skeleton] layers={len(bb.layers)} (meta, 0 RAM)")
    r, p = load_layer(bb.layers[LAYER], sd, prefix, "cuda", quant=True)
    del sd
    print(f"[load_layer] linear4bit={r} other={p}  "
          f"vram={torch.cuda.memory_allocated() / 2 ** 20:.0f} MiB")

    layer = bb.layers[LAYER]
    types = {}
    for n, m in layer.named_modules():
        types[type(m).__name__] = types.get(type(m).__name__, 0) + 1
    print(f"[modules] {types}")

    h = torch.randn(1, CTX, tcfg.hidden_size, dtype=torch.bfloat16, device="cuda")
    pos = torch.arange(CTX, device="cuda").unsqueeze(0)

    from train_partial_lora import materialize_rotary
    materialize_rotary(bb, "cuda")

    import inspect
    print(f"[sig] {inspect.signature(type(layer).forward)}")

    pe = bb.rotary_emb(h, pos)
    kind = "tuple" if isinstance(pe, (tuple, list)) else type(pe).__name__
    print(f"[rope] ok kind={kind} "
          f"{[tuple(t.shape) for t in pe] if isinstance(pe, (tuple, list)) else tuple(pe.shape)}")

    out = layer(h, position_embeddings=pe, position_ids=pos, use_cache=False)
    o = out[0] if isinstance(out, (tuple, list)) else out
    print(f"[fwd] out={tuple(o.shape)} {o.dtype} finite={bool(torch.isfinite(o).all())}")
    print(f"[vram] peak={torch.cuda.max_memory_allocated() / 2 ** 20:.0f} MiB")
    print("PROBE_LAYER_OK")


if __name__ == "__main__":
    main()
