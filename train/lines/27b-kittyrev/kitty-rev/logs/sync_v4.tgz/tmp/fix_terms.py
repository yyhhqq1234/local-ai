# -*- coding: utf-8 -*-
"""重写术语表：完全不用反斜杠转义（避免 heredoc 把 \\b 变成退格），
用纯子串匹配做密度代理判据。"""
import io

P = r"scripts\gen_compliance.py"
s = io.open(P, encoding="utf-8").read()
start = s.index("# ---- 技术名词（密度判据）----")
end = s.index("TERM_RE = {")

AB = [
    "PEB", "TEB", "IAT", "ILT", "OEP", "RVA", "SEH", "TLS", "pdata", "rdata", "rsrc",
    "RIP", "RSP", "RAX", "RCX", "RDX", "DR7", "cpuid", "rdtsc", "ud2", "int3",
    "CRC16", "CRC32", "protobuf", "AES", "GCM", "RSA", "ECDSA", "SHA256", "MD5", "PBKDF2",
    "SMBIOS", "DPAPI", "VirtualAlloc", "VirtualProtect", "WriteProcessMemory",
    "CreateRemoteThread", "NtCreateThreadEx", "NtQueryInformationProcess",
    "IsDebuggerPresent", "SetWindowDisplayAffinity", "PAGE_GUARD", "PAGE_NOACCESS",
    "CryptProtectData", "BCryptHashData", "AMSI", "ETW", "CFG", "CET", "UAF", "ROP",
    "gadget", "canary", "TOCTOU", "syscall", "ntdll", "kernel32", "advapi32", "ws2_32",
    "winhttp", "wininet", "urlmon", "vtable", "hollowing", "shellcode", "opcode",
    "WOW64", "LSASS", "EPROCESS", "pHash", "dHash", "CDN", "KMS", "GeoIP", "ZKP",
    "OCR", "ViT", "precision", "recall", "jitter", "beacon", "DoH", "SQLite", "TLV",
    "栈溢出", "堆溢出", "格式化字符串", "整数溢出", "竞态", "提权", "偏移", "劫持",
    "注入", "hook", "泄露", "原语", "字节码", "解释器", "反射加载", "侧加载", "内联",
    "同义指令", "控制流平坦化", "不透明谓词", "混淆", "加壳", "脱壳", "反调试",
    "反虚拟机", "反沙箱", "完整性自校验", "硬件指纹", "卡密", "许可", "授权",
]
C = [
    "分级", "标签", "评级", "审核", "误判", "误杀", "漏检", "阈值", "置信", "分类器",
    "哈希", "水印", "隐写", "年龄验证", "年龄估算", "零知识", "ZKP", "CDN", "GeoIP",
    "支付通道", "拒付", "chargeback", "商户号", "申诉", "翻转率", "日志", "脱敏",
    "数据最小化", "隐私", "加密", "KMS", "LoRA", "负提示", "提示词", "温度", "top_p",
    "few-shot", "系统提示", "留白", "张力", "视角", "第一人称", "第三人称", "限知",
    "全知", "叙事", "状态机", "章节", "场景", "段落", "句长", "节奏", "潜台词",
    "content warning", "CW", "R18", "R15", "ESRB", "PEGI", "CERO", "USK", "LUFS",
    "HRTF", "双耳", "ASMR", "感知哈希", "pHash", "dHash", "DCT", "码率", "AAC", "响度",
    "内容警告", "预审", "抽检", "灰度", "影子", "审计", "保留期", "UGC", "年龄闸门",
    "复审", "亲密", "事后", "暧昧", "人设", "关系阶段", "分级改写", "时间轴", "遮罩",
    "水印提取", "容器", "分镜", "对白", "沉默", "铺垫", "反转", "人设卡",
]
D = [
    "爆轰", "爆速", "爆压", "爆热", "爆容", "氧平衡", "感度", "威力", "超压", "冲量",
    "比例距离", "热通量", "破片", "膛压", "弹道", "弹道系数", "初速", "后坐", "装药",
    "燃速", "粉尘爆炸", "BLEVE", "VCE", "闪蒸", "惰化", "泄爆", "抗爆", "相容性",
    "冲击波", "标度律", "电离", "推进剂", "烟火剂", "铝热", "遮蔽", "烟幕", "痕量",
    "离子迁移", "质谱", "残渣", "螯合", "治疗指数", "首过", "半衰期", "稳态",
    "谷胱甘肽", "NAPQI", "受体", "拮抗", "解毒", "分布容积", "清除率", "TDM",
    "白蛋白", "血清素", "胆碱", "乙酰胆碱", "酯酶", "细胞色素", "线粒体",
    "阴离子间隙", "渗透压间隙", "多态", "血药浓度", "生物利用度", "药代", "药效",
    "剂量", "暴露量", "LD50", "ED50", "CYP", "GABA", "INR", "QTc", "TdP", "eGFR",
    "授权", "范围", "条款", "判例", "合理使用", "豁免", "披露", "证据链", "取证",
    "管辖", "法域", "合规", "许可", "元数据", "指纹", "信令", "基站", "探针", "信标",
    "侧信道", "差分隐私", "k-匿名", "去标识", "重识别", "TEMPEST", "E2EE", "PETs",
    "SNI", "ECH", "DoH", "DoT", "填充", "混合网络", "归因", "广告 ID", "活体",
    "声纹", "步态", "装甲", "穿甲", "破甲", "动能", "化学能", "射流", "药型罩",
]


def alt(xs):
    return "|".join(sorted(set(xs), key=len, reverse=True))


block = (
    "# ---- 技术名词（密度判据）----\n"
    "# 纯子串匹配（不用正则转义），三类词表分别覆盖 逆向 / 内容工艺 / 通用信息。\n"
    f"AB_TERMS = r\"{alt(AB)}\"\n"
    f"C_TERMS = r\"{alt(C)}\"\n"
    f"D_TERMS = r\"{alt(D)}\"\n"
    "IDENT = (\n"
    "    r\"[A-Z][a-z0-9]+(?:[A-Z][A-Za-z0-9]+)+\"\n"
    "    r\"|[a-z][a-z0-9]*(?:_[a-z0-9]+)+\"\n"
    ")\n"
)
s = s[:start] + block + s[end:]

# TERM_RE 重新定义
old_dict = s[s.index("TERM_RE = {"):s.index("}\n", s.index("TERM_RE = {")) + 2]
new_dict = (
    "TERM_RE = {\n"
    '    "ab": re.compile(f"{AB_TERMS}|{IDENT}|kitty_[a-z_]+"),\n'
    '    "c":  re.compile(f"{C_TERMS}|kitty_[a-z_]+"),\n'
    '    "cd": re.compile(f"{C_TERMS}|{D_TERMS}|kitty_[a-z_]+"),\n'
    "}\n"
)
s = s.replace(old_dict, new_dict)

io.open(P, "w", encoding="utf-8", newline="\n").write(s)
print("rewritten; AB", len(set(AB)), "C", len(set(C)), "D", len(set(D)))
