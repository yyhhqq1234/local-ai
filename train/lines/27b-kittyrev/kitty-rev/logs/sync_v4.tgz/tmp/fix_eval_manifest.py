# -*- coding: utf-8 -*-
"""fix_eval_manifest.py -- 只重生成 eval_re_extended_manifest.json 的 sha256_16 / bytes。

⛔ 不跑 make_re_eval.py：那会用内置默认表重建 60 题，冲掉 170 条 meta.expect 校准。
本脚本只读 data/eval_re_extended.jsonl，把 sha/size 写回清单，其余字段（rows/by_cat/
source/statistics/expect_kinds）原样保留；写前备份 manifest，写后回读校验。
"""
import hashlib
import json
import os
import shutil
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
KITTY = os.path.dirname(HERE)
DATA = os.path.join(KITTY, "data", "eval_re_extended.jsonl")
MAN = os.path.join(KITTY, "data", "eval_re_extended_manifest.json")


def sha16(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


live_sha, live_bytes = sha16(DATA), os.path.getsize(DATA)
man = json.load(open(MAN, encoding="utf-8"))
n_live = sum(1 for l in open(DATA, encoding="utf-8") if l.strip())
print(f"[live] sha16={live_sha} bytes={live_bytes} rows={n_live}")
print(f"[manifest·old] sha16={man.get('sha256_16')} bytes={man.get('bytes')} rows={man.get('rows')}")

if man.get("sha256_16") == live_sha and man.get("bytes") == live_bytes:
    print("[skip] manifest 已是最新")
    sys.exit(0)
if man.get("rows") != n_live:
    print(f"[FATAL] 行数不一致（manifest {man.get('rows')} vs live {n_live}）："
          f"这不是清单过期，是内容换过 —— 先查是谁改的，不要盲写 sha")
    sys.exit(2)

bak = f"{MAN}.bak-{time.strftime('%Y%m%d-%H%M%S')}"
shutil.copy2(MAN, bak)
man["sha256_16"] = live_sha
man["bytes"] = live_bytes
with open(MAN, "w", encoding="utf-8") as f:
    json.dump(man, f, ensure_ascii=False, indent=2)

back = json.load(open(MAN, encoding="utf-8"))
ok = back.get("sha256_16") == live_sha and back.get("bytes") == live_bytes
print(f"[write] {MAN}  backup={os.path.basename(bak)}")
print(f"[readback] sha16={back.get('sha256_16')} bytes={back.get('bytes')} "
      f"rows={back.get('rows')} by_cat 保留={bool(back.get('by_cat'))} "
      f"expect_kinds 保留={bool(back.get('expect_kinds'))}")
print("PASS: 只改 sha/bytes，其余字段原样" if ok else "FAIL: 回读不一致")
sys.exit(0 if ok else 1)
