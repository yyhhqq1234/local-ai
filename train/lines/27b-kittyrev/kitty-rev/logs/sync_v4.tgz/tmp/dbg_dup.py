# -*- coding: utf-8 -*-
import json, hashlib, os, re, collections
BASE = r"D:\BaiduNetdiskDownload\Local-AI\train\kitty-rev"
p = os.path.join(BASE, "data", "large-mix", "train.jsonl")
rows = [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]

def raw_hash(msgs):
    return hashlib.sha256(json.dumps(msgs, ensure_ascii=False, sort_keys=True).encode()).hexdigest()

WS = re.compile(r"[ \t\u3000]+")
def norm(s):
    return re.sub(r"\n{2,}", "\n", WS.sub(" ", s.replace("\r\n", "\n"))).strip()
def norm_hash(msgs):
    return hashlib.sha256("\u0001".join(f"{m['role']}\u0002{norm(m['content'])}" for m in msgs).encode()).hexdigest()

for name, fn in (("raw", raw_hash), ("normalized", norm_hash)):
    s = set(); d = 0
    for r in rows:
        h = fn(r["messages"])
        if h in s: d += 1
        s.add(h)
    print(f"{name}: rows={len(rows)} unique={len(s)} dup={d}")
