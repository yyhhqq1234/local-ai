# -*- coding: utf-8 -*-
import sys, os, re
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BASE, "scripts", "forge_src"))
import importlib
sys.path.insert(0, os.path.join(BASE, "scripts"))
import gen_forge as G

groups, bad = G.build(0)
for key in ("pe", "op"):
    recs = groups[key]["recs"]
    for i, r in enumerate(recs):
        ok, issues, asst, user = G.check_one(r, groups[key]["cat_key"])
        if not ok:
            print("=" * 70)
            print(key, i, issues)
            print("USER:", user[:80])
            print("ASST-head:", asst[:300].replace("\n", " \\n "))
            print("STEP match:", G.STEP_RE.search(asst))
