# -*- coding: utf-8 -*-
"""comply 400 条进训练前的抽样体检：
  · 12 条拒答正则
  · 与 eval_re_extended 60 题重叠（full-hash / user-hash / 5-gram Jaccard）
  · 长度与名词密度
抽样：A/B/C/D 各 1 条（固定取各自第 1 条）+ 1 条随机（seed=7）
"""
import hashlib
import json
import random
import re
import sys

sys.path.insert(0, "scripts")
sys.path.insert(0, "scripts/forge_src")
import gen_compliance as G


def norm(s):
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    return re.sub(r"\n{2,}", "\n", re.sub(r"[ \t\u3000]+", " ", s)).strip()


def fh(msgs):
    return hashlib.sha256("\u0001".join(f"{m['role']}\u0002{norm(m['content'])}" for m in msgs).encode()).hexdigest()


def uh(msgs):
    return hashlib.sha256("\u0002".join(norm(m["content"]) for m in msgs if m["role"] == "user").encode()).hexdigest()


def sh(t, n=5):
    t = re.sub(r"\s+", "", norm(t))
    return {t[i:i + n] for i in range(max(0, len(t) - n + 1))} or {t}


def jac(a, b):
    return len(a & b) / len(a | b) if a and b else 0.0


rows = [json.loads(l) for l in open("data/intent2/compliance-sft.jsonl", encoding="utf-8") if l.strip()]
by = {}
for r in rows:
    by.setdefault(r["meta"]["cat"], []).append(r)

ev = [json.loads(l) for l in open("data/eval_re_extended.jsonl", encoding="utf-8") if l.strip()]
ev_full = {fh(d["messages"]) for d in ev}
ev_user = {uh(d["messages"]) for d in ev}
ev_sh = [sh("".join(m["content"] for m in d["messages"] if m["role"] == "user")) for d in ev]

picks = [(c, by[c][0]) for c in ("comply-a", "comply-b", "comply-c", "comply-d")]
rng = random.Random(7)
picks.append(("comply-random", rng.choice(rows)))

print("=" * 78)
allpass = True
for tag, r in picks:
    u = r["messages"][0]["content"]
    a = r["messages"][1]["content"]
    msgs = r["messages"]
    # 拒答
    hits = []
    for pat in G.REFUSAL:
        m = re.search(pat, a, re.I)
        if m:
            hits.append(m.group(0)[:20])
    # 隔离
    dup_full = fh(msgs) in ev_full
    dup_user = uh(msgs) in ev_user
    jmax = max(jac(sh(u), e) for e in ev_sh) if ev_sh else 0.0
    # 质量
    terms = len(set(G.TERM_RE[{"comply-a": "ab", "comply-b": "ab"}.get(r["meta"]["cat"], "cd")].findall(a + " " + u)))
    minlen = 150 if r["meta"]["cat"] == "comply-c" else 200
    ok = (not hits) and (not dup_full) and (not dup_user) and jmax < 0.35 and len(a) >= minlen and terms >= 1
    allpass &= ok
    print(f"[{tag}] {r['meta']['cat']}  {len(a)} 字 / 名词 {terms}  {'PASS' if ok else 'FAIL'}")
    print(f"   prompt : {u}")
    print(f"   拒答命中: {hits or '0'}   与eval60: full={dup_full} user={dup_user} Jmax={jmax:.2f}")
    print(f"   开头   : {a[:90]}")
    print("-" * 78)
print("ALL PASS" if allpass else "HAS FAIL")
