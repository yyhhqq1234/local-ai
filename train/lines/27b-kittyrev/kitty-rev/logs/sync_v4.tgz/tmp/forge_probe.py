import json, collections, statistics, sys

R = r"D:\BaiduNetdiskDownload\Local-AI\train\kitty-rev"

def load(p):
    out = []
    with open(p, encoding="utf-8") as f:
        for i, l in enumerate(f):
            l = l.strip()
            if not l:
                continue
            try:
                out.append(json.loads(l))
            except Exception as e:
                print("BADLINE", p, i, e)
    return out

mix = load(R + r"\data\large-mix\train.jsonl")
print("mix total", len(mix))
c = collections.Counter((d.get("meta") or {}).get("cat") for d in mix)
for k, v in c.most_common():
    print(f"  {k}: {v} ({v/len(mix)*100:.1f}%)")

sub = load(R + r"\data\subsets\re-subset.jsonl")
print("\nre-subset", len(sub), "keys", collections.Counter(tuple(sorted(d.keys())) for d in sub))
print("cats", collections.Counter((d.get("meta") or {}).get("cat") for d in sub))
# schema of messages
d0 = sub[0]
print("\nSAMPLE0 keys:", list(d0.keys()), "meta:", d0.get("meta"))
print("roles:", [m["role"] for m in d0["messages"]])
for m in d0["messages"]:
    print("---", m["role"], len(m["content"]))
    print(m["content"][:400])

print("\n=== assistant length dist (359) ===")
al = []
for d in sub:
    a = "".join(m["content"] for m in d["messages"] if m["role"] == "assistant")
    al.append(len(a))
print("min/avg/max", min(al), round(statistics.mean(al), 1), max(al))
print("p10/p50/p90", statistics.quantiles(al, n=10)[0], statistics.median(al), statistics.quantiles(al, n=10)[8])

ev = load(R + r"\data\eval_re_extended.jsonl")
print("\neval_re", len(ev), "keys", collections.Counter(tuple(sorted(d.keys())) for d in ev))
print("meta sample:", ev[0].get("meta"))
print("eval roles:", [m["role"] for m in ev[0]["messages"]])
print(ev[0]["messages"][0]["content"][:300])
print()
print(ev[0]["messages"][-1]["content"][:300])
