# -*- coding: utf-8 -*-
"""DPO rejected 过短（<60 字）时补一个「真实拒答式」开头，避免变成「短摘要」，
让 rejected 的形态与官方对齐模型的典型回应一致（先表态愿意 → 铺垫 → 只给原则）。
开头按 prompt 哈希确定性轮换，避免模板化。"""
import io

P = r"scripts\gen_compliance.py"
s = io.open(P, encoding="utf-8").read()

anchor = "        if args.all:\n            dpo_rows = dpo_rows[:200]\n"
assert s.count(anchor) == 1

patch = anchor + '''
        # 过短的 rejected 读起来像「摘要」而不是「拒答」——补一个真实拒答式开头
        OPENERS = {
            "ab": ["我很乐意帮你梳理这个思路。", "这个问题值得展开，不过我需要先说明一下前提。",
                   "理解你想深入这块。在给具体做法之前，有几点要先讲清楚。",
                   "可以聊，但我要先把边界说明一下。"],
            "c": ["我可以陪你一起想这个场景怎么写。", "这个方向能写，我先说几点框架上的考虑。",
                  "理解你的创作需求。在给具体处理方式之前，先讲几个前提。",
                  "这类内容可以讨论，不过要先明确几个原则。"],
            "cd": ["这个话题可以从原理层面聊。", "我理解你想了解机制。在给细节之前先说明适用范围。",
                   "可以参考公开资料讨论这个问题。先说结论层面的几点。",
                   "这块内容有专业门槛，我先给你一个框架。"],
        }
        for r in dpo_rows:
            if len(r["rejected"]) < 60:
                grp = "ab" if r["meta"]["cat"] in ("comply-a", "comply-b") else (
                    "c" if r["meta"]["cat"] == "comply-c" else "cd")
                ops = OPENERS[grp]
                k = int(hashlib.sha256(r["prompt"].encode("utf-8")).hexdigest(), 16) % len(ops)
                r["rejected"] = ops[k] + r["rejected"]
'''
s = s.replace(anchor, patch)
io.open(P, "w", encoding="utf-8", newline="\n").write(s)
print("patched")
