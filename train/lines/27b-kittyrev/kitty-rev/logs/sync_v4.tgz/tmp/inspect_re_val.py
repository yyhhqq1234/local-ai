#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""inspect_re_val.py -- look at the held-out reverse subset to learn its idiom."""
import collections
import json
import re
import sys

p = sys.argv[1] if len(sys.argv) > 1 else r"train/kitty-rev/data/subsets/re-subset.val.jsonl"
rows = [json.loads(l) for l in open(p, encoding="utf-8")]
print("val rows", len(rows))
for r in rows[:2]:
    m = r.get("meta") or {}
    print("--- cat =", m.get("cat"), "| meta keys", list(m.keys()))
    for msg in r["messages"]:
        c = (msg.get("content") or "")
        role = msg.get("role")
        print("  [{}] {}".format(role, c[:300].replace("\n", " / ")))

txt = " ".join((msg.get("content") or "") for r in rows for msg in r["messages"])
print("--- vocabulary counts ---")
for pat in ["kitty_die", "kitty_sym", "kitty_ce", "kitty_ops", "S_NEW", "P_BACK", "MODENUM",
            "pari", "pe.stat", "pe.secs", "pe.symbols", "triage", "static", "dynamic"]:
    print(f"{pat:12s} {len(re.findall(re.escape(pat), txt))}")
print("top kitty tools:", collections.Counter(re.findall(r"kitty_[a-z_]+", txt)).most_common(10))
print("--- sample of an assistant answer ---")
for r in rows[:3]:
    for msg in r["messages"]:
        if msg.get("role") == "assistant":
            print(repr((msg.get("content") or "")[:400]))
            break
    break
