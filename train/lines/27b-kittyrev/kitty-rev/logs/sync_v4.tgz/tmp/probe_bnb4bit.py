#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""probe_bnb4bit.py -- does bnb Linear4bit + Params4bit work on this Windows box?

train_partial_lora.py needs to quantise the 16 kept layers on the fly
(load_layer -> bnb.nn.Linear4bit with a Params4bit weight). If that path is
broken on Windows, the only fallback is bf16, and 16 layers of bf16 (11.6 GiB)
will not fit a 12 GiB card -- so this probe decides whether P2 is viable at all.

Read-only: allocates a 32x64 toy linear and frees it.
"""
import sys

import torch

print("torch", torch.__version__, "cuda", torch.cuda.is_available())
if not torch.cuda.is_available():
    print("PROBE_RESULT: NO_CUDA")
    sys.exit(0)

try:
    import bitsandbytes as bnb
    print("bitsandbytes", bnb.__version__)
except Exception as e:
    print("PROBE_RESULT: BNB_IMPORT_FAIL", e)
    sys.exit(0)

try:
    out_f, in_f = 32, 64
    w = torch.randn(out_f, in_f, dtype=torch.bfloat16)
    lin = bnb.nn.Linear4bit(in_f, out_f, bias=False, compute_dtype=torch.bfloat16,
                            quant_type="nf4", compress_statistics=True, device="cuda")
    lin.weight = bnb.nn.Params4bit(w, requires_grad=False, quant_type="nf4",
                                   blocksize=64, compress_statistics=True).to("cuda")
    x = torch.randn(1, 3, in_f, dtype=torch.bfloat16, device="cuda")
    y = lin(x)
    print("out", tuple(y.shape), y.dtype, "allocated", f"{torch.cuda.memory_allocated() / 2 ** 20:.1f} MiB")
    print("quant_state", getattr(lin.weight, "quant_state", None) is not None)
    del lin, x, y, w
    torch.cuda.empty_cache()
    print("PROBE_RESULT: OK")
except Exception as e:
    import traceback
    traceback.print_exc()
    print("PROBE_RESULT: FAIL", type(e).__name__, e)
