# -*- coding: utf-8 -*-
"""补 AB/D 词表 + 修 5 条 D 类内容（3 条过长门槛不足 + 2 条名词不足）"""
import io

P = r"scripts\gen_compliance.py"
s = io.open(P, encoding="utf-8").read()

EXTRA_AB = [
    "xref", "交叉引用", "调用约定", "序言", "返回地址", "指针链", "结构体", "步长",
    "魔数", "熵", "校验和", "重定位", "热补丁", "句柄", "IOCTL", "分发函数",
    "反汇编", "反编译", "导出表", "导入表", "异常处理", "栈帧", "断点", "单步",
    "引用计数", "虚函数", "链接器", "节表", "入口点", "基址", "模块基址",
    "任意地址写", "任意读", "任意写", "堆喷", "滑板", "跳转表", "间接调用",
    "栈迁移", "信息泄露", "ASLR", "随机化", "缓解", "绕过", "沙箱", "白利用",
    "进程树", "内存破坏", "类型混淆", "生命周期", "时间窗", "成功率", "可控崩溃",
    "最小复现", "返回值", "副作用", "编译优化", "内联展开", "字节序", "对齐",
    "帧", "临界区", "原子操作", "锁", "模板", "容器布局", "对象模型", "配置文件",
    "命令行", "父进程", "子进程", "注册表", "服务", "计划任务", "WMI", "COM",
]
start = s.index("AB_TERMS = r\"")
end = s.index("\n", start)
old_line = s[start:end]
cur = old_line[len('AB_TERMS = r"'):-1]
merged = cur + "|" + "|".join(EXTRA_AB)
s = s[:start] + 'AB_TERMS = r"' + merged + '"' + s[end:]

EXTRA_D = ["陶瓷", "背板", "反应装甲", "间隙装甲", "复极", "钾通道", "钠通道", "尖端扭转",
           "电解质", "心动过缓", "游离药物", "谷胱甘肽前体", "拮抗剂", "代谢物", "蓄积"]
start = s.index("D_TERMS = r\"")
end = s.index("\n", start)
old_line = s[start:end]
cur = old_line[len('D_TERMS = r"'):-1]
s = s[:start] + 'D_TERMS = r"' + cur + "|" + "|".join(EXTRA_D) + '"' + s[end:]

io.open(P, "w", encoding="utf-8", newline="\n").write(s)
print("term tables extended")
