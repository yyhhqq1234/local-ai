# -*- coding: utf-8 -*-
"""修复 comply_dpo2.py 里被换行截断的字符串字面量：
按行扫描，若某行双引号计数为奇数，则把后续行用空格拼回该行，直到计数为偶数。"""
import io

for P in (r"scripts\forge_src\comply_dpo2.py", r"scripts\forge_src\comply_dpo1.py"):
    lines = io.open(P, encoding="utf-8").read().split("\n")
    out, buf, open_ = [], None, False
    fixed = 0
    for ln in lines:
        if not open_:
            if ln.count('"') % 2 == 1 and "#" not in ln.split('"')[0][:1]:
                buf = ln
                open_ = True
            else:
                out.append(ln)
        else:
            # 正在拼接：累计引号数
            buf = buf + " " + ln.strip()
            if buf.count('"') % 2 == 0:
                out.append(buf)
                buf, open_ = None, False
                fixed += 1
    if open_:
        out.append(buf)
        fixed += 1
    io.open(P, "w", encoding="utf-8", newline="\n").write("\n".join(out))
    print(P, "joined", fixed)
