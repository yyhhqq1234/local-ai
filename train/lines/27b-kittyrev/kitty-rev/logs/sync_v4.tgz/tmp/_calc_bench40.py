# -*- coding: utf-8 -*-
"""one-off: compute the fixed bench40 index list (stratified, deterministic, no RNG)."""
import collections
import json

PATH = "data/large-mix/eval.jsonl"
rows = [json.loads(l) for l in open(PATH, encoding="utf-8")]
n = len(rows)
cats = collections.Counter((r.get("meta") or {}).get("cat") or "?" for r in rows)

# proportional allocation, then force +1 for the two rare cats by taking one each
# from the two largest cats so total stays 40 and every cat is represented.
alloc = {c: round(k * 40 / n) for c, k in cats.items()}
alloc["kb-guard"] = 1
alloc["real-kitty"] = 1
# rebalance to exactly 40 by trimming the largest allocations
while sum(alloc.values()) > 40:
    c = max(alloc, key=lambda x: alloc[x])
    alloc[c] -= 1
while sum(alloc.values()) < 40:
    c = max(cats, key=lambda x: cats[x] - alloc[x])
    alloc[c] += 1

pos = collections.defaultdict(list)
for i, r in enumerate(rows):
    pos[(r.get("meta") or {}).get("cat") or "?"].append(i)

idx = []
for c in sorted(pos):
    k = alloc[c]
    lst = pos[c]
    m = len(lst)
    picks = [lst[(i * m) // k] for i in range(k)] if k else []
    assert len(set(picks)) == k, (c, picks)
    idx.extend(picks)

idx.sort()
print("n_rows", n)
print("alloc", json.dumps(alloc, ensure_ascii=False, sort_keys=True))
print("count", len(idx), "unique", len(set(idx)))
print("BENCH40 =", json.dumps(idx))
print("cats covered", len({(rows[i].get("meta") or {}).get("cat") for i in idx}))
print("per-cat picked:", json.dumps(dict(collections.Counter(
    (rows[i].get("meta") or {}).get("cat") for i in idx)), ensure_ascii=False))
print("user_chars:", [len(rows[i]["messages"][0]["content"]) for i in idx])
