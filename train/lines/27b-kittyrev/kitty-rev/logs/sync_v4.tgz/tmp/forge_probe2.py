import json, collections, statistics, io, sys

R = r"D:\BaiduNetdiskDownload\Local-AI\train\kitty-rev"
OUT = R + r"\tmp\style-dump.txt"

def load(p):
    out = []
    with open(p, encoding="utf-8") as f:
        for i, l in enumerate(f):
            l = l.strip()
            if l:
                out.append(json.loads(l))
    return out

sub = load(R + r"\data\subsets\re-subset.jsonl")
ev = load(R + r"\data\eval_re_extended.jsonl")
mix = load(R + r"\data\large-mix\train.jsonl")

w = io.open(OUT, "w", encoding="utf-8")

# topic distribution in re-subset
topics = collections.Counter(((d.get("meta") or {}).get("topic") or "") for d in sub)
w.write("=== topics (359) ===\n")
for k, v in topics.most_common(60):
    w.write(f"{v:4d}  {k}\n")

w.write("\n=== 12 full samples (kb-re) ===\n")
n = 0
for d in sub:
    if d["meta"]["cat"] != "kb-re":
        continue
    if n >= 6:
        break
    n += 1
    w.write("-" * 70 + "\n")
    w.write("META " + json.dumps(d["meta"], ensure_ascii=False) + "\n")
    for m in d["messages"]:
        w.write(f"[{m['role']}] len={len(m['content'])}\n{m['content']}\n")

w.write("\n=== 8 full samples (action-reverse) ===\n")
n = 0
for d in sub:
    if d["meta"]["cat"] != "action-reverse":
        continue
    if n >= 8:
        break
    n += 1
    w.write("-" * 70 + "\n")
    w.write("META " + json.dumps(d["meta"], ensure_ascii=False) + "\n")
    for m in d["messages"]:
        w.write(f"[{m['role']}] len={len(m['content'])}\n{m['content']}\n")

w.write("\n=== eval_re_extended 8 full ===\n")
for d in ev[:8]:
    w.write("-" * 70 + "\n")
    w.write("META " + json.dumps(d["meta"], ensure_ascii=False) + "\n")
    for m in d["messages"]:
        w.write(f"[{m['role']}]\n{m['content']}\n")

# all user prompts of re-subset, one per line (for dedupe awareness / avoid)
w.write("\n=== ALL 359 user prompts ===\n")
for i, d in enumerate(sub):
    u = [m["content"] for m in d["messages"] if m["role"] == "user"]
    w.write(f"{i:03d}|{d['meta']['cat']}|{u[0] if u else ''}\n")

w.write("\n=== ALL 60 eval prompts ===\n")
for i, d in enumerate(ev):
    u = [m["content"] for m in d["messages"] if m["role"] == "user"]
    w.write(f"{i:03d}|{(d.get('meta') or {}).get('cat')}|{u[0][:1200] if u else ''}\n")

# user length stats
ul = [len(m["content"]) for d in sub for m in d["messages"] if m["role"] == "user"]
w.write(f"\nuser len min/avg/max {min(ul)}/{statistics.mean(ul):.0f}/{max(ul)}\n")
w.write(f"eval user len min/avg/max {min(len(m['content']) for d in ev for m in d['messages'] if m['role']=='user')}"
        f"/{statistics.mean([len(m['content']) for d in ev for m in d['messages'] if m['role']=='user']):.0f}"
        f"/{max(len(m['content']) for d in ev for m in d['messages'] if m['role']=='user')}\n")

# kitty tool names used across 359
import re
TOOLS = r"kitty_[a-z0-9_]+"
cnt = collections.Counter()
for d in sub:
    for m in d["messages"]:
        cnt.update(re.findall(TOOLS, m["content"]))
w.write("\n=== kitty tool freq in 359 ===\n")
for k, v in cnt.most_common(80):
    w.write(f"{v:4d} {k}\n")

OPS = r"\b(S_NEW|S_SNAP|S_CHANGED|S_UNCHANGED|S_GET|S_FREE|P_BACK|P_BACK_RES|P_WALK|MODENUM|MODBASE|KM_R|KM_W|KM_ATTACH|KM_PA|KM_PR|KM_PW|MEMDUMP_HEX|DBG_REGS|DBG_BP|DBG_ATTACH|DBG_GO|SYNC_ARCHIVE|SYNC_STAT|JOB_STAT|ALLOC|FREE|LP|OPEN|CUR|PING|LUA)\b"
cnt2 = collections.Counter()
for d in sub:
    for m in d["messages"]:
        cnt2.update(re.findall(OPS, m["content"]))
w.write("\n=== OP freq in 359 ===\n")
for k, v in cnt2.most_common(80):
    w.write(f"{v:4d} {k}\n")

w.close()
print("written", OUT)
