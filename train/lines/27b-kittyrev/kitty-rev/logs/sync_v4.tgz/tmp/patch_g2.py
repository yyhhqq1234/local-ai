# -*- coding: utf-8 -*-
"""一次性修补：给 15 条只含单一工具名的样本补第二个工具/OP（G2 不达标）。
每处替换都是唯一字符串，替换后逐条断言命中次数 == 1。
"""
import io
import os
import sys

SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts", "forge_src")

# (文件, 原文, 新文)
PATCHES = [
    # pe 46 数据目录 4/6 —— 补 kitty_die 交叉
    ("pe_d.py",
     '退出：四个关键索引（1/2/9/14）各自的值抄进卡片，不靠记忆。',
     '交叉核对：\n```\nkitty_die action=detect target=SAMPLE.exe\n```\n判读：kitty_die 报的「签名 / 无签名」应与索引 4 的内容一致；\n报「无签名」但索引 4 非零 → 目录伪造。\n\n退出：四个关键索引（1/2/9/14）各自的值抄进卡片，不靠记忆，且与 kitty_die 结论一致。'),
    # pe 99 TimeDateStamp=0 —— 补 kitty_die
    ("pe_f.py",
     '退出：给出「清零原因（可重现构建 / 对抗溯源）」+ 能从其它指纹反推的构建信息。',
     '交叉：\n```\nkitty_die action=detect target=SAMPLE.exe\n```\n判读：kitty_die 报的编译/壳指纹与手读的 Rich/语言标记应一致；\n不一致说明头部字段被改过。\n\n退出：给出「清零原因（可重现构建 / 对抗溯源）」+ 能从其它指纹反推的构建信息。'),
    # pe 113 Checksum 不匹配 —— 补 kitty_die
    ("pe_f.py",
     '退出：给出「不匹配的差值 + 是否已在别处被重算」；',
     '交叉：\n```\nkitty_die action=detect target=SAMPLE.exe\n```\n判读：kitty_die 是否也报校验异常；两侧一致才说明是同一处改动。\n\n退出：给出「不匹配的差值 + 是否已在别处被重算」；'),
    # op 35 bytes 写越界 —— 补 kitty_prot query
    ("op_d.py",
     '退出：写入值正确 + 相邻 4 字节未变。',
     '权限核对（写失败时先做这一步）：\n```\nkitty_prot action=query addr=0xADDR\n```\n判读：Protect 必须是 RW 或 RWX；只读页写入会被拒，不是 bytes 参数的问题。\n\n退出：写入值正确 + 相邻 4 字节未变 + query 显示可写。'),
    # op 69 float 写 —— 补 kitty_km
    ("op_e.py",
     '退出：位模式回读一致 + 界面显示 100。',
     '跨视图确认：\n```\nkitty_km action=read addr=0xADDR vt=dword\n```\n判读：内核视图也应是 0x42C80000；不一致说明写进了影子页。\n\n退出：位模式回读一致 + 界面显示 100 + 双视图相同。'),
    # op 88 4→8 字节 —— 补 kitty_km
    ("op_f.py",
     '退出：目标 4 字节正确 + 相邻 4 字节未变，两项都过。',
     '跨视图确认：\n```\nkitty_km action=read addr=0xADDR vt=qword\n```\n判读：内核视图应与 R 一致；不一致时以内核视图为准。\n\n退出：目标 4 字节正确 + 相邻 4 字节未变 + 双视图一致。'),
    # op 97 qword 只改低 4 字节 —— 补 kitty_km
    ("op_f.py",
     '退出：高位未变 + 低位正确，两项都过；用 kitty_ce op="R|0xADDR+4|dword" 再确认一次高位。',
     '跨视图确认：\n```\nkitty_km action=read addr=0xADDR vt=qword\n```\n判读：内核视图的高位也必须未变。\n\n退出：高位未变 + 低位正确 + 双视图一致；用 kitty_ce op="R|0xADDR+4|dword" 再确认一次高位。'),
    # op 107 bit 位 —— 补 kitty_km
    ("op_f.py",
     '退出：位值与相邻位都正确；用 bytes:2 再看一眼相邻字节是否被波及。',
     '跨视图确认：\n```\nkitty_km action=read addr=0xADDR vt=byte\n```\n判读：内核视图的整字节应与你写入的一致。\n\n退出：位值与相邻位都正确 + 双视图一致；用 bytes:2 再看一眼相邻字节是否被波及。'),
    # op 111 S_GET 地址存疑 —— 补 kitty_prot
    ("op_f.py",
     '退出：可写 + 相邻字段自洽 + 改值跟随，三项齐备。',
     '归属核对：\n```\nkitty_prot action=query addr=0xCAND\n```\n判读：AllocationBase 应与目标对象一致；落在别的区说明取样索引混淆。\n\n退出：可写 + 相邻字段自洽 + 改值跟随 + 归属一致，四项齐备。'),
    # op 115 bytes 长度不符 —— 补 kitty_km
    ("op_f.py",
     '退出：写入 + 回读逐字节一致；长度不符时数一遍字符数再发。',
     '跨视图确认：\n```\nkitty_km action=read addr=0xADDR vt=bytes:4\n```\n判读：内核视图的字节串应与写入一致（长度也会被校验）。\n\n退出：写入 + 回读逐字节一致 + 双视图一致；长度不符时数一遍字符数再发。'),
    # chain 45 只有 PDB —— 补 kitty_ida / kitty_ghidra
    ("chain_d.py",
     '产物：符号清单 + 职责推断。明确写「无字节，不给实现结论」。',
     '若有二进制但无导出，改用反汇编器补面：\n```\nkitty_ida action=analyze target=<binary>\nkitty_ida action=functions out=logs\\ida-pdb-<ts> limit=80\nkitty_ghidra action=functions out=logs\\ghidra-pdb-<ts> filter=<PDB 里的函数名>\n```\n判读：PDB 里的函数名能对上反汇编器识别出的地址 → 符号可用。\n\n产物：符号清单 + 职责推断 + （有字节时）符号与地址的对应表。明确写「无字节，不给实现结论」。'),
    # detour 61 unsigned —— 补 kitty_prot
    ("det_c.py",
     '末态：按无符号补码写入。\n复盘：负数一律转补码；界面表现取决于字段符号性。',
     '归属与权限核对：\n```\nkitty_prot action=query addr=0xADDR\n```\n判读：Protect 可写才谈值语义；不可写时先改保护。\n\n末态：按无符号补码写入 + query 显示可写。\n复盘：负数一律转补码；界面表现取决于字段符号性。'),
    # detour 94 BATCH ops 字符串 —— 补 kitty_ce PING 判活
    ("det_d.py",
     '末态：批量读正确。\n复盘：ops 是数组，元素内不能夹分隔符。',
     '解析异常时先判通道而不是猜格式：\n```\nkitty_ce op=PING\n```\n判读：PING 正常说明桥在，问题在 ops 的组织方式；PING 也超时则是通道问题。\n\n末态：批量读正确 + 通道判活一次。\n复盘：ops 是数组，元素内不能夹分隔符。'),
    # detour 97 from/to —— 补 kitty_die
    ("det_e.py",
     '末态：范围参数用法确认。\n复盘：from 起点、to 终点，两个都要给才能控范围。',
     '搜不到时先确认文件本身没被判错：\n```\nkitty_die action=detect target=SAMPLE.exe\n```\n判读：能正常识别说明文件可读，问题只在范围参数。\n\n末态：范围参数用法确认 + 文件可读性已核。\n复盘：from 起点、to 终点，两个都要给才能控范围。'),
    # detour 110 32 位 qword 写 —— 补 kitty_km
    ("det_e.py",
     '末态：宽度匹配。\n复盘：写前核位数与字段宽度；写后必查相邻。',
     '跨视图确认：\n```\nkitty_km action=read addr=0xADDR vt=dword\n```\n判读：内核视图的 dword 应等于写入值；若内核视图显示高位被写，说明 qword 写生效了 —— 正是要避免的。\n\n末态：宽度匹配 + 双视图确认未越界。\n复盘：写前核位数与字段宽度；写后必查相邻。'),
]


def main():
    touched = {}
    ok = True
    for fn, old, new in PATCHES:
        p = os.path.join(SRC, fn)
        s = io.open(p, encoding="utf-8").read()
        n = s.count(old)
        if n != 1:
            print(f"MISS {fn}: count={n} :: {old[:40]}")
            ok = False
            continue
        s = s.replace(old, new)
        io.open(p, "w", encoding="utf-8", newline="\n").write(s)
        touched[fn] = touched.get(fn, 0) + 1
    print("patched:", touched)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
