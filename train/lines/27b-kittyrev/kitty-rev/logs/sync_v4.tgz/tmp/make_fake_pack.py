# -*- coding: utf-8 -*-
"""make_fake_pack.py -- 造三个 tar 供 verify_local_pack.py 自检（不碰真交付物）。

good.tar    16 层 + head + layers_index.json + act-cache(9 目录) → 应 PASS
trunc.tar   同上但 layer_55 被截掉 1 KB（GNU tar 允许，读的时候不报错）→ 应 FAIL
nolayer.tar 同上但缺 layer_61 → 应 FAIL（层数/连续性）
"""
import hashlib
import io
import json
import os
import sys
import tarfile

out = os.path.dirname(os.path.abspath(__file__))
TMP = os.path.join(out, "fake-pack")
os.makedirs(TMP, exist_ok=True)
LAYERS = [f"layer_{i}.safetensors" for i in range(48, 64)]
ACT_DIRS = ["re-train", "re-val", "route-train", "route-val", "discipline-train",
            "discipline-val", "gen-train", "gen-val", "rest"]


def blob(n, seed):
    h = hashlib.sha256(seed.encode()).digest()
    return (h * (n // 32 + 1))[:n]


def build(tar_name, drop=None, trunc=None):
    path = os.path.join(TMP, tar_name)
    groups = {}
    files = {}
    for name in LAYERS:
        data = blob(128 * 1024, name)
        sha = hashlib.sha256(data).hexdigest()[:16]
        groups[name.replace(".safetensors", "")] = {
            "file": name, "keys": 7, "bytes": len(data) - 64, "sha256_16": sha}
        files[name] = data
    head = blob(64 * 1024, "head")
    groups["head"] = {"file": "head.safetensors", "keys": 2,
                      "bytes": len(head) - 64,
                      "sha256_16": hashlib.sha256(head).hexdigest()[:16]}
    files["head.safetensors"] = head
    index = {"n_layers": 16, "n_groups": len(groups), "groups": groups}
    idx_bytes = json.dumps(index, ensure_ascii=False, indent=1).encode()

    if drop:
        files.pop(drop)
    if trunc:
        files[trunc] = files[trunc][:-1024]

    with tarfile.open(path, "w") as tf:
        def add(name, data):
            ti = tarfile.TarInfo(name)
            ti.size = len(data)
            tf.addfile(ti, io.BytesIO(data))
        for name in LAYERS:
            if name in files:
                add("merged-layers/" + name, files[name])
        add("merged-layers/head.safetensors", files["head.safetensors"])
        add("merged-layers/layers_index.json", idx_bytes)
        for d in ACT_DIRS:
            add(f"act-cache/{d}/", b"") if False else None
            for i in range(3):
                add(f"act-cache/{d}/s{i:05d}.pt", blob(4096, f"{d}{i}"))
    print(f"[write] {path}  {os.path.getsize(path)/2**20:.2f} MiB")
    return path


build("good.tar")
build("trunc.tar", trunc="layer_55.safetensors")
build("nolayer.tar", drop="layer_61.safetensors")
print(TMP)
