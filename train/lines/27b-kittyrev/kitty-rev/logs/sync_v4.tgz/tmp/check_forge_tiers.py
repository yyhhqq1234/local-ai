#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""check_forge_tiers.py -- what difficulty tiers does the forge subset actually carry?

lead said "forge-val 的 96 条里 hard 只有 16 条"; the earlier probe showed tier
is uniformly 'gold'.  This prints the real distribution and hunts for any
difficulty-like field so the statistical-limitation note is based on data.
"""
import collections
import json
import os

D = r"train/kitty-rev/data/subsets"

for name in ("forge-subset.jsonl", "forge-subset.train.jsonl", "forge-subset.val.jsonl"):
    p = os.path.join(D, name)
    if not os.path.exists(p):
        print(name, "MISSING")
        continue
    rows = [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]
    tiers = collections.Counter((r.get("meta") or {}).get("tier", "?") for r in rows)
    keys = collections.Counter()
    for r in rows:
        for k in (r.get("meta") or {}):
            keys[k] += 1
    print(f"{name:28s} rows={len(rows):3d}  tier={dict(tiers)}")
    print(f"{'':28s} meta keys = {dict(keys)}")
    hard = []
    for r in rows:
        for k, v in (r.get("meta") or {}).items():
            if str(v).strip().lower() in ("hard", "difficulty", "困难"):
                hard.append((r.get("meta") or {}).get("cat"), k, v)
    print(f"{'':28s} 含 hard/困难 值的行 = {len(hard)}  {hard[:5]}")
    # 正文长度分布（难度代理指标）
    lens = [sum(len(m.get("content") or "") for m in (r.get("messages") or [])) for r in rows]
    if lens:
        lens.sort()
        print(f"{'':28s} 正文字数 min/med/max = {lens[0]}/{lens[len(lens)//2]}/{lens[-1]}")
    print()
