#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""test_manifest_guard.py -- prove the act-cache manifest guard works.

Builds three directories from the fake cache:
    act-ok    manifest count matches  -> must construct fine
    act-bad   manifest count +1       -> must exit FATAL
    act-none  no manifest             -> must construct fine (legacy layout)
"""
import glob
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(HERE, "scripts"))

from train_partial_lora import MultiCache  # noqa: E402

SRC = os.path.join(HERE, "tmp", "fake-act")
BASE = os.path.join(HERE, "tmp")


def make(name, delta=0, with_manifest=True):
    d = os.path.join(BASE, name)
    os.makedirs(d, exist_ok=True)
    for f in glob.glob(os.path.join(d, "*.pt")):
        os.unlink(f)
    for f in glob.glob(os.path.join(SRC, "*.pt")):
        shutil.copy(f, d)
    fs = sorted(os.path.basename(f) for f in glob.glob(os.path.join(d, "*.pt")))
    if with_manifest:
        json.dump({"count": len(fs) + delta, "samples": fs},
                  open(os.path.join(d, "manifest.json"), "w"))
    elif os.path.exists(os.path.join(d, "manifest.json")):
        os.unlink(os.path.join(d, "manifest.json"))
    return d, len(fs)


ok = True
for name, delta, wm, should_fail in (
        ("act-ok", 0, True, False),
        ("act-bad", 1, True, True),
        ("act-none", 0, False, False)):
    d, n = make(name, delta, wm)
    try:
        c = MultiCache([(name, d, 1.0)], 512)
        got = f"构造成功 源={c.names} 样本={len(c)}"
        failed = False
    except SystemExit as e:
        got = f"FATAL: {e}"
        failed = True
    tag = "✓" if failed == should_fail else "✗"
    if failed != should_fail:
        ok = False
    print(f"[{name:9s}] {n} 个 .pt  manifest={'有' if wm else '无'}  "
          f"期望={'FATAL' if should_fail else '通过'}  {tag}  {got}")

print("MANIFEST_GUARD_OK" if ok else "MANIFEST_GUARD_FAIL")
sys.exit(0 if ok else 1)
