# 会话全量读取报告 — session-e06f434c-6a09-42c1-a0c5-d51c69d92e19

- 读取时间：2026-11-08 22:18 (+08)
- 会话文件：`C:\Users\Administrator\.dsh\sessions\--D-BaiduNetdiskDownload-Local-AI--\session-e06f434c-6a09-42c1-a0c5-d51c69d92e19\session.v4.jsonl.zstd`
- 压缩体积 11,848,902 B → 解帧 3,349 frame → 明文 **39,354,976 B / 7,705 event**
- 时间跨度：2026-11-07 23:23:42 → 2026-11-08 22:00:49（约 22.6 小时，156 轮 turn）
- cwd：`D:\BaiduNetdiskDownload\Local-AI`；标题：`你好`（首条消息回退命名）
- 参与模型：`codex-local/gpt-6.1-sol`（主）· `commandcode-goat-autosync/deepseek-v4.1-flash`（切换后）

## 0 事件结构（全量直方）

```
request/header      78      assistant/message   986     tool/call    872
tool/result        901      user/message       1258     step/start   991
turn/start         156      turn/end           156     step/end     991
agent/inbox/spliced 504     job/registered     325     job/settled  325
compaction/prune    29      compaction/start     6     compaction/end 6
compaction/summary   2      goal/change          5     workspace/changes 71
system/message       4      developer/message    4     model/selection 11
session/end-seed     8      assistant/attempt    4     llm/retry 1 / retry-started 1
todo/write 1 · session/title 1 · session/title-llm-request 1 · permission/preset 1 · sandbox/mode 1 · approval/policy 1
```

工具调用直方（872 次）：

```
pwsh 325 · job_output 225 · edit 98 · read 79 · grep 69 · ops_read_files 26
write 19 · glob 9 · job_list 3 · schedule_edit 3 · job_kill 3 · working_directory 2
skill 2 · create_goal 2 · schedule_create 2 · session_event_search 1 · todo_write 1
get_goal 1 · update_goal 1 · schedule_list 1
```

用户消息 1258 条中，**真实人输入仅 179 条**，其余为：987 条每步 `[SHIYI TOOL LOCK]` 注入、60 条 `goal_round` 自动续跑、22 条定时提醒、少量 system-reminder / runtime-context。

## 1 任务目标（会话内两次 goal 演进）

**目标 A（T9 建，T10 完成）**：修好 `ninfer-serve.exe` 对 `oxcoder9b-merged` 的推理 → ①连续 ≥32 token 无 NaN；②5 prompt×3 轮=15/15；③失败不挂死。

**目标 B（T13 建，全程主线，至会话结束未完成）**：
> 让本地 Windows 原生引擎完全正常地推理后训练 Oxcoder9B，五项验收全实测：
> ① 内容正确 5×3=15/15，无 NaN/500，失败不挂死；
> ② 多模态 `--vision` 图片 → decode→image token→vision tower→文本，≥1 例图文问答；
> ③ 接 DSH 完成一次真实对话（工具调用可后续）；
> ④ 首 token <15s（冷启后首请求实测）；
> ⑤ decode ≥100 tok/s（192+ token 实测均值）。

约束条件（用户原话）：`我要的是本地 ninfer 可以推理的` / `不要额外给我造推理引擎` / `不接受 WSL2，必须 Windows 原生 .exe` / `要支持多模态`。

## 2 时间线（按阶段）

### 阶段 I（T1–T4）接续上一会话
`/resume session-f0150a97…` 两次，读 `TASKPOINT.md`（442 行，基线 `main@6f1a3c0`）与 `ninfer-master` 内嵌 AGENTS.md，恢复 NaN 排障上下文。期间 DSH 重启两次（runtime-context 换端口 61068→53111→53264→57481→58655）。

### 阶段 II（T5–T10）9B attention NaN 根因 → 修复 → 15/15
- 症状：verify logits 100% NaN → 采样越界 → HTTP 500。
- 分段 dump 定位：`attention_projection` = `ops::linear_split` 单次 fused GEMM 出四段 `{query 4096行, key 1024行, gate 4096行, value 1024行}`；`width∈{13,14,15}` 时**只有 1024 行的 key/value 段 NaN**，Q/Gate 正常，`w≤12` 正常。
- 分支定位：`src/ops/linear/split/q4_q5/shapes/n5120_n5120_k4096/shape.cpp`
  `x.ne[1] <= 12 → launch_small`（4 段独立 launch，正确）/ `> 12 → launch_matrix`（fused RowSplitGroupedMmaJob，partial 分支坏）。
- 修法：阈值 `<=12` → `<=15` 走已验证路径；撤掉多余 paged_write。
- 结果：**5/5→15/15 全绿，长生成 111 token**；`proj_k nan=0 l2=13485`、`proj_v nan=0 l2=8380`。提交 `7e81e48`。

### 阶段 III（T12）清理 + 提交推送
删 `_tools` 下 470 个诊断 txt/构建 log（181.7 MB，D: 97.1 GB 可用）；push `6f1a3c0..7e81e48`。

### 阶段 IV（T13–T16）CUDA graph 打通
- 报错 `cudaErrorStreamCaptureInvalidated` @ `silu_mul.cu:202`；compute-sanitizer 定性首个错误是 `error 900 cudaErrorStreamCaptureUnsupported on cudaDeviceSynchronize`（捕获期 host 同步）。
- 逐层排除：`DeviceContext::synchronize()`（device.cu:241，legacy 默认流）→ 加 `graph_capture_active()` 早退，仍失败；**真凶** = `src/ops/linear/swiglu/q4/shapes/n34816_k5120/dispatch.cpp:89/133` 两处未关死的 `cudaDeviceSynchronize()` 诊断 dump。
- 结果：**decode 15.25 → 36.2 tok/s（2.3×）**；graph 与 eager 输出逐字一致。提交 `8973a04`。

### 阶段 V（T17–T31）吞吐/多模态探测 → 多个"产物缺失"定性
- 投机三条路全堵：`--spec mtp` / `--spec dflash` → `FATAL missing component`；`--lm-head-draft` 参数不存在。
- 带宽账：36 tok/s × 5.81 GiB ≈ 226 GB/s ≈ 5070Ti Laptop 峰值 29%；100 tok/s 需 ~581 GB/s（65–75%）。
- MLP 走 materialized projection（`dispatch.cpp:34-49` 对 k=4096 一律强制），`launch_q4_swiglu_gemv_pair` 硬编码 27B 的 34816/5120 无法复用。
- 实测：4 并发聚合仍 34.7 tok/s（引擎按请求串行）→ **⑤-A GEMV 路线作废**（蓝本降 P3）。
- ④ 达标：冷启 7.05 s、TTFT 25–225 ms、prefill 190.8–1720 tok/s。

### 阶段 VI（T32–T61）长 prompt NaN（≥263 token）与大量否证
- 现象链：带 tools 请求崩 → 改 `sample/kernel.cuh:56` 的 `asm volatile("trap;")` 为 `-INF` 后降级为单请求 500（引擎不再 0xC0000409 全灭，提交 `c6faf4b`）。
- 真凶改写：**不是 tools，是 prompt 长度**；二分得阈值 **≤260 token 通过 / ≥263 失败**，报 `token outside the public token domain` → 500 → 503。
- 逐项否掉：CUDA graph、tools/grammar、shape 阈值扩到 `<=512`、`--prefill-chunk 256`、`--no-prefix-reuse`、掩码宽度/词表错配、采样踩 padding、掩码全 0、grammar 词表不一致。
- 插桩三次失败（`attn_mix`、`run_layers` 汇合处、`kLayerDiag`）——**根因是分支覆盖**：`text.cpp:1401` eager 分支层末直接 `continue`，而 9B（dense，非 MoE）只走 eager，桩全在它之后。
- 桩位修正后一次命中：`L03 prefill T=263 nan=16384`（首个 full-attention 层），分段 `proj_q nan=0 / proj_gate nan=0 / proj_k nan=63276 / proj_v nan=3955` —— 与 7e81e48 同签名，只是 T>256。

### 阶段 VII（T52–T77）配置级绕行 → ①③④ 达标
- `--prefill-chunk 128` 让 310 token 长 prompt 不再 500；`--no-thinking` 让内容回落 `content`（否则全进 `reasoning_content`）。
- `5×3 => OK=15 FAIL=0`（内容非空才计）；长 prompt 312 token 3/3；`LONG2/LONG3 prompt_n=9` 证明前缀复用命中。
- 固化 `_tools/run-serve.ps1`（chunk 128 + no-thinking，注释写明不可省原因）。提交 `c812a16 / 8438297`。

### 阶段 VIII（T78–T96）G1 版本选型
- 用户判定：最佳模型 = **G1 混合量化（p6d G1_mlp_gate_up，mlp.gate/up 升 Q6）**；最佳 MTP = **v3-mix600.step300**；视觉权重"没动过"。
- 核查：G1 权重目录 `_p6d_cand\G1_mlp_gate_up` 已被清理，只剩评测 JSON（recall 0.6333 / leak 0.0333 / nogate 0.9333 / fpr 0 / trap 0.1111）与分配方案 `b4-allocation.json`（rco，assign=[q5,q4,q5,q5,q8,q6,q6,q6,q6,q8,q8,q8]，cost 4.9846）。
- 磁盘清理释放 **49.69 GB**（97.1→146.8 GB），v1 MTP 全保留。
- 落盘 `_work/ninfer-9b/TASKPOINT.md`（commit `5e8f665`）。

### 阶段 IX（T97–T122）G1 重转 + 三组件产物（② 打通）
- 纠正误判：`merged-2b-nsfw-mtp-tuned-v3\model.safetensors`（19.3 GB / 775 tensors）**已同时含** `model.language_model.* 426`、`model.visual.* 333`、`mtp.* 15` —— 视觉权重一直在。
- 转换链：`ninfer-master` 支持 q6（`infer-all-master` 不支持）→ 自写 `recipe_g1_full_gsq.py`（相对路径传入，避免 argparse 按 `:` 切盘符）。
- 卡点逐个解决：
  - 缺 `video_preprocessor_config.json` → 按 `vision_config` 生成最小版 + `--resource` 覆盖；
  - `tokenizer_config.json` 1100 B 缺 `added_tokens_decoder` → 引擎侧加"缺字段早退"（`tokenizer.cpp:283`）；
  - 产物内恒为 1100 B → 最终用 `tools.artifact.reader` 的 `read_object` 导出旧产物 5518 B 原版解决。
- 产物：`train/lines/9b-oxcoder/out/kittyrev-oxcoder9b-nsfw-gate-full-GSQ.ninfer`，7.93 GB / 738~741 objects，text+vision+mtp，q8 gate/up（64 张量，比原定 q6 更高精度）。
- ② 打通：`--vision` ready 7 s；data URI 报 `WIC: unrecognized image format`（引擎上游 base64 解码 bug），改用 **HTTP URL** 传图 → decode→image token→vision tower→文本可复现（PNG/JPG 均可）。
- 提交 `6e455f3`（run-serve 默认切新产物 + `[switch]$NoThinking` → `[bool]`，修 -File 模式默认值失效）。

### 阶段 X（T123–T156）⑤ MTP 投机：连破 13 层 → 打通但负收益 → 定性 0 接受率
逐层关卡（每层都是打印定位 → 补实例 → 重编验证）：

| # | 报错 | 修法 | 结果 |
|---|---|---|---|
| 1 | `linear_pair unsupported shape`（k=4096） | `select_q8_pair_n1024_k4096` + 常量按 K 参数化（`require_adjacent_parent_views` 加 k_hidden） | ✅ |
| 2 | `native input requires one contiguous parent region` | 打印 parts 得 4 个不同 parent → mtp attention **四合一 group（query+gate+key+value=10240 行）** | ✅ 连续 |
| 3 | `q8 linear unsupported n=10240 k=4096` | 补 q8 该形状（K 相同转发） | ✅ |
| 4 | `q8 n=4096 k=4096` | 补 | ✅ |
| 5 | `bf16 n=24576 k=4096` | 补（转发 n12288_k4096） | ✅ |
| 6 | `gdn_replay_fold unsupported record geometry` | 放宽到 32 层同 head 几何；**改 launch.h 必须删 gdn obj** | ✅ |
| 7 | `verify columns=4: slice range out of bounds`（start=4096 len=6144 extent=8192） | `projection_mma.cu:39 kValueRows 6144 → value_z_weight.n/2`；`split/.../n4096_n12288_k5120/small.cu:232`、`input_conv/q4_q5/projection.cpp:18` 改为按张量推 | ✅ |
| 8 | `Q5 direct SIMT static K differs` | `convolution.cu:173` / `projection_independent.cu:117,170` 按 x.ne[0] 分派 4096/5120 两套实例 | ✅ |
| 9 | `split_bf16_features invalid shape` | `indexing/features.cu` 的 27B 硬编码（source 14336、q/g 256×24、k/v 256×4）改为从张量推导（9B: 256×(32+8)=10240） | ✅ |
| 10 | `cudaErrorIllegalAddress` | compute-sanitizer 指到 `recurrent_fold_kernel<FoldGeometry<30,16,32,8192>>`；`[fold-miss]` 打印真值 **layers=24**（GDN 层数，非总层数）→ 新增 `FoldGeometry<24,16,32,8192>` | ✅ **投机首次跑通** |

- 速度反常：draft=3 → 10–16 tok/s；draft=1 → 31.4 tok/s，均低于无投机 34.4。
- 决定性取证（`--request-log-jsonl`）：`drafted_tokens: 190` / `accepted_tokens: 0` / `accepted_per_position: [0,…]` → **接受率精确 0.000**，属结构性不对齐（MTP 的 hidden 输入绑定或权重与 target 不匹配），非调度/窗口/fold 开销问题。
- 用户校正：`mtp不应该用V3吗？` → 确认当前产物 MTP 就来自 `merged-2b-nsfw-mtp-tuned-v3`（v3-mix600 世代），v1-reonly 的 top1=0.8516 是**训练期离线指标**，不能横比，撤回换 MTP 的提议。

## 3 会话结束时状态（T156，2026-11-08 22:00）

| # | 验收 | 状态 | 实测证据 |
|---|---|---|---|
| ① | 5×3=15/15、无 NaN/500、失败不挂死 | ✅ | `5x3 => OK=15 FAIL=0`（内容非空才计）；长 prompt 312 token 3/3；空候选只死单请求 |
| ② | `--vision` 图文问答 ≥1 例 | ✅ | `--vision` ready 7 s；HTTP URL 图 → 全链路可复现（内容质量差属"视觉没动过"的基座能力，非链路问题） |
| ③ | DSH 真实对话 | ✅（对话侧） | plain 对话含长 prompt 正常；带 tools 内容退化，属验收"工具调用可后续" |
| ④ | 首字 <15 s | ✅ | 冷启 7.05 s；长 prompt TTFT 225 ms；前缀复用后更快 |
| ⑤ | ≥100 tok/s | ⬜ **34.4 tok/s** | 投机已打通但接受率 0；无投机 34.4–35.2；100 需 581 GB/s 或有效投机 |

**当前交付物**
```
产物   train/lines/9b-oxcoder/out/kittyrev-oxcoder9b-nsfw-gate-full-GSQ.ninfer
       7.93 GB / 738~741 objects / text+vision+mtp / G1: mlp.gate+up = q8
启动   & D:\BaiduNetdiskDownload\Local-AI\_tools\run-serve.ps1
       等价：ninfer-serve.exe <model.ninfer> --max-context 4096 --greedy
             --host-context-mib 2048 --prefill-chunk 128 --no-thinking --port 1610
交接   _work/ninfer-9b/TASKPOINT.md（36,021 B / 21:59:57）
       _work/ninfer-9b/STATE-ROUND40 / ROUND47 / ROUND54 / PLAN-5A-gemv-pair-9b.md
镜像   _work/ninfer-9b/patched-20261108/（37 个文件，可直接 cp 回 ninfer-master 重放）
项目根 TASKPOINT.md（/checkpoint 两次：43bcab3 / 25ff34f）
```

**本会话产生的 19 个 commit（`6f1a3c0..43bcab3`，main == origin/main）**
```
7e81e48 修 9B attention 投影 13-15 token K/V 段 NaN
8973a04 打通 CUDA graph，decode 15.3→36.2
c6faf4b 采样空候选不再 device trap
9aa848f grammar 约束失败降级为无约束
c696d37 收尾长 prompt 临时开关 + STATE-ROUND40
38edf1d 落盘长 prompt NaN 决定性证据（L03/proj_k，T=263）
c812a16 固化 chunk128+no-thinking 与 8/8 验收
8438297 严格口径 15/15
408a2f5 记录 5-A GEMV 路线常量映射
5009b69 5-A 蓝本 + 备份
080d134 修正 5-A 蓝本（CMake 无 GLOB）
139ac41 ⑤ 结论修正：GEMV 不破带宽下限
5e8f665 落盘 TASKPOINT（验收/G1/step300/重建链）
6e455f3 G1 产物落地 + run-serve 切换 + switch 修正
33d6b07 9B 多模态与投机 4 组引擎改动
8e3b2c9 ⑤ 阻塞点定位（mtp 4-part vs 2-part）
af914b6 ⑤ 连破 7 层
25ff34f checkpoint：9B 交付形态成立
43bcab3 checkpoint：⑤ 定性（接受率≈0，34.4 天花板）
```

## 4 雷区（会话内实测踩出来的，接续必须守）

1. **Ninja 不跟踪被 include 的头**：改 `.cuh` / `launch.h` 必须手动删对应 `.obj`，否则改动不生效（第 6 层、第 13 层都踩过）。
2. **诊断代码必须编译期关死**：`cudaDeviceSynchronize` 落进 CUDA 流捕获区间 → error 900 → 整个捕获 901 失效。
3. **`--prefill-chunk` 默认（>128）会让 ≥263 token 的 prefill 在 L03 出 `proj_k/proj_v` NaN**；`--no-thinking` 不加则内容全进 `reasoning_content`、`content` 为空。两个参数不可"优化"掉。
4. **`run-serve.ps1` 里 `[switch]$x = $true` 在 `-File` 模式下默认值失效** → 必须写 `[bool]$x = $true`。
5. **recipe 传绝对路径会被 argparse 的 `file:function` 语法按 `:` 切成盘符** → 用相对路径。
6. **`infer-all-master` 不支持 q6**，G1 必须用 `ninfer-master` 转换。
7. **`--resource` 对某些 role 不生效**（tokenizer_config），且 `read_range` 拿到的是 `raw_bytes_v1` 封装不是裸 JSON → 用 `read_object` 导出。
8. **`.conversion.json` 残留 / 影子目录**会导致转换器读坏 json（`Extra data`）而静默不重转（产物 mtime 不变是判据）。
9. **fold spec 里的 `layers` 是 GDN 层数**（32 层里每 4 层 1 full → 24），不是总层数。
10. **dispatch 缺形状的正确查法**：在 throw 前打印 `(n,k,t)`，再补一条 K 相同的转发实例（`Bf16ScheduleInstance<…,K>` 只有 K 参与实例化，N 是运行期）。
11. **verify（T=4）与 prefill 走的不是同一条 GDN conv 分派**，prefill 正常不代表 verify 正常。
12. **PowerShell `${n}` / 反引号 / 管道缓冲**：长作业输出在进程结束才一次性出现，`job_output` 前别重复启动。

## 5 未完成项与下一步（会话内已定方向）

**⑤ 的三种成因（按可验证性排序）**
1. MTP 的 hidden 输入取错（最可能）：MTP 要吃 target 的 final hidden（经 `mtp/pre_fc_norm_hidden`），若绑定到 pre-norm / 错误层 / 错误位置，draft 必然全错 → dump 输入张量对齐验证。
2. MTP 权重与本 target 不匹配：mtp 仍是 cd 世代 q8/bf16 混配，与 G1 的 text 权重不同代 → 用 G1 量化后的 text 重训 MTP 头。
3. 记为上限制：接受率 0 若无法修，⑤ 的天花板就是 34.4 tok/s，需换 dflash 权重或重训 MTP。

**旁路状态（会话外现状，读取时实测）**
- `schedule-151d8022-aad4-4cc9-bbb7-4660fb5da60c` 仍 **active**，`FREQ=MINUTELY;INTERVAL=30;COUNT=48`，下文投递 `2026-11-08 22:30 (+08)`，target = 本会话（session-e06f434c）→ 会持续唤醒旧会话。
- git HEAD `43bcab3`，`main == origin/main`；但工作区存在未提交改动（`AGENTS.md` / `CLAUDE.md` / `_research/*` 修改，`_tmp/*` 大量删除）→ 与本会话无关的漂移，接续前需确认来源。

## 6 提取产物（本次读取生成，全部在工作区内）

```
_work/session-audit/s-e06f434c.jsonl              明文全量事件（39.3 MB / 7705 行）
_work/session-audit/s-e06f434c.jsonl.index.json   逐事件 type/keys/len 索引
_work/session-audit/s-e06f434c.transcript.md      全量对话记录（3.39 MB，user/assistant/tool 全展开）
_work/session-audit/s-e06f434c.digest.md          逐轮摘要（1.07 MB）
_work/session-audit/s-e06f434c.core.md            去噪核心日志（332 KB）
_work/session-audit/s-e06f434c.spine.md           任务骨架：用户输入+助手结论+goal+compaction（218 KB）
_work/session-audit/e06f434c-READOUT.md           本报告
脚本：unframe2.mjs（复用）· probe-e06f434c.mjs · shape-e06f434c.mjs · digest-e06f434c.mjs
      skim-e06f434c.mjs · core-e06f434c.mjs · spine-e06f434c.mjs
```
