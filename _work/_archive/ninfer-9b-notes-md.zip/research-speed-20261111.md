# ninfer-9B 单流 decode 冲 100 tok/s：技术清单（联网调研）

> 口径：单流 decode（batch=1、无并发）、RTX 5070 Ti Laptop 12 GB、Windows 11、权重 8.69 GiB 的 Qwen3.5-9B GSQ 混合量化。
> 基线：36 tok/s（27.8 ms/token）、prefill 2.0–2.2k tok/s、TTFT 144 ms / 0.7–1.7 s。
> 标注规则：**（估算）**＝我按带宽算术或他卡数据外推；**（未证实）**＝检索不到一手数据。

---

## 0 先算硬边界：为什么 100 tok/s 不是"调参"能到的

| 量 | 数值 | 说明 |
|---|---|---|
| 权重/次前向 | 8.69 GiB = **9.33 GB** | GSQ q4/q5/q8 混配 |
| 实测步时 | 27.8 ms（36 tok/s） | 你给的基线 |
| 实测有效带宽 | 9.33 GB / 0.0278 s = **336 GB/s** | 只用掉峰值 672 GB/s 的 **50%** |
| 峰值带宽 | **672 GB/s**（12 GB GDDR7 / 192-bit） | [规格](https://baike.baidu.com/item/GeForce%20RTX%205070%20Ti%20Laptop%20GPU/67481312) |
| **8.69 GiB 下的理论天花板** | 672 / 9.33 = **72 tok/s** | 100% 峰值、零开销，现实不可达 |
| 80% 峰值下的天花板 | **58 tok/s** | 更现实的目标线 |
| 想 100 tok/s 需的 bytes/token | ≤ **5.7 GB**（85% 峰值）或 ≤ 3.4 GB（维持现 336 GB/s） | 二选一 |

**结论：在当前 8.69 GiB 权重下，任何投机/调度手段都不可能到 100 tok/s——上限就是 72。** 必须先减 bytes/token，再叠加"一次前向多出 token"。两条腿缺一不可。

---

## 1 Qwen3 / Qwen3.5 官方 MTP 头：结构、loss、数据、接受率

| 来源 | MTP 结构 | loss / 训练法 | 训练数据 | 依赖主干 hidden | 公开接受率 | 证据 |
|---|---|---|---|---|---|---|
| **DeepSeek-V3**（唯一完整公开的配方） | 1 个 MTP module：`RMSNorm(h_{t-1})` → `Linear(2d→d)`（把上一位置主干 hidden 与当前 token embedding 拼接后投影）→ 1 个 Transformer block → **共享主模型 output head**；顺序堆叠 D 个可扩到 D>1 | 各深度 cross-entropy 取平均，加权 **λ=0.3（前 10T tokens）/ 0.1（后 4.8T）**；主模型 loss 与 MTP loss 联合反传 | 与预训练**同分布同语料**，无额外数据 | **是**（必须拿主干 hidden，不能只用 token id） | **第二 token 85%–90%，端到端 1.8× TPS**；推理时可整体丢弃不影响主模型 | [arXiv:2412.19437](https://arxiv.org/abs/2412.19437) · [论文要点摘录](https://jbarrow.ai/field_notes/deepseek-v3/) |
| **Qwen3（初代，2025-04）** | **无 MTP**（纯 next-token 训练） | — | — | — | — | 同上 Qwen3-Next 博客对比段：MTP 是 Qwen3-Next 才引入的 |
| **Qwen3-Next**（2025-09） | "native MTP"，官方称"not only yields an MTP module with a high acceptance rate"；具体层结构/参数**未公开**（HF config.json 无 mtp_* 字段，HF Transformers 不支持 MTP） | 额外做 **multi-step 训练**以保持 train/infer 一致，专门优化多步推理下的接受率 | 未公开 | 是（按其服务端实现推断，**未证实**具体取哪层） | 官方只给"high acceptance"，**无数字（未证实）**；SGLang 推荐 `--speculative-num-steps 3 --eagle-topk 1 --num-draft-tokens 4`，vLLM 推荐 `num_speculative_tokens: 2` | [Qwen3-Next 官方博客](https://www.alibabacloud.com/blog/qwen3-next-towards-ultimate-training-%26-inference-efficiency_602580) · [config.json](https://huggingface.co/Qwen/Qwen3-Next-80B-A3B-Instruct/blob/main/config.json) |
| **Qwen3.5**（2026-02） | 明确"built on Qwen3-Next architecture … and multi-token prediction"，即沿用同一套 MTP；**9B 档是否随权重发布 MTP head 未证实** | 未公开 | 未公开 | 是 | **无官方数字（未证实）**；社区声称微调后 MTP-1 接受率 98%+（单条推文，**未证实**） | [Qwen3.5 官方博客](https://www.alibabacloud.com/blog/qwen3-5-towards-native-multimodal-agents_602894) |
| **Qwen3.8-27B**（同族，含原生 MTP head） | 随权重发布**独立 31 个 tensor 的 MTP head**（单独 shard） | 未公开 | 未公开 | 是 | **depth-1 实测 85.9%**；**depth 3 净亏**，因为"每多验 1 个 token，目标步时 +~20%" | [OsaurusAI/Qwen3.8-27B-JANG_2D](https://huggingface.co/OsaurusAI/Qwen3.8-27B-JANG_2D) |

### 对你那套 2/753（0.27%）的判断

期望值 85%，实测 0.27%，且输出损坏 —— **这是接线 bug，不是"头没训好"**。按此顺序排查（每条都可单独证伪）：

1. **hidden 来源层错了**：MTP 必须吃"最后一个 Transformer block 的 norm 后 hidden"；吃到 norm 前、或吃到 embedding，会产生"语法通但语义乱"的损坏输出。
2. **vocab 错位**：Qwen3.5 词表 250k 级 vs Qwen3-Next 151,936；embedding/输出头 tie 关系不一致 → logits 全错。
3. **位置偏移**：预测 t+1 时必须用位置 t+1 的 RoPE，沿用 t 会系统性偏一位。
4. **验证端不一致**：verify 用 greedy 而 draft 用采样（或反之），接受率会直接塌到个位%。
5. **chat template / 多步一致性**：DeepSeek 系实测"chat template 会显著压低 MTP 接受率"（[ROCm/ATOM #609 标题即结论](https://github.com/ROCm/ATOM/issues/609)）。

先做 1→3 的定点验证（同 prompt 下拿 MTP 头对"已知 ground truth 的下一个 token"打分，看 top-1 是否落在正确 token 上），比重新训练便宜两个数量级。

---

## 2 其他投机路线：要什么、能不能在 12 GB 共存

| 方法 | 预期单流收益 | 预期吞吐收益 | 需要什么 | 代价与风险 | 适用性判断 | 证据 |
|---|---|---|---|---|---|---|
| **修/重训 MTP head** | **1.5–2.1×**（36→54–76） | 同（单流即吞吐） | 1 层 head（约 0.2–0.4 B 等效参数）+ 主干 hidden 抓取管线 + 训练脚本 | 需拿 hidden 重跑语料；头坏了会静默降质 | **★★★★★ 最匹配**：架构已存在，只差接线/重训 | 1.8×@85–90% [DSV3](https://arxiv.org/abs/2412.19437)；49→75 t/s@60–75% [同卡实测](https://atomgit.com/GitHub_Trending/bo/Bonsai-demo/blob/main/community-benchmarks/bonsai2/cuda-rtx5070ti-laptop-windows.md) |
| **EAGLE-3** | 论文最高 **6.5×**（约为 EAGLE-2 的 1.4×） | SGLang bs=64 时 **+38%** | 1 层 draft 头 + **多层 hidden 融合**（training-time test）+ 离线训练 + 引擎侧树状验证 | 必须暴露多层 hidden；树验证要改 kernel；小模型上 6.5× 拿不到 | ★★★☆ 收益上限最高，工程量最大 | [arXiv:2503.01840](https://arxiv.org/abs/2503.01840) |
| **Medusa** | **2.2×**（Medusa-1，冻结主干）/ **2.3–3.6×**（Medusa-2 联训） | 中 | 多个解码头 + 树状 attention + 训练 | 头多、树验证复杂；联训要动主干 | ★★☆ 不如 MTP 直接 | [arXiv:2401.10774](https://arxiv.org/abs/2401.10774) |
| **n-gram / prompt lookup** | **0–1.6×，本机实测净亏** | 低 | **零训练、零权重**（llama.cpp 内置 ctx/dyn/static 三级 n-gram 缓存） | 接受率强依赖"逐字复制"；draft 本身极便宜（0.45–1.2 µs/token），但**验证路径打碎 CUDA graph / 批形状**，低接受率下净亏 | ★☆ 只在代码补全/大段引用场景值得开 | 同卡实测：chat 0% 接受 38–39 t/s（基线 49），文本续写 54% 接受仍只有 39 t/s [见](https://atomgit.com/GitHub_Trending/bo/Bonsai-demo/blob/main/community-benchmarks/bonsai2/cuda-rtx5070ti-laptop-windows.md)；draft 成本 [42× 优化文](https://jadidbourbaki.github.io/blog/prompt-lookup-llama-cpp/) |
| **Lookahead decoding**（无 draft 模型） | **1.8×**（MT-bench） | 4×（多卡强扩展） | 无额外权重，只需并行 n-gram 池 + 验证 | 每步 log(FLOPs) 换步数，单流收益有限 | ★★ 无权重依赖，可作为 n-gram 失败后的备选 | [arXiv:2402.02057](https://arxiv.org/abs/2402.02057) |
| **LayerSkip（self-speculation）** | **1.82–2.16×**（coding / 摘要） | 中 | **必须重训主干**：layer dropout（前低后高）+ 全层共享 early-exit loss | 你已有量化成品，重训主干等于推翻现有资产 | ★ 不适用 | [arXiv:2404.16710](https://arxiv.org/abs/2404.16710) |
| **独立 draft model（0.5B 级）** | 1.5–2.5×（**未证实**于 9B←0.6B 组合） | 中 | 独立权重（fp16 1.2 GiB / int8 0.6 GiB / q4 ~0.35 GiB）+ 双模型调度 | draft 与 target 分布差大 → 接受率常 50–70%；两次前向各自读权重，带宽翻倍，**净收益可能为负** | ★★ 显存能共存，但性价比低于头方案 | 共存算术见下 |

### 12 GB 共存算术（可直接套）

```
主模型权重            8.69 GiB
KV（Qwen3-8B 口径：36 层 × 8 KV head × 128 × 2 × 2B = 0.14 MiB/token）
   2k ctx             0.28 GiB
   8k ctx             1.18 GiB
   32k ctx            4.72 GiB   ← 32k 时已无空间放 draft
运行时/workspace      0.6–1.0 GiB
────────────────────────────────
2k ctx 下可用余量     ≈ 12 − 8.69 − 0.28 − 0.8 = 2.2 GiB
```
→ **头方案（20–400 MB）随便放；0.6B draft 在 ≤8k ctx 也能放（fp16 1.2 GiB），但一次 decode 要读两套权重，带宽账不划算。**

---

## 3 量化与带宽：真正能动 bytes/token 的手段

| 手段 | 预期单流收益 | 预期吞吐收益 | 需要什么 | 代价与风险 | 适用性 | 证据 |
|---|---|---|---|---|---|---|
| **权重 bpw 从 ~8.3 降到 ~4.5**（GSQ 重配：敏感层保 q8，其余 q4） | **+60–80%**（36→58–65；9.33→5.1 GB） | 同 | 重跑校准 + 精度回归 | 9B 上 q4 有掉点风险，需 eval 卡门 | **★★★★★ 最便宜的一条腿**（纯算术：bytes ∝ 1/速度） | 带宽算术见 §0；INT4 8B 单流 205 TPS vs NVFP4 124 TPS [实测](https://joshua8.ai/blackwell-gpu-shootout/) |
| **FP8 权重（8 bit）** | ≈0（与现 8.69 GiB 同量级） | 中 | SM120 FP8 GEMM kernel | 白忙 | ★ 无意义 | 同上 |
| **NVFP4 权重** | **−40%**（5090 c=1：124 vs INT4 205 TPS） | **+33%**（c=128：8691 vs 6510） | Blackwell FP4 kernel + 双层 scaling 校准（16 值/块 + FP32 张量级） | 单流反而更慢；显存仅 FP16 的 25% | ★★ **只提吞吐，不提单流** | [NVFP4 官方博客](https://developer.nvidia.cn/blog/introducing-nvfp4-for-efficient-and-accurate-low-precision-inference/) · [对照实测](https://joshua8.ai/blackwell-gpu-shootout/) |
| **KV cache int8/fp8** | 短 ctx **≈0 或略负**；长 ctx 显著（ITL 斜率降到 **54%** of BF16） | **+14.9%**（c=8，20k 输入） | FA3/FlashInfer 的 FP8 attention kernel | head_dim=256 时 prefill 反而慢 ~1.6×；短于 **~7k token 有恒定开销** | ★★ 你是 1.4–2k 短 prompt → **容量手段，不是速度手段** | [vLLM FP8 KV 长文](https://vllm-project.github.io/2026/04/22/fp8-kvcache.html) · [文档](https://docs.vllm.ai/en/latest/features/quantization/quantized_kvcache.html) |
| **GQA** | 已具备（Qwen3-8B：32 Q / 8 KV head = 4:1） | — | 架构既定 | 改不了 | — 无操作项 | [Qwen3-8B config](https://huggingface.co/Qwen/Qwen3-8B/blob/main/config.json) |
| **batch 并发换吞吐** | **0**（单流不变） | 近似线性：5070 Ti(16G) 205 → **2,689 TPS** @c=32 | 调度器 + 显存 | 12 GB 上 KV 先 OOM（同卡 16G 版 c=64 OOM） | ★★ 与"单流 100"目标正交 | [实测](https://joshua8.ai/blackwell-gpu-shootout/) |

**关键对照**：5070 Ti **桌面 16 GB**（896 GB/s）跑 Llama-3.1-8B GPTQ-INT4，**c=1 时 205 tok/s**。折算到你的 672 GB/s、12 GB，同 bpw 下 c=1 应落在 **~150 tok/s（估算）**；你现在 36 tok/s 的差距，一半来自 8.69 GiB 的高 bpw，一半来自 kernel 只用掉 50% 带宽。

---

## 4 Windows + 12 GB 的工程手段：收益区间与代价

| 手段 | 预期单流收益 | 预期吞吐收益 | 需要什么 | 代价与风险 | 适用性 | 证据 |
|---|---|---|---|---|---|---|
| **CUDA graph**（捕获整个 decode 步） | **+3–10%（估算）** | 同步提升 | 固定形状捕获；变长/树验证要按桶重捕 | 投机验证的动态形状会打破图，需分桶 | ★★★★ 便宜、无精度风险 | 机制见 [vLLM CUDA Graphs 设计文档](https://github.com/vllm-project/vllm/blob/main/docs/design/cuda_graphs.md)；百分比为按"50% 带宽利用率"反推，**未证实** |
| **单流 kernel 调优（提高带宽利用率 336→500 GB/s）** | **+45%（估算）**（36→52） | 同 | GEMV 合并、去 launch 开销、向量化 dequant | 纯工程时间 | ★★★★ 与量化叠加后是达标关键 | 同卡 27B@5.53 GiB 跑到 49 t/s ≈ **291 GB/s（43% 峰值）**，说明这类卡上利用率普遍只有 4–5 成 [实测](https://atomgit.com/GitHub_Trending/bo/Bonsai-demo/blob/main/community-benchmarks/bonsai2/cuda-rtx5070ti-laptop-windows.md) |
| **chunked prefill** | **0 或略负** | 多请求时明显（ITL 更平滑） | 调度器分块 | 单流无收益 | ★ 与目标无关 | [vLLM 优化文档](https://docs.vllm.ai/en/latest/configuration/optimization.html) |
| **prefix cache** | decode 0；**TTFT 0.7–1.7 s → ~0.1 s** | 高（agent 多轮） | 前缀哈希 + KV 复用 | 吃显存 | ★★★★★ agent 场景必开 | [vLLM APC](https://docs.vllm.ai/en/latest/features/automatic_prefix_caching.html) |
| **FlashAttention 版本** | FA2 相对朴素 attention 有收益；**FA3 仅 Hopper（SM90），SM120 用不了** | 中 | FA2 需 sm120 补丁才能在 5070 Ti 上编过 | Windows 编译链是主要成本 | ★★ 走 FlashInfer / cuDNN SDPA 更省事 | [FA2 vs FA3](https://www.aquanode.io/blog/flash-attention-2-vs-3) · [sm120 补丁](https://github.com/sorryhyun/flash-attention-sm120-fix) · [Windows 构建 issue](https://github.com/Dao-AILab/flash-attention/issues/1469) |
| **Tensor parallel** | **不适用**（单卡；无 NVLink 的第二块卡） | — | 多卡 | — | — 直接排除 | [vLLM 并行文档](https://docs.vllm.ai/en/latest/serving/parallelism_scaling.html) |

---

## 5 单流 100 tok/s 判定表（哪些真能到，哪些只提吞吐）

设 L = 每次验证平均产出 token 数，c = 每多验 1 token 的步时增量（你这类卡实测 **c≈0.2–0.3**，来自 Qwen3.8 bundle 的"~20%"与 Bonsai 49→75 反解），则单流加速 ≈ `L / (1 + c·(L−1))`。

| 方案组合 | 算式 | 预期单流 | 到 100？ | 判定 |
|---|---|---|---|---|
| 现状（8.69 GiB，无投机） | 672/9.33 封顶 | 36（实测） | ❌ | 硬上限 72 |
| 只修 MTP 到 accept≈3 | 36 × 3/(1+0.6) = 67 | 60–76 | ❌ | 单腿不够 |
| 只降 bpw 到 4.5（5.1 GB） | 36 × 9.33/5.1 | 58–65 | ❌ | 单腿不够 |
| **降 bpw 4.5 + MTP accept 3** | 65 × 1.875 | **110–125** | ✅ | **唯一稳过 100 的组合** |
| 只把带宽利用率提到 85% | 36 × 1.7 | 55–61 | ❌ | 需与上面叠加 |
| 只开 n-gram / PLD | 同卡实测 38–39（基线 49） | **净亏** | ❌ | 除逐字复制场景 |
| 只开 NVFP4 权重 | 5090 c=1 实测 −40% | 更慢 | ❌ | 只提吞吐 |
| 只开 KV fp8 | 短 ctx 无收益 | 36 | ❌ | 容量手段 |
| 加 batch / 并发 | 单流不变 | 36 | ❌ | 吞吐手段（205→2689 TPS） |

---

## 6 按性价比排序的 3 条建议

**① 先把权重压到 ~4.5 bpw（5.1–5.7 GB），零训练成本，单流 +60–80%**
- 数字：8.69 GiB→5.1 GB 即 bytes/token ×0.55；同 kernel 效率下 36 → **58–65 tok/s**。依据是纯带宽算术（672 GB/s ÷ 5.1 GB = 132 tok/s 封顶），并有 8B INT4 c=1 = 205 tok/s 的旁证：<https://joshua8.ai/blackwell-gpu-shootout/>
- 做法：GSQ 里把 q8/bf16 层按敏感度重排，只保留 attention/embedding 关键层 q8，其余 q4；用固定 eval 集卡门（掉点 >1% 就回收一层）。
- 风险：q4 在 9B 上掉点；建议目标 4.5–5.0 bpw 而非 4.0。

**② 修 MTP 接线（不行再用自有数据重训 1 层 head），目标 depth-1 ≥80%、draft 长度 2–3**
- 数字：DSV3 85–90% 接受率 → **1.8× TPS**（<https://arxiv.org/abs/2412.19437>）；Qwen3.8-27B 原生头实测 depth-1 **85.9%**，且 **depth 3 净亏**（每多验 1 token +20% 步时）（<https://huggingface.co/OsaurusAI/Qwen3.8-27B-JANG_2D>）；**同型号 5070 Ti Laptop 12 GB + Windows 11** 上 MTP 打开后 49 → **70–75 t/s**（code/structured，接受率 60–75%），chat 只 49–57（<https://atomgit.com/GitHub_Trending/bo/Bonsai-demo/blob/main/community-benchmarks/bonsai2/cuda-rtx5070ti-laptop-windows.md>）；同一实测还给出 **`--spec-draft-n-max 2` 优于 4**。
- 先查 §1 的 5 条接线 bug（hidden 层/vocab/位置/验证一致性/template），2/753 这个量级几乎必然是接线问题。
- 叠加 ①：65 × 1.875 ≈ **110–125 tok/s**。

**③ CUDA graph + 单流 kernel 把带宽利用率从 50% 提到 ≥75%，顺带开 prefix cache**
- 数字：现 336 GB/s（50%）；同卡同架构实测只到 291 GB/s（43%）→ 这类卡利用率普遍 4–5 成（<https://atomgit.com/GitHub_Trending/bo/Bonsai-demo/blob/main/community-benchmarks/bonsai2/cuda-rtx5070ti-laptop-windows.md>）。提到 500 GB/s 即 **36 → 52 tok/s（估算，未证实）**；叠加 ① 后 5.1 GB 下可到 **98 tok/s**，再叠 ② 稳过 100。
- 同时开 prefix cache：TTFT 从 0.7–1.7 s 降到 ~0.1 s 量级（agent 多轮收益最大）<https://docs.vllm.ai/en/latest/features/automatic_prefix_caching.html>
- 风险：投机验证的动态形状会打破 CUDA graph，需按 draft 长度分桶重捕；先做 graph 再做投机，顺序不能反。

---

## 附：本文的假设与未证实项

| 项 | 状态 |
|---|---|
| Qwen3.5-9B 的 KV 头数/层数/是否随权重发布 MTP head | **未证实**（公开 config 只查到 Qwen3-Next-80B 与 Qwen3-8B；KV 算术用 Qwen3-8B 口径代填） |
| Qwen3-Next MTP 的具体层结构、loss 权重、训练数据配比 | **未证实**（官方博客只给"native MTP + multi-step 训练 + 高接受率"，技术报告未检索到） |
| Qwen3.5 MTP 接受率 98%+ | **未证实**（单条推文） |
| CUDA graph 的 +3–10%、kernel 提到 500 GB/s 的 +45% | **估算**（按带宽利用率反推，未在你机器上实测） |
| 0.6B draft 对 9B 的接受率 | **未证实**（无该组合公开数据；一般经验 50–70%） |
| 5070 Ti Laptop 满血 TGP 下的绝对 t/s | 上述同卡数据是 **55 W 限功耗**下测的；作者自述 140 W 时约 1.6×，换算时注意 |

当前:ninfer-9B 单流提速调研 / 结果:D:\BaiduNetdiskDownload\Local-AI\_work\ninfer-9b\research-speed-20261111.md / 下一步:按 §1 五条接线 bug 验 MTP 头 top-1 命中，同时起 GSQ 4.5bpw 重配
