# 交接提示词（复制下面整块给 DSH）

> 用法：把 `====` 之间的内容整段粘贴给接手方。它自带定位、状态、约束与验收口径。

====

你是 ninfer 9B 本地推理引擎的接手工程师。上一棒（WorkBuddy AI）已在引擎侧收口，现在把工作交给你。**不要重新调研已经定案的东西**，先读文档，再按顺序执行三个任务。

## 第一件事：读交接文档

唯一权威入口：

```
D:\BaiduNetdiskDownload\Local-AI\_work\ninfer-9b\TASKPOINT.md
```

只读文件顶部 **第 1–259 行**（`§H` 交接段）即可上手。需要细节时再跳：

- A-15 乱码真因（attention 四段输出错绑）→ 第 1609 行
- A-17 MTP 逐层对拍 + `features.cu` 几何越界修复 → 第 1822 行
- A-18 MTP 头不成立的定案 → 第 1887 行

第 260 行起是 2026-11-10 的历史交接，**结论已被覆盖，仅作背景，不要据此行动**。

## 已定案的事实（不要再查、不要推翻）

**引擎侧没有待修的东西。** 以下三条都有闭环证据：

1. **A-15（已修）** 乱码根因是 `src/ops/linear/split/q4_q5/shapes/n5120_n5120_k4096/mma.cu` 的 grouped-MMA 把 9B attention 的四个独立输出当成两块 5120 行连续缓冲写，造成越界 + 相邻张量互覆盖。已改为四个 RowSplit job 直写 `outputs[0..3]`。闭环验证：修复前独立 FP64 oracle 测试在 T=16 处进程异常终止，修复后整套 OK。
2. **A-17（已修）** `src/ops/indexing/features.cu` 的 `split_bf16_features` kernel 把 27B 几何（14336/6144/1024）写成编译期常量，9B（10240/4096/1024）上 token 边界错位并把 6144 行 q 写进 4096 行张量。已改为 `SplitGeometry` 由 host 推导传入。
3. **A-18（已定案，非代码问题）** MTP block 实现完全正确——用真实权重在 torch 侧整层复算，与引擎逐段一致到 bf16 舍入级，**cosine = 1.00000**。但 MTP 头本身不可用：同一份 hidden 下主干 `lm_head` 能复现真实下一 token **9/12**，MTP 头只有 **7/101**（长 prompt，n=101），且输出退化成 3 种 token。

当前五条验收：①内容正确 ✅ · ②多模态 ✅ · ③可接入 DSH ⚠️ · ④首 token ✅ · ⑤decode ≥100 tok/s ❌

**所以 ⑤ 卡在权重，不在引擎。别再去引擎代码里找 ⑤。**

## 环境与命令（照抄）

```powershell
# 启动（参数不可省）
ninfer-serve.exe D:\BaiduNetdiskDownload\Local-AI\train\lines\9b-oxcoder\out\kittyrev-oxcoder9b-nsfw-gate-full-GSQ.ninfer `
  --max-context 4096 --greedy --host-context-mib 2048 --prefill-chunk 128 --no-thinking --port 18900

# 只重建三个应用（改完源码后；MSVC 环境已写进 bat，不要手搭）
& D:\BaiduNetdiskDownload\Local-AI\_work\ninfer-9b\p3-rebuild-apps.bat

# 回归（17 条，判据：17/17 clean + bad markers NONE）
& C:\ProgramData\anaconda3\python.exe D:\BaiduNetdiskDownload\Local-AI\_work\ninfer-9b\p3_regress.py
```

硬约束：

- `--prefill-chunk` 必须是 128 的正整数倍；`--no-thinking` 不可省。
- `BUILD_TESTING` 保持 **OFF**。要重编 oracle 测试才临时开，编完改回。
- 改完 `.cu/.cpp` 先删对应 `.obj` 再编，否则 ninja 可能不重编。
- 探针必须配 `--no-cuda-graph`（探针内有 `cudaDeviceSynchronize`，会让 graph capture 失效）。
- 工作目录是 `_work/ninfer-9b`（**带前导 n**），写成 `infer-9b` 会 FileNotFoundError。
- 探针/脚本用 `C:\ProgramData\anaconda3\python.exe`；需要 torch/safetensors 的用 `train\.venv\Scripts\python.exe`。
- 禁删资产：`ninfer-27b-kv-stream-3arch-20261019/`、`ninfer-csunx/`、`train/.venv/`、`train/lines/9b-oxcoder/models/`、`train/lines/27b-kittyrev/{base,local-pack}/`、`plugins/`。不碰 27B 档位。

## 你的三个任务（按代价排序，依次做）

**任务 1 · 收口 ③「可接入 DSH」（最便宜，先做）**

重启 DSH 加载新 exe，用 `build-9b` 档位跑一轮**带 system + tools** 的真实会话。
判据：会话内不乱码、TTFT 可接受（历史值 164 ms）、无 500。适配器路径未变，不需要改配置。

**任务 2 · ⑤ 二选一（必须选，别悬着）**

- **A. 重训 MTP 头**（唯一能翻盘）：用当前服务模型的 hidden（A-18 已证是正确末层输出）+ 现有 SFT 语料，按 `train/lines/27b-kittyrev/quant/mtp_posttrain.py` 的配方重训 1 层，目标 top1 ≥ 0.5，再重转换、回填验证 `draft_n_accepted`。
- **B. 关掉投机、记为交付上限**：不带 `--spec mtp` 时 20–43 tok/s（典型 30–43）。把「34 tok/s 是本机 12 GB 卡的交付上限」写进结论。

**任务 3 · 可选（优先级最低）** data URI / inline base64 传图走不通，属上游 WIC 路径问题。HTTP URL 传图已完全可用（2.44 s，描述正确）。除非 DSH 侧必须支持 data URI，否则不用碰。

## 交付口径

- 结论要带数字和复现命令，不要写「应该」「大概」。
- 动过源码就列：文件路径 + 改了什么 + 对应 `.bak` 名 + 回滚命令。
- 收口时报告：`ninfer-serve.exe` 进程数（应为 0）、显存占用、回归结果、五条验收的最新状态。
- 遇到与本文档结论冲突的实测，**以实测为准**，但要在 `TASKPOINT.md` 里写清哪条旧结论被推翻、依据是什么。

====
