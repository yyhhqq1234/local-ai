# 速度组实测：draft-tokens / ngram-archive / lookup-ngram · 2026-10-20

> 对象：`ninfer-27b-kv-stream-3arch-20261019` / RTX 5070 Ti Laptop 12G / sm120a
> 口径：**decode tok/s 一律取引擎日志 `req#N done | … | decode X tok/s`**（脚本按 SSE chunk 计数会低估一半，已弃用）
> 驱动：`tools/decode_matrix.py`（每变体起一次引擎，同进程内连发 N 次请求）+ `tools/bench_decode.py`

## 1. 结论

| 开关 | 判定 | 数据 |
|---|---|---|
| `--draft-tokens 1`（现状） | ✅ **已是最优** | 峰值 90.4 tok/s，MTP 接受 **72.8%** |
| `--draft-tokens 3 / 4 / 6` | ❌ 净负 | 峰值 93.8 / 92.6 / 77.1；**接受率崩到 35.9% / 34.3% / 34.4%**，后续请求更低 |
| `--adaptive-mtp` 配宽 draft | ❌ 无效 | 自适应下限是 3，draft=1 时等于没开；draft≥3 时它收缩也救不回验证开销 |
| `--lm-head-draft` | ❌ **不可用** | 启动 FATAL：`selected proposal head is absent from artifact`（v3-mtponly 无 proposal head） |
| `--lookup-ngram 16` | ❌ 无增益 | 峰值 90.9 vs 基线 90.4；接受率同为 72.8% |
| `--ngram-archive-mib 512 --ngram-session-mib 256` | ✅ **显著正向** | 同进程第 3 次请求起：**134 / 140 / 221 / 120 tok/s** vs 基线 **82 / 80 / 81 / 82**，峰值 **2.7×** |

**根因**：draft 加宽后每轮验证的 token 数翻倍，但接受率按比例下跌（72.8% → 36%），验证成本吃掉全部收益。真正有效的是 **ngram 复制源归档**——它只在「同会话、重复结构」时命中，命中时几乎不花验证成本（日志 `ngram 178/199 accepted, 14 rounds`）。

## 2. draft-tokens 矩阵（plain 任务，256 token greedy，每变体同进程 2 次请求）

| 变体 | draft | decode 峰值 | 各请求 decode | MTP 接受 |
|---|---:|---:|---|---:|
| B0 基线 | 1 | **90.4** | 90.4 / 63.3 / 81.8 | **72.8%** |
| B1 | 3 | 93.8 | 93.8 / 71.3 / 82.6 | 35.9% |
| B2 | 4 | 92.6 | 81.4 / 66.7 / 92.6 | 34.3% |
| B3 | 6 | 77.1 | 77.1 / 57.7 / 76.3 | 34.4% |
| B5 lookup-ngram 16 | 1 | 90.9 | 90.9 / 63.3 / 83.5 | 72.8% |
| B7 combo（d3+lookup+archive） | 3 | 93.3 | 93.9 / 70.2 / 93.3 | 36.2% |

## 3. ngram-archive：唯一有效的提速项

### 3.1 同进程 4 次请求（plain，无客户端 session 头，走引擎直连）

```
B0 基线            : 89.2  62.1  81.6  79.6   (mtp 428/588, 72.8%)
B6 archive 512/256 : 91.3  83.4 134.3 139.9  ← 第 3 次起跳到 134+
B6 第二轮（6 次）  : 91.3  83.4 134.3 139.9 220.8 120.5
```

前两次与基线无差（archive 里还没有可复用的复制源），**第 3 次起稳定跳升**。

### 3.2 端到端（走网关 8081，客户端不发任何 header）

gateway 注入 `X-NInfer-Draft-Session`（首条 system/user 内容 sha1 前 16 位）：

| 请求 | decode | 命中情况 |
|---|---:|---|
| #1 | **85.2** | mtp 107/147 |
| #2 | **134.3** | mixed speculation（mtp + ngram） |
| #3 | **140.8** | ngram 118/120 accepted |
| #4 | **205.9** | ngram 178/199 accepted, 14 rounds |

**85.2 → 205.9 tok/s，2.4×**；同时 TTFT 253 ms → 61 ms（前缀缓存命中 88.1%）。

## 4. 落地改动

| 文件 | 改动 |
|---|---|
| `profiles.json` · `12g-laptop` | `extra_argv` 追加 `--ngram-archive-mib 512 --ngram-session-mib 256` |
| `gateway/chat_gateway.py` | 新增 `draft_session_for()`：透传客户端 `X-NInfer-Draft-Session`；否则用首条 system/user 内容 sha1 派生 `gw-<16hex>` 并注入转发头 |
| 说明 | 客户端不配合也能生效；如客户端自带 session 标识则优先用它 |

回归：重启后 `--ngram-archive-mib 512 --ngram-session-mib 256` 已在 argv；网关 4 连发 decode 85.2 → 205.9。

## 5. 未采用项与原因

| 项 | 原因 |
|---|---|
| `--draft-tokens ≥3` | 接受率崩到 34–36%，净负 |
| `--lm-head-draft` | 制品缺 proposal head，启动即 FATAL |
| `--lookup-ngram 16` | 与基线无差异（本机 prompt 无足够可复制上下文） |
| `--ngram-native-sessions` | 未测；DSH 走 openai-completions，未必带 Kilo/Codex/Claude 的会话标识（gateway 注入已覆盖） |

## 6. 边界

1. archive 是 RAM 缓存，`--ngram-session-mib 256` × 会话数；多会话并发时按 512 MiB 总预算摊分。
2. 收益只在**同会话、结构重复**的请求上出现（agent 的工具回环、代码续写、日志处理典型）；一次性长文问答无收益。
3. 前两次请求永远是基线速度——别用单次测量判断此项。
4. draft-tokens 与 archive 可叠加但不推荐：draft 加宽后 MTP 接受率崩，会把 ngram 的收益吃掉一半（B7 = 93.3 峰值，低于纯 archive 的 134）。
