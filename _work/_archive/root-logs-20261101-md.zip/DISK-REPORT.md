# DISK-REPORT · Local-AI 根目录占用盘点

- 测量时间：2026-10-22 13:11 (+08:00)
- 测量方式：`du -sh` / `find -size +1G` / `df -h D:` 实测，无估算
- 磁盘基线：`D: 631G 总 / 493G 已用 / 138G 可用 (79%)`
- 工作区总量：约 **175 GiB**（`du -sc` 全树，含 .git）

## 一、顶层占用 Top（实测）

| 路径 | 大小 | 类型 | 判定 | 理由 |
|---|---|---|---|---|
| train/ | 151G | 训练数据＋权重＋中间件 | 混合 | 内含 57G base + 57G local-pack + 17G ninfer + 16G kitty-rev，逐项下钻见下 |
| ninfer-27b-kv-stream-3arch-20261019/ | 22G | 权重＋运行时 | KEEP（含 ASK 子项） | 部署中的 27B 模型（model 17G / engines 2.2G / runtime 657M）；`logs/` 内 1.86G 前缀缓存见 ASK |
| ninfer-csunx/ | 2.7G | 源码＋运行时 | KEEP（含 ASK 子项） | NInfer 引擎运行时（runtime 1.9G）；`engine.zip` 809M 为重复包，见 ASK |
| _research/ | 88M | 归档 | KEEP | 调研备案（csunx 87M 为下载资料） |
| .git/ | 37M | 源码 | KEEP | 仓库本体，禁止触碰 |
| _work/ | 30M | 源码 | KEEP | 会话解帧/校验脚本＋统计 |
| _repos/ | 2.5M | 源码 | KEEP | 参考仓库（heretic / abliteration） |
| plugins/ | 1.6M | 源码 | KEEP | 适配器源码＋lib |
| _tools/ | 119K | 源码 | KEEP | 提取脚本 |
| logs/ | 81K | 日志 | KEEP | 本轮交付报告与隔离校验 json（单文件 <50MB） |
| docs/ | 48K | 源码 | KEEP | 文档 |
| TASKPOINT.md / README.md / AGENTS.md / CLAUDE.md / .gitignore | 44K+12K+8K+4K+4K | 源码 | KEEP | 约定与断点 |
| .agent-teams/ | 44K | 归档 | KEEP | 团队状态 |
| Local-AI-testarea/ | 5K | 临时 | KEEP | 体积可忽略 |

## 二、二级下钻（>1 GB 目录）

| 路径 | 大小 | 类型 | 判定 | 理由 |
|---|---|---|---|---|
| train/lines/27b-kittyrev/local-pack/ | 57G | 交付物 | KEEP（含 ASK 子项） | v3 三件交付物在此 |
| ├ kittyrev-local-pack.tar | 25G | 交付物 | **KEEP** | v3 pack 本体（25,778,176,000 B），tar 内仅 merged-layers/ + act-cache/ |
| ├ merged-layers/ | 14G | 权重 | **ASK** | 该 tar 的解包副本；删后 `tar -xf` 可复原，但属交付链中间件 |
| ├ act-cache/ | 11G | 训练数据 | **ASK** | 同上，tar 内 `act-cache/` 的解包副本 |
| ├ qwen3_8_27b_kittyrev_iq2s.ninfer | 8.8G | 权重 | **KEEP** | v3 量化交付物（9,407,284,736 B） |
| └ adapter_model.safetensors | 153M | 交付物 | **KEEP** | v3 LoRA 适配器（159,452,256 B）＋ adapter_config.json |
| train/lines/27b-kittyrev/base/ | 57G | 权重 | **ASK** | Qwen 原版权重，见 ASK |
| ├ Qwen3.8-27B/ | 52G | 权重 | **ASK** | 18 个 safetensors（单文件最大 3.8G）；删后无法重建 merged，只能重下 52G |
| └ Qwen3.8-27B-layers/ | 4.8G | 权重 | **ASK** | head/embed 分层切片；可由 base 本地再切（需 GPU 时间） |
| train/ninfer/ | 17G | 权重 | **ASK** | `qwen3_8_27b_base.ninfer` 17G；base 转换产物，删后需重转 |
| train/lines/27b-kittyrev/kitty-rev/ | 16G | 训练数据＋交付物 | KEEP（含 TRASH 子项） | 后训练主目录 |
| ├ tmp/ | 16G | 临时 | **TRASH（保留 mix/ v41/ plan-opt/）** | 本轮临时沙箱；其中 `pack/` 14.55 GiB 为 local-pack tar 的暂存副本 |
| ├ out-mix/ · out/ | 95M · 95M | 权重 | **ASK** | 两版训练输出 adapter（190M），与 v3 正式 adapter 不同代 |
| ├ data/ | 59M | 训练数据 | **KEEP** | large-mix-plus / forge / intent2-3 / bench100 索引 |
| ├ logs/ | 26M | 日志 | KEEP | 含交接 md 与 _v4selftest 自检树 |
| ├ deploy/ | 21M | 源码＋旧打包件 | KEEP（旧包 2 项 TRASH） | 含冻结 md5 校验脚本；旧 tar.gz / zip 见 TRASH |
| ├ scripts/ · eval/ | 4.8M · 156K | 源码 | **KEEP** | 冻结脚本（.pyc 已被 git 跟踪，不动） |
| └ docs-local-*.md / *.md | ≤100K | 源码 | **KEEP** | 方案与交接 |
| train/lines/_shared/tools/ | 1.2G | 源码＋旧打包件 | KEEP（zip 12M TRASH） | ninfer-master 958M + ninfer-convert 195M 为引擎源码，`ninfer-master.zip` 已有解包目录 |
| train/lines/_shared/hf/ | 142M | 缓存 | KEEP | HF datasets 缓存（仍在用） |
| train/.venv/ | 3.3G | 源码 | **ASK** | 训练用 Python 虚拟环境，可 pip 重建（需联网） |
| train/tmp/ · train/logs/ | 895K · 293K | 临时·日志 | KEEP | 体积小，收益低 |
| ninfer-27b…/model/ | 17G | 权重 | KEEP | 两个 .ninfer（9.6G abliterated + 7.2G bonsai），部署中 |
| ninfer-27b…/engines/ | 2.2G | 源码 | KEEP | sm86/sm89/sm120a 三档引擎 |
| ninfer-27b…/logs/ | 1.9G | 缓存＋日志 | **ASK（缓存 1.86G）** | `alt-prefix33.bin` 837M、`prefix-cache-12g-hybrid.bin` 510M、`alt-prefix.bin` 510M 为 KV 前缀缓存，可自动再生 |
| ninfer-27b…/runtime/ | 657M | 源码 | KEEP | CUDA/cuBLAS 运行时 |
| ninfer-csunx/runtime/ | 1.9G | 源码 | KEEP | 引擎 exe + 依赖 |
| ninfer-csunx/engine.zip | 809M | 归档 | **ASK** | 解包目标 `runtime/engine/ninfer-serve.exe` 已在（同 1.35G） |
| _work/model-id-check/ | 16M | 源码 | KEEP | 模型标识校验 |
| _work/session-audit/ | 14M | 源码＋日志 | KEEP | 解帧/校验/统计 |

## 三、TRASH 清单（本轮实际移动，全部 `mv` 进 `_trash/`，无 `rm`）

| 路径 | 大小 | 类型 | 判定 | 理由 |
|---|---|---|---|---|
| train/lines/27b-kittyrev/kitty-rev/tmp/**（除 mix/ v41/ plan-opt/） | 99 项 ≈ 15.6 GiB | 临时 | TRASH | tmp 沙箱按约定清空；`pack/` 14.55 GiB 是 local-pack tar 的暂存副本，tar 完好即再生 |
| __pycache__/（全树 3038 个，实移 3035 个，跳过 3 个含 git 跟踪 .pyc 的目录） | 470 MiB（481,334 KB） | 缓存 | TRASH | 字节码缓存，可再生；含 .venv 内 1667 个 |
| train/lines/_shared/tools/ninfer-master.zip | 12M | 归档 | TRASH | 同名解包目录 `train/lines/_shared/tools/ninfer-master/` 已存在 |
| train/lines/27b-kittyrev/kitty-rev/deploy/ninfer-all-master.tar.gz | 3.1M | 归档 | TRASH | 解包目录 `train/lines/_shared/tools/ninfer-master/` 已存在 |
| train/lines/27b-kittyrev/kitty-rev/deploy/cloud/run_after_expand.sh.bak-imatrix | 10K | 临时 | TRASH | 同目录同名正式文件存在，且该名还有更新备份 `.bak-v4paths`（保留最近 1 份） |
| 空目录 37 个 | 0 | 临时 | TRASH | 无内容（含 tmp 内残留、ninfer-csunx/models、train/gguf 等） |

**注意（物理空间）**：`_trash/` 与源在同一卷（D:），`mv` 只改目录项，**`df` 可用空间在确认真删前不变**。上表数字为「已隔离、可一键释放」的字节量。

## 四、ASK 清单（一项未动，等操作者决定）

| 路径 | 大小 | 删了会怎样 |
|---|---|---|
| train/lines/27b-kittyrev/base/Qwen3.8-27B/ | 52G | v3 的 Qwen 原版权重没了；无法重建 merged/重新量化，只能重下 52G（数小时） |
| train/ninfer/qwen3_8_27b_base.ninfer | 17G | base 转换产物；要重跑 27B 转换（GPU 小时级） |
| train/lines/27b-kittyrev/local-pack/merged-layers/ | 14G | 交付 tar 的解包副本；删后用 `tar -xf kittyrev-local-pack.tar` 复原（约 10 分钟 IO，需 14G 峰值空间） |
| train/lines/27b-kittyrev/local-pack/act-cache/ | 11G | 同上，tar 内 `act-cache/`；删后同样由 tar 复原 |
| train/lines/27b-kittyrev/base/Qwen3.8-27B-layers/ | 4.8G | head/embed 分层切片；可由 base 本地重切（需一次 GPU 前向） |
| train/.venv/ | 3.3G | 训练/合并用 venv；需联网 `pip install` 重建（依赖版本已记录在环境报告） |
| ninfer-27b…/logs/*.bin（3 个） | 1.86G | KV 前缀缓存；删后首个长前缀请求变慢，引擎会自动重建 |
| ninfer-csunx/engine.zip | 809M | 与 `runtime/engine/ninfer-serve.exe` 同内容；删后若引擎损坏需重下 |
| train/lines/27b-kittyrev/kitty-rev/out/ · out-mix/ | 190M | 两版训练输出 adapter；非 v3 正式交付物，删后若无 checkpoint 无法复现该两轮实验 |

**判为 KEEP 但需说明的一处**：`plugins/dsh-ninfer-local/lib/index.js.bak-think*`（30 个，1.4M）按 TRASH 的「同名备份保留最近 1 份」本可清，但 `AGENTS.md §4` 明确要求保留 `.bak-thinkN` 回滚链 → 按工作区约定保留，不动。

## 五、执行记录（实测）

执行时间 2026-10-22 13:11–13:18。全部操作为 `mv`（无一条 `rm`），目标 `_trash/20261022-1311/`。

| 批次 | 内容 | 条数 | 隔离字节（du -sk 实测） | 源侧验证 |
|---|---|---|---|---|
| A | train/lines/27b-kittyrev/kitty-rev/tmp 沙箱（保留 mix/ v41/ plan-opt/） | 99 项 | 16,407,271 KB = 15.65 GiB | 移前 tmp=16,420,295 KB → 移后 13,044 KB，仅剩 3 个保留目录 + 1 个 pycache |
| B | __pycache__ 目录（跳过 3 个含 git 跟踪 .pyc 的目录） | 3,035 个 | 481,334 KB = 470 MiB | 每 500 项打点计数对齐：found 3038 / moved 3035 / SKIP 3 |
| C-1 | train/lines/_shared/tools/ninfer-master.zip | 1 | 12,555,920 B = 12.0 MiB | 解包目录 train/lines/_shared/tools/ninfer-master/ 存在 |
| C-2 | train/lines/27b-kittyrev/kitty-rev/deploy/ninfer-all-master.tar.gz | 1 | 3,222,066 B = 3.1 MiB | 同上解包目录存在 |
| C-3 | deploy/cloud/run_after_expand.sh.bak-imatrix | 1 | 10,209 B | 正式文件存在，且 .bak-v4paths 更新（保留最近 1 份） |
| D | 空目录（两轮扫描，子目录先移后父目录再空） | 22 个 | 4 KB | 全树空目录剩余 0 |
| **合计** | | **3,159 项** | **16,904,033 KB = 16.12 GiB** | |

A 批明细：`pack/` 14.55 GiB（local-pack tar 的暂存副本，tar 本体未动）＋ `audit/` 44 MiB ＋ 其余
`out-*/ fake-*/ act-*/ subsets-*/ *_test.bin` 等散件。

自检结果：
- `_trash/20261022-1311/`：archives 2 / bak 1 / empty-dirs 22 / pycache 3,035 / tmp 99，与移动计数一致。
- `git status`：无 `D` 记录；git 跟踪文件数 325（移前 325），**零跟踪文件被移走**。
- KEEP 抽查：`kittyrev-local-pack.tar` 25,778,176,000 B、`qwen3_8_27b_kittyrev_iq2s.ninfer` 9,407,284,736 B、
  `adapter_model.safetensors` 159,452,256 B、`train/lines/27b-kittyrev/kitty-rev/{data,scripts,eval,deploy,logs}`、
  `plugins/dsh-ninfer-local/lib`、`train/lines/27b-kittyrev/base/Qwen3.8-27B`、`ninfer-csunx/runtime/engine`、
  `ninfer-27b-…/model` 全部在位。
- 磁盘：`df -h /d` → `631G 493G 138G 79%`（与基线一致）。

## 六、第二轮（Lead 裁决后执行，2026-10-22 13:18–13:20）

### 6.1 清空前「三个必留件」字节校验（清空前执行，全对）

```text
25,778,176,000 B  train/lines/27b-kittyrev/local-pack/kittyrev-local-pack.tar          ✓ = 期望
 9,407,284,736 B  train/lines/27b-kittyrev/local-pack/qwen3_8_27b_kittyrev_iq2s.ninfer  ✓ = 期望
   159,452,256 B  train/lines/27b-kittyrev/local-pack/adapter_model.safetensors         ✓ = 期望
```
三件全对 → `rm -rf _trash/20261022-1311`（16,904,033 KB 落盘释放），exit=0。

### 6.2 ASK 获批五项 → `_trash/20261022-1318/`（仍为 mv，未 rm）

前置确认：`tar -tf kittyrev-local-pack.tar` 内 `act-cache/rest/121.pt`、`merged-layers/layer_48..50.safetensors` 均在 → 副本关系成立，含才删。

| 项 | 隔离字节（du 实测） | 复原件 |
|---|---|---|
| train/lines/27b-kittyrev/local-pack/merged-layers/ | 14,374,500 KB = 13.71 GiB | `tar -xf kittyrev-local-pack.tar merged-layers` |
| train/lines/27b-kittyrev/local-pack/act-cache/ | 10,805,112 KB = 10.31 GiB | 同上，`act-cache` |
| train/lines/27b-kittyrev/base/Qwen3.8-27B-layers/ | 4,966,416 KB = 4.74 GiB | 由 `train/lines/27b-kittyrev/base/Qwen3.8-27B` 本地重切 |
| ninfer-27b…/logs/*.bin（3 个，877,198,076 + 534,225,739 + 534,225,739 B） | 1,900,056 KB = 1.81 GiB | 引擎自动重建 |
| ninfer-csunx/engine.zip | 828,128 KB = 809 MiB（848,001,373 B） | 与 `runtime/engine/ninfer-serve.exe` 同内容 |
| **合计** | **32,874,212 KB = 31.35 GiB** | |

### 6.3 磁盘前后对比（`df -k /d` 实测）

```text
阶段                                  Used(KB)      Avail(KB)    Avail(GiB)
基线（盘点前）                        516,108,808   144,633,328   137.9
清空 _trash/20261022-1311 后          499,206,648   161,535,492   154.1   ← 实释放 16,902,160 KB = 16.11 GiB
隔离 6.2 五项后（同卷 mv，未落盘）     499,206,652   161,535,488   154.1   ← 31.35 GiB 待确认后释放
```
未动（明确保留）：`train/lines/27b-kittyrev/base/Qwen3.8-27B` 52G、`train/ninfer/qwen3_8_27b_base.ninfer` 17G、
`train/.venv` 3.3G、`train/lines/27b-kittyrev/kitty-rev/out` + `out-mix` 190M。
`git status` 无 `D` 记录，跟踪文件数仍 325；`train/lines/27b-kittyrev/local-pack/` 现只剩 tar + .ninfer + adapter 三件交付物。

**本轮最终磁盘**：`D: 631G 总 / 477G 已用 / 155G 可用 (76%)`；`_trash/20261022-1318` 31.35 GiB 待操作者确认后清空（届时 ≈186 GiB 可用）。

## 七、第三轮收尾（Lead 批准清空，2026-10-22 13:2x）

### 7.1 清空前清点（`_trash/20261022-1318`）

```text
顶层 4 项（base / local-pack / ninfer-27b-logs / ninfer-csunx）
递归 4,444 个条目（文件 4,425 + 目录 19），32,874,212 KB = 31.35 GiB
三件必留件删前复核：25,778,176,000 / 9,407,284,736 / 159,452,256 全对
```

### 7.2 清空后最终态

```text
rm -rf _trash/20261022-1318   exit=0    _trash 剩余条目 = 0

df -h /d :  D:  631G  445G  186G  71%
df -k /d :  Used 466,332,444 KB   Avail 194,409,696 KB (= 185.4 GiB)

阶段                   Used(KB)      Avail(KB)    Avail(GiB)
基线                 516,108,808   144,633,328   137.9
清 20261022-1311     499,206,648   161,535,492   154.1
清 20261022-1318     466,332,444   194,409,696   185.4   ← 本轮净释放 49,776,364 KB = 47.5 GiB
```

`git status --short`：146 行 = 24 `M`（本轮之前已有的改动）+ 122 `??`（未跟踪），**删除类记录 0 行**，跟踪文件 325 未变。
`train/lines/27b-kittyrev/base/Qwen3.8-27B`（52G）与 `train/ninfer/qwen3_8_27b_base.ninfer`（17G）**保持在原位，未移入 _trash**，等操作者答复。

## 八、纪律留档（以后清盘照此执行）

```text
· 一律 mv 到 _trash 再 rm，从不直接 rm（唯一例外：清空自己刚隔离、已分类的 _trash 目录）
· 删大目录前先 `tar -tf <包> | grep '^<dir>/'` 证明包内有副本（本例：act-cache/ · merged-layers/）
· 删大件前先验字节：
    tar 25,778,176,000 / .ninfer 9,407,284,736 / adapter 159,452,256
· 每批移动后核 git 跟踪文件数（325）与 KEEP 抽查件，数变了就是动错了
· plugins/dsh-ninfer-local/lib/index.js.bak-think* 30 个 1.4M 是回滚链，永久保留（AGENTS.md §4）
· _trash 与源同卷：mv 只改目录项，df 不变；真正释放发生在 rm 那一刻，别把"已隔离"当"已释放"
· 不确定就归 ASK，不做"看着挺大就删"的判断
```

## 九、第四轮（操作者批准删 base 权重，2026-10-22 13:2x）

### 9.1 删除前置三项（全过，缺一不删）

```text
① train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/  9 个文件齐全，du -sb = 22,917,507 B = 期望值 ✓
   config.json 4,312 / tokenizer.json 12,809,320 / tokenizer_config.json 17,928
   generation_config.json 202 / vocab.json 6,722,759 / merges.txt 3,353,259
   chat_template.jinja 8,952 / preprocessor_config.json 390 / video_preprocessor_config.json 385
② fix_pack.sh        grep -c 'base-meta' = 2  ✓（BASE 默认指向 base-meta）
③ local_train.ps1    grep -c 'base-meta' = 1  ✓（候选列表含 deploy/base-meta/config.json）
额外加验：base-meta 9 个文件与原 train/lines/27b-kittyrev/base/Qwen3.8-27B 同名文件 md5 逐一比对 → 9/9 SAME
```

### 9.2 删除（操作者明确批准，可重下项，直接 rm）

```text
路径                                         删除前 du -sk        删除后
train/lines/27b-kittyrev/base/Qwen3.8-27B/                      54,283,317 KB        GONE（空父目录 train/lines/27b-kittyrev/base 已 rmdir）
train/ninfer/qwen3_8_27b_base.ninfer         17,146,336 KB        GONE
train/ninfer/qwen3_8_27b_base.ninfer.conversion.json   396 KB      GONE（空父目录 train/ninfer 已 rmdir）
rm 两条 exit=0，ls 三路径全部 GONE
```

### 9.3 自检四条

```text
① df：Used 466,354,868 → 394,924,828 KB（释放 71,430,040 KB = 68.1 GiB）
      Avail 194,387,272 → 265,817,312 KB = 253.5 GiB（df -h：186G → 254G，符合预期 ≈69 GiB）
② local-pack 三件未变：25,778,176,000 / 9,407,284,736 / 159,452,256  ✓
③ deploy/base-meta/ = 22,917,507 B，9 文件  ✓
④ git 删除类记录 0；跟踪文件 325 未变；status 148 行（新增 base-meta 为未跟踪 ??，非删除）  ✓
```

### 9.4 全轮总计

```text
阶段               释放                                      Avail(GiB)
基线               —                                         137.9
第一轮隔离→清空     16.11 GiB（tmp 沙箱 / pycache / 旧归档）    154.1
第二轮隔离→清空     31.35 GiB（merged-layers / act-cache / layers / KV缓存 / engine.zip）  185.4
第四轮直接删        68.1 GiB（base 52G + base.ninfer 17G）       253.5
本轮合计释放       115.6 GiB；工作区 175 GiB → 64 GiB
```

级联处置提示：`train/lines/27b-kittyrev/base` 与 `train/ninfer` 已空并移除；v4 训练所需的 base 元数据改由
`train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/` 提供（`fix_pack.sh` / `local_train.ps1` 已指向该处）。


