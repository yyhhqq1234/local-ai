# COMMIT-PLAN · 2026-10-22 仓库卫生与提交计划（只准备，未提交）

扫描基线：`git status --porcelain -uall` = **292 条目**（24 个 `M` + 268 个 `??`）。
本文件位于 `logs/`（`.gitignore:46 logs/` 已忽略），不会进入任何提交。

---

## 一、>50 MB 文件全量（31 个，`find -size +50M` 实测）

| # | 路径 | 大小 | .gitignore 覆盖 |
|---|---|---|---|
| 1 | train/lines/27b-kittyrev/local-pack/kittyrev-local-pack.tar | 24,584.0 MB | **❌ 未覆盖（缺口）** |
| 2 | ninfer-27b-…/model/Huihui-…-IQ2_S-mtp.ninfer | 9,782.4 MB | ✅ `:2 ninfer-27b-kv-stream-3arch-20261019/` |
| 3 | train/lines/27b-kittyrev/local-pack/qwen3_8_27b_kittyrev_iq2s.ninfer | 8,971.5 MB | ✅ `:3 *.ninfer` |
| 4 | ninfer-27b-…/model/Ternary-Bonsai-2-27B-ninfer-v3-mtponly.ninfer | 7,299.6 MB | ✅ `:2` |
| 5 | ninfer-csunx/runtime/engine/ninfer-serve.exe | 1,285.7 MB | ✅ `:10 ninfer-csunx/runtime/` |
| 6 | ninfer-27b-…/engines/sm86/infer-serve.exe | 782.2 MB | ✅ `:2` |
| 7 | ninfer-27b-…/engines/sm89/infer-serve.exe | 764.2 MB | ✅ `:2` |
| 8 | ninfer-27b-…/engines/sm120a/infer-serve.exe | 677.4 MB | ✅ `:2` |
| 9 | train/.venv/…/torch/lib/cublasLt64_13.dll | 455.8 MB | ✅ `:25 train/.venv/` |
| 10 | ninfer-csunx/runtime/engine/cublasLt64_13.dll | 439.0 MB | ✅ `:10` |
| 11 | ninfer-27b-…/runtime/cublasLt64_13.dll | 439.0 MB | ✅ `:2` |
| 12 | train/.venv/…/torch/lib/torch_cuda.dll | 387.1 MB | ✅ `:25` |
| 13 | train/lines/_shared/tools/ninfer-master/.venv-convert/…/torch_cpu.dll | 291.7 MB | ✅ `:88` |
| 14 | train/.venv/…/torch/lib/cufft64_12.dll | 271.2 MB | ✅ `:25` |
| 15 | train/.venv/…/torch/lib/torch_cpu.dll | 250.6 MB | ✅ `:25` |
| 16 | train/.venv/…/torch/lib/cudnn_engines_precompiled64_9.dll | 179.8 MB | ✅ `:25` |
| 17 | train/lines/27b-kittyrev/local-pack/adapter_model.safetensors | 152.1 MB | ✅ `:5 *.safetensors` |
| 18 | train/.venv/…/torch/lib/cusparse64_12.dll | 143.4 MB | ✅ `:25` |
| 19 | train/lines/_shared/tools/ninfer-convert/verify/head-iq3s-mtp.gguf | 128.0 MB | ✅ `:89`（目录整排除）＋`:4 *.gguf` |
| 20 | train/.venv/…/torch/lib/cusolver64_12.dll | 120.6 MB | ✅ `:25` |
| 21 | ninfer-csunx/runtime/engine/avcodec-63.dll | 113.0 MB | ✅ `:10` |
| 22 | ninfer-27b-…/runtime/avcodec-63.dll | 113.0 MB | ✅ `:2` |
| 23 | train/.venv/…/torch/lib/cusolverMg64_12.dll | 90.9 MB | ✅ `:25` |
| 24 | train/.venv/…/torch/lib/nvrtc64_130_0.alt.dll | 86.8 MB | ✅ `:25` |
| 25 | train/.venv/…/torch/lib/nvrtc64_130_0.dll | 86.7 MB | ✅ `:25` |
| 26 | train/.venv/…/torch/lib/nvJitLink_130_0.dll | 84.1 MB | ✅ `:25` |
| 27 | train/.venv/…/torch/lib/cudnn_adv64_9.dll | 84.0 MB | ✅ `:25` |
| 28 | train/lines/27b-kittyrev/kitty-rev/out/adapter/adapter_model.safetensors | 83.3 MB | ✅ `:77 train/lines/27b-kittyrev/kitty-rev/out/` |
| 29 | train/lines/27b-kittyrev/kitty-rev/out-mix/adapter/adapter_model.safetensors | 83.3 MB | ✅ `:78 out-*/` |
| 30 | train/.venv/…/torch/lib/curand64_10.dll | 56.1 MB | ✅ `:25` |
| 31 | train/.venv/…/torch/lib/cudnn_heuristic64_9.dll | 50.8 MB | ✅ `:25` |

结论：31 个里 **30 个已被忽略，唯一缺口是 #1 的 24.5 GB tar**。
次级缺口（<50 MB 但同等危害）：`train/lines/27b-kittyrev/local-pack/act-cache/**/*.pt`（`*.pth` 有，`*.pt` 无）、
66 个未跟踪 `*.pyc`（无 `__pycache__/` 规则）。

---

## 二、.gitignore patch（**已落盘 2026-10-22，Lead 批准；`*.pt` 已收窄为 `train/**/*.pt`**）

实际落盘 diff（`git diff --stat .gitignore` = `1 file changed, 14 insertions(+)`）：

```diff
--- a/.gitignore
+++ b/.gitignore
@@ -69,6 +69,20 @@ train/lines/27b-kittyrev/kitty-rev/out/
 
 # ── 2026-10-21 本轮后训练工程（大件与派生物）────────────────
 .agent-teams/
+
+# ── 2026-10-22 补齐：v3 交付包本体 / 激活缓存 / 字节码 / 清盘临时件 ──
+# tar 24.5G（tar -xf 可复原，绝不入库；谁跑 git add -A 都不能带上它）
+train/lines/27b-kittyrev/local-pack/*.tar
+train/lines/27b-kittyrev/local-pack/merged-layers/
+train/lines/27b-kittyrev/local-pack/act-cache/
+# 激活缓存张量（.pth 已有规则，.pt 之前漏了；收窄到 train/ 下避免误伤别处小 .pt）
+train/**/*.pt
+# Python 字节码：66 个未跟踪 .pyc；已跟踪的 9 个保持原状（不动仓库内容）
+__pycache__/
+*.pyc
+# 一次性清盘脚本（本轮 disk-janitor，无版本价值）
+_work/disk-janitor/
+
 train/lines/_shared/tools/ninfer-master/.venv-convert/
 train/lines/_shared/tools/ninfer-convert/.venv*/
 train/lines/_shared/tools/**/*.gguf
```

### 落盘后三项验证（实测）

```text
a) git check-ignore -v train/lines/27b-kittyrev/local-pack/kittyrev-local-pack.tar
   .gitignore:75:train/lines/27b-kittyrev/local-pack/*.tar    train/lines/27b-kittyrev/local-pack/kittyrev-local-pack.tar    rc=0 ✓
b) git check-ignore -v train/lines/27b-kittyrev/local-pack/act-cache/rest/121.pt
   .gitignore:77:train/lines/27b-kittyrev/local-pack/act-cache/   train/lines/27b-kittyrev/local-pack/act-cache/rest/121.pt  rc=0 ✓
   附验 train/**/*.pt：train/anything/act-cache/x.pt → .gitignore:79 命中；
   反例 docs/config.pt → rc=1 未命中（未误伤别处小 .pt）
c) git status --porcelain -uall : 294 → 223 行
   消失 74 项 = 未跟踪 .pyc 63 + tar 1（24.5G）+ _work/disk-janitor 10
   新增 3 项 = .gitignore 自身(M) + data/forge3 两份实时新数据（14:21 由 S3 侧生成，非本次改动）
   剩余 223 = 25 M（含 .gitignore）+ 198 ??
已跟踪 9 个 .pyc 不动；其中 3 个仍以 M 呈现（eval_kitty / train_kitty / train_partial_lora），按 Lead 指示保持原状。
```

回滚：`cp _work/disk-janitor/gitignore.before .gitignore`（改前原件 2,707 B）。

副作用说明：
- `*.pyc` 不会撤销已跟踪的 9 个 `.pyc`（仍是 tracked，仍需 `git rm --cached` 才脱库）；
- `train/lines/27b-kittyrev/local-pack/merged-layers/`、`act-cache/` 两层已物理删除，规则是防复发；
- `*.pt` 可能误伤未来确实要入库的小 `.pt` 配置——如担心，可改成 `train/**/*.pt`。

---

## 三、建议提交清单（4 组核心 + 1 组可选）

分类口径：按 `git status -uall` 全量 292 条目切分，`__pycache__/*.pyc`、`_work/disk-janitor/`、
`local-pack/*.tar` 不进任何组（见第四节）。

### A · 判据与脚本（99 个 / 1,548,910 B = 1.48 MiB）

```text
构成：scripts/ 直属脚本 24 + scripts/forge_src/ 34 + scripts/regression/ 41
含：train_kitty.py(M) train_partial_lora.py(M) precompute_activations.py(M) plan_layers.py(M)
    refusal_probe.py(M) probe_layout.py(M) make_subsets.py(M) make_re_eval.py(M)
    eval_re_extended.py(M) distill_cot.py(M) split_merge_layers.py(M) pin_arch.py verify_expand.py …
    regression/：run_all + scan_dead_assignments + scan_silent_patterns + t1…t38（41 项门）
    forge_src/：chain_* / comply_* / det_* / op_* / pe_* 34 份数据生成源
message：补 v3/v4 判据与回归脚本：训练·评测·激活预计算·拒绝探测 + 41 项回归门与 34 份数据生成源，冻结可复算口径
```

### B · 部署链（5 个 / 77,922 B = 76 KiB）

```text
train/lines/27b-kittyrev/kitty-rev/deploy/cloud/：run_after_expand.sh(M) make_imatrix.sh v4_after_download.sh v4_pick.sh pack_deliverables.sh
message：固化云端部署链：expand 后处理 / imatrix / v4 下载与挑选 / 交付打包，五脚本串起 5070 Ti 侧全流程
备查：pin_arch 实际在 scripts/pin_arch.py（归 A），cloud/ 下无同名件
```

### C · 数据与文档（56 个 / 10,238,581 B = 9.76 MiB）

```text
data/：intent3（7 脚本+6 数据+2 manifest）、forge2（9）、forge（6）、intent2（6）、subsets（5）、
      reablit（2）、eval_re_calib（2）、eval_re_extended.jsonl(M) + _manifest.json(M)、bench100.index.json、
      large-mix-plus/merge-manifest.json
文档：docs-local-continual-training-plan.md(M) docs-local-partial-lora.md(M) TASKPOINT.md(M)
大件：data/large-mix-plus/train.jsonl 5.97 MB（真实训练集，见第四节风险）
message：落 intent3/forge2/bench100 索引与口径文档：训练数据、接续计划与断点同步到今天
```

### D · 本地侧（11 个 / 22,931,295 B = 21.87 MiB）

```text
deploy/base-meta/ 9 件 = 22,917,507 B（config/tokenizer×2/merges/vocab/chat_template/generation/preprocessor×2）
deploy/fix_pack.sh 4,432 B   deploy/local_train.ps1 9,356 B
message：base 元数据本地化到 deploy/base-meta（9 件 22.9 MB）＋ fix_pack/local_train 改指该处，删 52 G 权重后仍可起训
```

### E · 运行辅助（**Lead 收窄后：只提交 3 个，其余不入库**）

```text
入库（随 B 或 D 一起，约 1.2 MiB）：
  train/lines/27b-kittyrev/kitty-rev/deploy/remote.py(M)              7,415 B   云端/本地交互复用
  train/lines/27b-kittyrev/kitty-rev/deploy/verify_local_pack.py     12,606 B   交付包校验，复跑要用
  train/lines/27b-kittyrev/local-pack/adapter_config.json             1,199 B   v3 适配器配置（与 tar/.ninfer 配套）
不入库（一次性探针，10 个）：probe_*.sh(7) / finish14*.sh(3) / iq2s_fix*.sh(2) / iq2s_final.sh / probe_speed.py…
不入库（一次性产物与副本）：_iq2s_obj.json 286 KB / _iq2s_inspect.json / _work/model-id-check/hf/*（16 MB）
可选保留：_work/intent3 7 个分析脚本（1.1 MB）——是否入库由你定，默认不入库
原 E 组规模：46 个 / 16,431,611 B (15.67 MiB)；收窄后实际入库 3 个 / 21,220 B
```

---

## 四、风险提示（不该提交 / 需单独决策）

| 项 | 体量 | 处理建议 |
|---|---|---|
| `train/lines/27b-kittyrev/local-pack/kittyrev-local-pack.tar` | 24,584 MB | **绝不 add**；先落第二节 `train/lines/27b-kittyrev/local-pack/*.tar` 规则 |
| 66 个未跟踪 `*.pyc` | ≈0.9 MB | 忽略即可；已跟踪的 9 个建议 `git rm --cached` + 忽略（需你决定，会改变仓库内容） |
| `__pycache__` 内被改动的 3 个已跟踪 `.pyc`（eval_kitty / train_kitty / train_partial_lora） | 小 | 不要当源码提交；随上一条一起 `rm --cached` |
| `_work/disk-janitor/` 10 个脚本 | 小 | 本轮清盘一次性件，建议不进库（已写进 patch） |
| `_work/model-id-check/hf/*`（tokenizer 11.4 MB + vocab 2.7 MB + merges 1.6 MB） | ≈16.0 MB | 一次性模型指纹副本；建议不入库（要么 ignore，要么放 E 单组但明确"仅比对用"） |
| `train/lines/27b-kittyrev/kitty-rev/data/large-mix-plus/train.jsonl` | 5.97 MB | **Lead 决定：入库**（可复现性优先于仓库体积），随 C 组提交 |
| `data/forge3/`（FORGE3-MANIFEST.json + train.jsonl，14:21 实时新增） | 34 KB | S3 侧新生成的数据，本轮提交计划外；等生成稳定后再并入 C 组 |
| `deploy/_iq2s_obj.json` 286 KB / `_iq2s_inspect.json` | 小 | 运行产物 json，不入库 |
| `probe_*.sh` / `finish14*.sh` / `iq2s_fix*.sh` 共 10 个一次性探针 | 小 | **Lead 决定：不入库** |
| `_trash/` | **0 项** | 已清零，目录空；本轮未动 |

**提交顺序（Lead 定，2026-10-22）：`D → B → A → C`**

```text
D 先落：base 权重已删，deploy/base-meta 是唯一一份元数据，最怕丢
B 其次：5 个部署脚本仅 76 KiB，最容易验证
A 第三：99 个脚本 1.48 MiB，体量最大但属核心判据
C 最后：数据+文档 9.76 MiB，含已决定入库的 large-mix-plus/train.jsonl（5.97 MB）
E 只带 3 个（remote.py / verify_local_pack.py / adapter_config.json），并入 B 或 D 那一批
提交时点：16:45 S4 起训后，由 Lead 一句话触发；本文件之前不 add / 不 commit / 不 push
```

先落 D（删了 52 G 权重后 base-meta 是唯一元数据来源，先保命），再落判据与部署链，最后数据文档。
