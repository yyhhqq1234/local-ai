# COMMIT-READY · 四批提交清单（实测双快照 · 只读采集）

- 仓库：`D:\BaiduNetdiskDownload\Local-AI`（branch `main`）
- 采集窗口：2026-10-22 17:56 – 18:05（Asia/Shanghai），其中 §1 基线取 **快照 1 @ 17:56**，§1.3 取 **快照 2 @ 18:00:42**
- **纪律声明：全程只读 git。未执行 `git add` / `commit` / `push` / `checkout` / `reset`。** 唯一触及 index 的命令是 `git add -n`（dry-run，只列出将暂存项，不写 index）——执行后复验 `git diff --cached --name-only | wc -l` = **0**，index 干净。
- 口径：`git status --short`（未跟踪目录折叠为 1 行）与 `git status --short -uall`（逐文件展开）双记。

---

## §1 实测基线（必查 1 + 必查 2）

### 1.1 快照 1 @ 17:56（HEAD / tracked / staged）

```text
$ git rev-parse --short HEAD
ff27277                                      ✓ 与期望一致
$ git rev-parse HEAD
ff27277e219b0d8b31cb25c70d7f84032bb37588
$ git rev-parse --abbrev-ref HEAD
main

$ git ls-files | wc -l
325                                          ✓ 与期望一致
$ git diff --cached --name-only | wc -l
0                                            ✓ staged = 0

$ git status --short | wc -l
94                                           折叠口径：25 M + 69 ??
$ git status --short -uall | wc -l
240                                          逐文件口径：25 M + 215 ??
```

### 1.2 必查 1-a：>50MB 未忽略文件 → **0 个**

```text
$ git ls-files --others --exclude-standard -z | xargs -0 stat -c "%s" | awk '$1>52428800' | wc -l
0                                            ✓ 未跟踪且未忽略中，0 个 >50MB
$ git ls-files -z | xargs -0 stat -c "%s" | awk '$1>52428800' | wc -l
0                                            ✓ 已跟踪中，0 个 >50MB

# 未跟踪未忽略文件总数 215，最大 5 个：
  6,722,759  train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/vocab.json
  5,972,631  train/lines/27b-kittyrev/kitty-rev/data/large-mix-plus/train.jsonl
    638,586  train/lines/27b-kittyrev/kitty-rev/data/subsets/forge-subset.jsonl
     85,248  train/lines/27b-kittyrev/kitty-rev/data/intent3/re-sft.messages.jsonl
     78,648  train/lines/27b-kittyrev/kitty-rev/data/intent3/re-sft.jsonl
```

### 1.3 快照 2 @ 18:00:42（基线漂移复测）

```text
git status --short          96 行      （25 M + 71 ??）
git status --short -uall    241 行     （25 M + 216 ??）
未跟踪未忽略                 216
>50MB 未忽略                 0          ✓
已跟踪 >50MB                 0          ✓
tracked                     325
staged                      0
HEAD                        ff27277
```

> **漂移说明（重要）**：采集期间有并发写入，状态从 240 行涨到 241 行。新增为
> `train/lines/27b-kittyrev/kitty-rev/scripts/assert_params_effective.py`（23,299 B，new）。因此 **A 批文件数为 104 而非 103**。
> 执行提交前请重跑 §1.1 五条命令取当场值；若 `git status --short` 不再是 96 行，按 §5 的
> "新增 scripts/*.py 自动并入 A" 规则处理：A 批 add 命令用的是 `scripts/*.py` 通配，新增脚本自动带上。

### 1.4 必查 1-b：`train/lines/27b-kittyrev/local-pack/` 实况（重点大件）

```text
$ stat -c '%s %n' train/lines/27b-kittyrev/local-pack/*
25,778,176,000  kittyrev-local-pack.tar              ← 24.01 GiB（十进制 25.78 GB）  IGNORED ✓
   159,452,256  adapter_model.safetensors            ← IGNORED (*.safetensors @:5) ✓
 9,407,284,736  qwen3_8_27b_kittyrev_iq2s.ninfer     ← 8.76 GiB  IGNORED (*.ninfer @:3) ✓
         1,199  adapter_config.json                   ← **未忽略**（遗留小件，见 §3）
```

> 结论：24 GB 级 tar 不会被 `git add` 误带上；但 `train/lines/27b-kittyrev/local-pack/adapter_config.json`（1,199 B）未忽略，
> **`git add train/lines/27b-kittyrev/local-pack` 或 `git add -A` 会把它带进来**。四批命令一律用精确路径，禁用 `-A`。

### 1.5 必查 2：`.gitignore` 三规则 `git check-ignore -v` 实测命中

```text
① tar
$ git check-ignore -v train/lines/27b-kittyrev/local-pack/kittyrev-local-pack.tar
.gitignore:75:train/lines/27b-kittyrev/local-pack/*.tar   train/lines/27b-kittyrev/local-pack/kittyrev-local-pack.tar      rc=0 ✓

② .pt（规则收窄到 train/）
$ git check-ignore -v train/lines/27b-kittyrev/kitty-rev/act-cache/probe-0.pt
.gitignore:79:train/**/*.pt            train/lines/27b-kittyrev/kitty-rev/act-cache/probe-0.pt          rc=0 ✓
# 现存 4 个 .pt 全部命中（均位于 train/lines/27b-kittyrev/kitty-rev/logs/ 内，先被 :67 目录规则吃掉）：
train/lines/27b-kittyrev/kitty-rev/logs/_v4selftest/actfix/right/act-cache/re-train/re-train-0.pt    → :67
train/lines/27b-kittyrev/kitty-rev/logs/_v4selftest/actfix/right/act-cache/rest/rest-0.pt            → :67
train/lines/27b-kittyrev/kitty-rev/logs/_v4selftest/actfix/wrong/act-cache-v4/re-train/re-train-0.pt → :67
train/lines/27b-kittyrev/kitty-rev/logs/_v4selftest/actfix/wrong/act-cache-v4/rest/rest-0.pt         → :67

③ __pycache__/
$ git check-ignore -v train/lines/27b-kittyrev/kitty-rev/scripts/regression/__pycache__/
.gitignore:81:__pycache__/   train/lines/27b-kittyrev/kitty-rev/scripts/regression/__pycache__/        rc=0 ✓
$ git check-ignore -v train/lines/27b-kittyrev/kitty-rev/scripts/__pycache__/zzz_probe.cpython-313.pyc
.gitignore:81:__pycache__/   ...zzz_probe.cpython-313.pyc                           rc=0 ✓
```

### 1.6 必查 2-a：反例 —— 小 `.pt` / 别处 `.pt` **不应**被忽略（实测 rc=1）

```text
$ git check-ignore -v _work/tiny-model.pt
（无输出）                                rc=1   ← 未忽略 ✓ 符合预期
$ git check-ignore -v tiny-model.pt
（无输出）                                rc=1   ← 未忽略 ✓ 符合预期
```

> 即 `train/**/*.pt` 只吃 `train/` 下的张量缓存；`_work/` 或仓库根目录的小 `.pt` 仍会正常出现在
> `git status` 里 —— 有意保留的窄口径，防"整仓 .pt 全禁"漏文件。

### 1.7 已跟踪 `.pyc` 属例外（ignore 对已入库文件无效）

```text
$ git ls-files "*.pyc" | wc -l
9
$ git check-ignore -v train/lines/27b-kittyrev/kitty-rev/scripts/__pycache__/train_kitty.cpython-313.pyc
（无输出）                                rc=1   ← 已跟踪，ignore 不生效

其中 3 个处于 M：
  train/lines/27b-kittyrev/kitty-rev/eval/__pycache__/eval_kitty.cpython-313.pyc
  train/lines/27b-kittyrev/kitty-rev/scripts/__pycache__/train_kitty.cpython-313.pyc
  train/lines/27b-kittyrev/kitty-rev/scripts/__pycache__/train_partial_lora.cpython-313.pyc
→ 四批均不含；A 批用 `scripts/*.py`，不用 `scripts/`，避免把 .pyc 改动带进暂存区。
```

---

## §2 四批清单（顺序 D → B → A → C）

| 批 | 文件数 | 字节 | MiB | 构成 |
|---|---:|---:|---:|---|
| D | 12 | 22,934,606 | 21.87 | `.gitignore` 1 + base-meta 9 + fix_pack.sh + local_train.ps1 |
| B | 5 | 77,922 | 0.07 | deploy/cloud 5 脚本 |
| A | **104** | **1,611,925** | 1.54 | scripts 26 + forge_src 34 + regression 43 + eval_kitty.py 1 |
| C | 39 | 1,109,628 | 1.06 | intent3 25 + forge2 10 + bench100 1 + docs 2 + TASKPOINT 1 |
| **合计** | **160** | **25,734,081** | **24.54** | 另有 C+ 4 件既有改动（72,871 B，可选，§2.5） |

### 批 D · 本地侧 + ignore 安全网（最关键，12 件 / 22,934,606 B）

```text
大小(B)     路径
    3,311   .gitignore                                          (M)  ← :75 / :79 / :81 三条安全网本体
    ▼ base-meta 9 件，sum = 22,917,507 B（实测与预期一致）
    8,952   train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/chat_template.jinja
    4,312   train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/config.json
      202   train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/generation_config.json
3,353,259   train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/merges.txt
      390   train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/preprocessor_config.json
12,809,320  train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/tokenizer.json
   17,928   train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/tokenizer_config.json
      385   train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/video_preprocessor_config.json
6,722,759   train/lines/27b-kittyrev/kitty-rev/deploy/base-meta/vocab.json
    4,432   train/lines/27b-kittyrev/kitty-rev/deploy/fix_pack.sh
    9,356   train/lines/27b-kittyrev/kitty-rev/deploy/local_train.ps1
```

```bash
# D 批 add（.gitignore 先落：后续三批的安全网以它为准）
git add .gitignore \
        train/lines/27b-kittyrev/kitty-rev/deploy/base-meta \
        train/lines/27b-kittyrev/kitty-rev/deploy/fix_pack.sh \
        train/lines/27b-kittyrev/kitty-rev/deploy/local_train.ps1
# 提交前验（预期 12 files changed / 22,934,606 insertions）
git diff --cached --stat | tail -1
# message：
# deploy: base 元数据落到 deploy/base-meta（9 件 22.9 MB），fix_pack/local_train 改指该处；补 .gitignore 三条安全网（tar / train**/*.pt / __pycache__）
```

```bash
# D 批回滚（未 commit）
git restore --staged .gitignore train/lines/27b-kittyrev/kitty-rev/deploy/base-meta \
                    train/lines/27b-kittyrev/kitty-rev/deploy/fix_pack.sh train/lines/27b-kittyrev/kitty-rev/deploy/local_train.ps1
```

### 批 B · 云端脚本（5 件 / 77,922 B）

```text
 13,695  train/lines/27b-kittyrev/kitty-rev/deploy/cloud/run_after_expand.sh     (M)
  9,749  train/lines/27b-kittyrev/kitty-rev/deploy/cloud/make_imatrix.sh
 34,466  train/lines/27b-kittyrev/kitty-rev/deploy/cloud/v4_after_download.sh
 15,769  train/lines/27b-kittyrev/kitty-rev/deploy/cloud/v4_pick.sh
  4,243  train/lines/27b-kittyrev/kitty-rev/deploy/cloud/pack_deliverables.sh
```

```bash
git add train/lines/27b-kittyrev/kitty-rev/deploy/cloud/run_after_expand.sh \
        train/lines/27b-kittyrev/kitty-rev/deploy/cloud/make_imatrix.sh \
        train/lines/27b-kittyrev/kitty-rev/deploy/cloud/v4_after_download.sh \
        train/lines/27b-kittyrev/kitty-rev/deploy/cloud/v4_pick.sh \
        train/lines/27b-kittyrev/kitty-rev/deploy/cloud/pack_deliverables.sh

# 回滚
git restore --staged train/lines/27b-kittyrev/kitty-rev/deploy/cloud/run_after_expand.sh \
                    train/lines/27b-kittyrev/kitty-rev/deploy/cloud/make_imatrix.sh \
                    train/lines/27b-kittyrev/kitty-rev/deploy/cloud/v4_after_download.sh \
                    train/lines/27b-kittyrev/kitty-rev/deploy/cloud/v4_pick.sh \
                    train/lines/27b-kittyrev/kitty-rev/deploy/cloud/pack_deliverables.sh
```

### 批 A · 判据与回归（104 件 / 1,611,925 B）

构成：`scripts/*.py` 26（其中 M 11）+ `scripts/forge_src/` 34 + `scripts/regression/` 43 + `eval/eval_kitty.py` 1（M）。

```text
=== scripts/ 直属 26 ===
 4,442  diag_eval_format.py            (new)
13,824  distill_cot.py                 (M)
14,125  eval_re_extended.py            (M)
 3,465  flatten_keys.py                (new)
 6,167  forge_difficulty.py            (new)
22,174  gen_compliance.py              (new)
16,606  gen_forge.py                   (new)
 4,914  make_comply_subsets.py         (new)
21,673  make_re_eval.py                (M)
21,565  make_subsets.py                (M)
 3,126  merge.py                       (new)
10,636  merge_forge.py                 (new)
 2,765  parse_train_log.py             (new)
26,682  pick_checkpoint.py             (new)
11,015  pin_arch.py                    (new)
16,663  plan_layers.py                 (M)
34,708  precompute_activations.py      (M)
 4,278  probe_layout.py                (M)
 4,103  recompute_refusal_rate.py      (new)
35,290  refusal_probe.py               (M)
 9,966  serve_4bit_base.py             (new)
20,060  split_merge_layers.py          (M)
22,169  train_kitty.py                 (M)
66,498  train_partial_lora.py          (M)
39,220  verify_expand.py               (new)
23,299  assert_params_effective.py     (new，§1.3 漂移新增，自动并入本批)

=== scripts/forge_src/ 34（全 new）===
13,857 chain_a1.py      13,225 chain_a2.py       13,801 chain_a3.py
27,455 chain_d.py       23,156 chain_e.py        22,612 chain_f.py
31,825 comply_a.py      63,677 comply_a_ext.py   42,092 comply_b.py
48,348 comply_b2.py     38,498 comply_c.py       54,287 comply_c_ext.py
36,925 comply_d.py      36,390 comply_d2.py      26,746 comply_dpo1.py
23,131 comply_dpo2.py   25,455 det_a.py          24,877 det_b.py
33,009 det_c.py         26,676 det_d.py          28,422 det_e.py
 6,125 extra.py         21,091 op_d.py           18,671 op_e.py
17,698 op_f.py          16,516 op_semantics_a.py  19,457 op_semantics_b.py
17,822 pe_c.py          19,870 pe_d.py           21,652 pe_e.py
20,030 pe_f.py           3,788 pe_g.py           18,364 pe_structure_a.py
18,789 pe_structure_b.py

=== scripts/regression/ 43（全 new；__pycache__ 6 个 .pyc 已忽略，不在清单内）===
 3,044 README.md                  13,930 dead_assignments_allow.json
 7,353 run_all.py                 12,774 scan_dead_assignments.py
 4,005 scan_silent_patterns.py
t1  2,489   t2  3,304   t3  6,854   t4  3,068   t5  2,366
t6  3,691   t7  3,409   t8  3,642   t9  3,079   t10 3,775
t11 5,897   t12 8,300   t16 7,865   t17 3,840   t18 5,097
t19 2,963   t20 6,158   t21 5,062   t22 2,371   t23 3,346
t24 7,310   t25 4,843   t26 5,239   t27 6,404   t28 6,627
t29 8,182   t30 4,618   t31 7,309   t32 3,275   t33_imatrix_gate 4,825
t33_train_cache_base_fp 7,648   t34 5,212   t35 5,457   t36 7,823
t37 6,174   t38 12,483  t39 6,203   t40 4,502

=== eval/ ===
19,964  train/lines/27b-kittyrev/kitty-rev/eval/eval_kitty.py   (M)
```

```bash
# A 批 add —— scripts/*.py 而非 scripts/（避开 3 个已跟踪 .pyc 的 M）
git add train/lines/27b-kittyrev/kitty-rev/scripts/*.py \
        train/lines/27b-kittyrev/kitty-rev/scripts/forge_src \
        train/lines/27b-kittyrev/kitty-rev/scripts/regression \
        train/lines/27b-kittyrev/kitty-rev/eval/eval_kitty.py

# 回滚
git restore --staged train/lines/27b-kittyrev/kitty-rev/scripts/ train/lines/27b-kittyrev/kitty-rev/eval/eval_kitty.py
```

### 批 C · 数据与文档（39 件 / 1,109,628 B）

```text
=== data/intent3/ 25 件 = 647,488 B（w3_accept.py.bak-wf2 4,231 B 被 :61 *.bak-* 忽略，不计入）===
14,446 INTEGRATION.md         19,416 V41-GROUPS.md           7,826 build_w3_scenes.py
10,696 dedup.py                7,683 gen_w3.py                6,752 judge_structural.py
   568 length-stats.json        6,451 manifest_schema.json   11,452 measure_willingness.py
10,691 nsfw_judge.py           8,853 overrefusal-40.jsonl    78,648 re-sft.jsonl
85,248 re-sft.messages.jsonl   9,317 run_overrefusal.py       8,046 style_meter.py
104,579 w3-scenes.jsonl       26,592 w3-scenes.p0.jsonl     26,521 w3-scenes.p1.jsonl
25,657 w3-scenes.p2.jsonl     25,809 w3-scenes.p3.jsonl      8,964 w3_accept.py
36,580 w3n-negative.jsonl     72,588 w4-general.jsonl         4,833 will_compare.py
 4,026 willing-forge-MANIFEST.json

=== data/forge2/ 10 件 = 245,654 B ===
22,003 FORGE2-MANIFEST.json   16,981 _src/a1_elf.py    13,134 _src/a2_fw.py
13,546 _src/a3_pe.py           8,424 _src/a4_apk.py     8,859 _src/a5_extra.py
15,478 _src/b1_dualview.py    13,244 _src/b2_ring0.py  15,930 _src/c_report.py
118,055 train.jsonl

=== 单件 ===
 1,955 train/lines/27b-kittyrev/kitty-rev/data/bench100.index.json

=== 文档 3 件 ===
64,561 train/lines/27b-kittyrev/kitty-rev/docs-local-continual-training-plan.md  (M)
100,263 train/lines/27b-kittyrev/kitty-rev/docs-local-partial-lora.md            (M)
49,707 TASKPOINT.md                                           (M)
```

```bash
# C 批 add
git add train/lines/27b-kittyrev/kitty-rev/data/intent3 \
        train/lines/27b-kittyrev/kitty-rev/data/forge2 \
        train/lines/27b-kittyrev/kitty-rev/data/bench100.index.json \
        train/lines/27b-kittyrev/kitty-rev/docs-local-continual-training-plan.md \
        train/lines/27b-kittyrev/kitty-rev/docs-local-partial-lora.md \
        TASKPOINT.md

# 回滚
git restore --staged train/lines/27b-kittyrev/kitty-rev/data/intent3 train/lines/27b-kittyrev/kitty-rev/data/forge2 \
                    train/lines/27b-kittyrev/kitty-rev/data/bench100.index.json \
                    train/lines/27b-kittyrev/kitty-rev/docs-local-continual-training-plan.md \
                    train/lines/27b-kittyrev/kitty-rev/docs-local-partial-lora.md TASKPOINT.md
```

### §2.5 C+ 追加 4 件（已跟踪数据的改动 / 72,871 B，建议并入 C，否则四批跑完仍留 4 条 M）

```text
63,399  train/lines/27b-kittyrev/kitty-rev/data/eval_re_extended.jsonl          (M)
   928  train/lines/27b-kittyrev/kitty-rev/data/eval_re_extended_manifest.json  (M)
 2,378  train/lines/27b-kittyrev/kitty-rev/data/subsets/refusal_scan.json       (M)
 6,166  train/lines/27b-kittyrev/kitty-rev/data/subsets/subsets_manifest.json   (M)
```

```bash
git add train/lines/27b-kittyrev/kitty-rev/data/eval_re_extended.jsonl \
        train/lines/27b-kittyrev/kitty-rev/data/eval_re_extended_manifest.json \
        train/lines/27b-kittyrev/kitty-rev/data/subsets/refusal_scan.json \
        train/lines/27b-kittyrev/kitty-rev/data/subsets/subsets_manifest.json
# 回滚
git restore --staged train/lines/27b-kittyrev/kitty-rev/data/eval_re_extended.jsonl \
                    train/lines/27b-kittyrev/kitty-rev/data/eval_re_extended_manifest.json \
                    train/lines/27b-kittyrev/kitty-rev/data/subsets/refusal_scan.json \
                    train/lines/27b-kittyrev/kitty-rev/data/subsets/subsets_manifest.json
```

---

## §3 不进四批（保持未跟踪 / 保持改动，禁用 `git add -A`）

未跟踪未忽略 216（快照 2）− 四批覆盖 144 = **残留 72**：

```text
30  train/lines/27b-kittyrev/kitty-rev/deploy/    一次性探针：probe_*(7) / finish14*(3) / iq2s_*(3) / dl_huihui*(2) /
                               diag_eval*(2) / get_multi / speed_multi / test_get_multi_resume /
                               rename_shards / artifact_formats / budget_transfer / make_text_view /
                               fetch_all / run_iq2s_path / sample-train.ps1 / verify_local_pack.py /
                               _iq2s_obj.json / _iq2s_inspect.json
28  train/lines/27b-kittyrev/kitty-rev/data/      非本轮主题：forge/ forge3/ forge4/ forge5/ intent2/ reablit/
                               eval_re_calib/ large-mix-plus/ subsets/forge-subset*.jsonl
 7  _work/model-id-check/hf/   一次性模型指纹副本 15.9 MB（tokenizer 11.4 MB / vocab 2.7 MB / merges 1.6 MB）
 7  _work/intent3/             一次性分析脚本 82 KB
 1  train/lines/27b-kittyrev/local-pack/adapter_config.json   1,199 B（未忽略；只能用精确路径 add）
*  并发仍在写入，实时值以 §1.1 重跑为准
```

四批跑完后仍会残留的改动（4 条 M）：

```text
train/lines/27b-kittyrev/kitty-rev/deploy/remote.py                                            (M)
train/lines/27b-kittyrev/kitty-rev/eval/__pycache__/eval_kitty.cpython-313.pyc                 (M，已跟踪 .pyc)
train/lines/27b-kittyrev/kitty-rev/scripts/__pycache__/train_kitty.cpython-313.pyc              (M，同上)
train/lines/27b-kittyrev/kitty-rev/scripts/__pycache__/train_partial_lora.cpython-313.pyc       (M，同上)
```

被 ignore 覆盖、永不 add 的大件（逐个 check-ignore 命中）：
`train/lines/27b-kittyrev/local-pack/kittyrev-local-pack.tar` 24.01 GiB · `train/lines/27b-kittyrev/local-pack/qwen3_8_27b_kittyrev_iq2s.ninfer` 8.76 GiB ·
`train/lines/27b-kittyrev/local-pack/adapter_model.safetensors` 152 MB · `train/lines/27b-kittyrev/local-pack/merged-layers/` · `train/lines/27b-kittyrev/local-pack/act-cache/` · `train/**/*.pt`。

---

## §4 逐批自检与预期计数

```bash
# 每批之后各跑 4 条
git show --stat HEAD | tail -3                                            # 文件数/体量与下表一致
git ls-files | wc -l                                                      # 见下表序列
git status --short | wc -l                                                 # 逐批递减（起点 96）
git diff HEAD~1 --name-only | grep -E '\.(tar|ninfer|safetensors|pt)$'     # 必须为空
```

| 批次 | 累计 tracked（自 325 起） | 累计提交字节 |
|---|---:|---:|
| D 后 | 337 | 22,934,606 |
| B 后 | 342 | 23,012,528 |
| A 后 | 446 | 24,624,453 |
| C 后 | 485 | 25,734,081 |
| C+ 后（可选） | 489 | 25,806,952 |

```bash
# 全批总回滚（未 push 前提）
git reset --soft ff27277     # 提交全撤，改动回暂存区，文件内容不动
git reset ff27277            # 提交全撤 + 撤暂存，文件不动（最安全）
# 单批撤提交留改动
git reset --soft HEAD~1
# 仅已推送场景
git revert <sha>
```

---

## §5 收口口径

```text
9 条关键实测数（快照 2 @ 18:00:42）：
  HEAD                      ff27277（ff27277e219b0d8b31cb25c70d7f84032bb37588）
  tracked                   325
  staged                    0
  git status --short        96 行（25 M + 71 ??）      ← 快照 1 为 94，漂移 +2
  git status --short -uall  241 行（25 M + 216 ??）    ← 快照 1 为 240
  未跟踪未忽略文件           216
  >50MB 未忽略              0      ✓
  已跟踪 >50MB              0      ✓
  四批文件总数               160（D12 + B5 + A104 + C39）；含 C+ 为 164

提交顺序：D → B → A → C（C+ 可并入 C）。
新增 scripts/*.py 会被 A 批通配自动带上，无需改命令。
本轮只产出本文件，未执行任何写 git 操作（唯一 index 接触是 git add -n dry-run，复验 staged=0）。
```
